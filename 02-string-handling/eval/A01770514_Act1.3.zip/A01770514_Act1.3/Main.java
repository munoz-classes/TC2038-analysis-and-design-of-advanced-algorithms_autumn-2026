import java.util.Scanner;
import java.util.LinkedList;
import java.util.Queue;

public class Main {
    public static void main(String[] args) {
        Scanner scanner  = new Scanner(System.in);

        if (!scanner.hasNextInt()) {
            scanner.close();
            return;
        }
        int m = scanner.nextInt();
        int n = scanner.nextInt();

        int[][] laberinto = new int[m][n];
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                laberinto[i][j] = scanner.nextInt();
            }
        }

        int[][] algBacktrack = solveBacktrack(laberinto, m, n);
        int[][] algByB = solveByB(laberinto, m, n);

        printMatriz(algBacktrack, m, n);
        System.out.println();
        printMatriz(algByB, m, n);

        scanner.close();
    }

    public static int[][] solveBacktrack(int[][] laberinto, int m, int n) {
        return algBacktrack(laberinto, m, n);
    }

    public static int[][] solveByB(int[][] laberinto, int m, int n) {
        return algByB(laberinto, m, n);
    }

    /**
     * Complejidad Backtracking (DFS)
     * Temporal: O(4^(M*N))
     * Espacial: O(M*N)
     */
    public static int[][] algBacktrack(int[][] laberinto, int m, int n) {
        int[][] solucion = new int[m][n];
        boolean[][] visitado = new boolean[m][n];

        if (laberinto[0][0] == 1) {
            auxBacktrack(laberinto, 0, 0, m, n, solucion, visitado);
        }
        return solucion;
    }

    private static boolean auxBacktrack(int[][] laberinto, int r, int c, int m, int n, int[][] solucion, boolean[][] visitado) {
        if (r == m - 1 && c == n - 1) {
            solucion[r][c] = 1;
            return true;
        }

        if (r >= 0 && r < m && c >= 0 && c < n && laberinto[r][c] == 1 && !visitado[r][c]) {
            visitado[r][c] = true;
            solucion[r][c] = 1;

            if (auxBacktrack(laberinto, r + 1, c, m, n, solucion, visitado)) return true;
            if (auxBacktrack(laberinto, r, c + 1, m, n, solucion, visitado)) return true;
            if (auxBacktrack(laberinto, r - 1, c, m, n, solucion, visitado)) return true;
            if (auxBacktrack(laberinto, r, c - 1, m, n, solucion, visitado)) return true;

            solucion[r][c] = 0;
            return false;
        }
        return false;
    }

    /**
     * Complejidad RAMIFICACIÓN Y PODA (BFS)
     * Temporal: O(M*N)
     * Espacial: O(M*N)
     */
    public static int[][] algByB(int[][] laberinto, int m, int n) {
        int[][] solucion = new int[m][n];
        if (laberinto[0][0] == 0 || laberinto[m - 1][n - 1] == 0) return solucion;

        boolean[][] visitado = new boolean[m][n];
        Nodo[][] padre = new Nodo[m][n];
        Queue<Nodo> cola = new LinkedList<>();

        Nodo inicio = new Nodo(0, 0);
        cola.add(inicio);
        visitado[0][0] = true;

        boolean found = false;
        int[] dr = {1, 0, -1, 0};
        int[] dc = {0, 1, 0, -1};

        while (!cola.isEmpty()) {
            Nodo actual = cola.poll();

            if (actual.r == m - 1 && actual.c == n - 1) {
                found = true;
                break;
            }

            for (int i = 0; i < 4; i++) {
                int nr = actual.r + dr[i];
                int nc = actual.c + dc[i];

                if (nr >= 0 && nr < m && nc >= 0 && nc < n && laberinto[nr][nc] == 1 && !visitado[nr][nc]) {
                    visitado[nr][nc] = true;
                    padre[nr][nc] = actual;
                    cola.add(new Nodo(nr, nc));
                }
            }
        }

        if (found) {
            int currR = m - 1;
            int currC = n - 1;
            while (currR != 0 || currC != 0) {
                solucion[currR][currC] = 1;
                Nodo p = padre[currR][currC];
                currR = p.r;
                currC = p.c;
            }
            solucion[0][0] = 1;
        }

        return solucion;
    }

    /*
     * Complejidad temporal: O(M * N)
     * Complejidad espacial: O(1)
     */
    private static void printMatriz(int[][] matriz, int m, int n) {
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                System.out.print(matriz[i][j] + (j == n - 1 ? "" : " "));
            }
            System.out.println();
        }
    }

    static class Nodo {
        int r, c;
        Nodo(int r, int c) {
            this.r = r;
            this.c = c;
        }
    }
}