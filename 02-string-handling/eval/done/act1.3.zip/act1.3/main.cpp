/*
 * main.cpp
 * Actividad 1.3 - Solucion de un laberinto
 *
 * Descripcion:
 *   Lee un laberinto de M x N casillas (0 = pared, 1 = libre) desde la
 *   entrada estandar y busca un camino desde la casilla (0,0) hasta la
 *   casilla (M-1, N-1). El problema se resuelve con dos tecnicas:
 *     1) Backtracking: primer camino que encuentra una busqueda en
 *        profundidad (DFS).
 *     2) Ramificacion y poda: camino mas corto, usando una cota inferior
 *        (distancia Manhattan) para podar ramas que no mejoran.
 *   Se imprime la matriz solucion de cada tecnica, separadas por una
 *   linea en blanco. Si no hay solucion, la matriz queda en ceros.
 *
 * Estudiante: René
 * Matricula: A01773558
 */

#include <iostream>
#include <vector>
#include <queue>
#include <cstdlib>

using namespace std;

int M;                             // numero de filas
int N;                             // numero de columnas
vector<vector<int>> laberinto;     // 1 = libre, 0 = pared
vector<vector<int>> solBT;         // solucion por backtracking
vector<vector<int>> solRP;         // solucion por ramificacion y poda

// Direcciones a explorar: abajo, derecha, arriba, izquierda.
const int dFila[4] = {1, 0, -1, 0};
const int dCol[4]  = {0, 1, 0, -1};

/*
 * Indica si (fila, col) esta dentro del laberinto y es transitable.
 * Complejidad: O(1)
 */
bool esValida(int fila, int col) {
    if (fila < 0 || fila >= M || col < 0 || col >= N) {
        return false;
    }
    return laberinto[fila][col] == 1;
}

/* ----------------------- BACKTRACKING ----------------------- */
/*
 * Busca un camino de (fila,col) a la meta marcando las casillas
 * Cuando una casilla no lleva a la salida, la desmarca (backtrack) y
 * regresa para probar otra direccion.
 *
 * Complejidad temporal: O(4^(M*N)) en el peor caso, ya que cada casilla
 *   puede ramificar hasta en 4 direcciones antes de podarse por visita.
 * Complejidad espacial: O(M*N) por la matriz solucion y la pila de
 *   recursion.
 */
bool resolverBacktracking(int fila, int col) {
    if (!esValida(fila, col)) {
        return false;
    }
    if (solBT[fila][col] == 1) { 
        return false;
    }

    solBT[fila][col] = 1;          // marcar casilla

    if (fila == M - 1 && col == N - 1) {   // llego a la meta
        return true;
    }

    for (int d = 0; d < 4; d++) {
        if (resolverBacktracking(fila + dFila[d], col + dCol[d])) {
            return true;
        }
    }

    solBT[fila][col] = 0;          // desmarcar casilla (backtrack)
    return false;
}

/* ------------------- RAMIFICACION Y PODA -------------------- */
/*
 * Cota inferior: distancia Manhattan de (fila,col) a la meta. Nunca
 * sobreestima los pasos que faltan, por lo que es una cota admisible.
 * Complejidad: O(1)
 */
int cotaInferior(int fila, int col) {
    return abs((M - 1) - fila) + abs((N - 1) - col);
}

struct Nodo {
    int fila;
    int col;
    int costo;   // pasos realizados desde el origen
    int cota;    // costo + cota inferior (se usa como prioridad)
};


struct Comparador {
    bool operator()(const Nodo &a, const Nodo &b) const {
        return a.cota > b.cota;
    }
};

/*
 * Encuentra el camino mas corto con ramificacion y poda:
 *   - Ramifica generando los nodos hijos (las 4 direcciones).
 *   - Acota cada nodo con costo + distancia Manhattan.
 *   - Poda los nodos cuya cota no mejora el mejor costo a la meta y los
 *     que llegan a una casilla con un costo peor al ya registrado.
 * El camino se reconstruye con la matriz de padres.
 *
 * Complejidad temporal: O(M*N * log(M*N))
 * Complejidad espacial: O(M*N) por las matrices auxiliares y la cola.
 */
void resolverRamificacionPoda() {
    const int INF = 1000000000;
    vector<vector<int>> mejorCosto(M, vector<int>(N, INF));
    vector<vector<pair<int, int>>> padre(M, vector<pair<int, int>>(N, {-1, -1}));

    priority_queue<Nodo, vector<Nodo>, Comparador> cola;
    int mejorMeta = INF;   // mejor costo encontrado para llegar a la meta

    if (esValida(0, 0)) {
        mejorCosto[0][0] = 0;
        cola.push({0, 0, 0, cotaInferior(0, 0)});
    }

    while (!cola.empty()) {
        Nodo actual = cola.top();
        cola.pop();

        if (actual.cota >= mejorMeta) {
            continue;
        }
        // Poda: ya llegamos a esta casilla con un costo mejor.
        if (actual.costo > mejorCosto[actual.fila][actual.col]) {
            continue;
        }

        if (actual.fila == M - 1 && actual.col == N - 1) {
            mejorMeta = actual.costo;
            continue;
        }

        for (int d = 0; d < 4; d++) {
            int nf = actual.fila + dFila[d];
            int nc = actual.col + dCol[d];
            if (!esValida(nf, nc)) {
                continue;
            }
            int nuevoCosto = actual.costo + 1;
            if (nuevoCosto >= mejorCosto[nf][nc]) {   // poda por costo
                continue;
            }
            int nuevaCota = nuevoCosto + cotaInferior(nf, nc);
            if (nuevaCota >= mejorMeta) {             // poda por cota
                continue;
            }
            mejorCosto[nf][nc] = nuevoCosto;
            padre[nf][nc] = {actual.fila, actual.col};
            cola.push({nf, nc, nuevoCosto, nuevaCota});
        }
    }

    // Reconstruir el camino si se llego a la meta.
    if (mejorMeta != INF) {
        int fila = M - 1;
        int col = N - 1;
        while (fila != -1 && col != -1) {
            solRP[fila][col] = 1;
            pair<int, int> p = padre[fila][col];
            fila = p.first;
            col = p.second;
        }
    }
}

/*
 * Imprime una matriz de 0 y 1 separados por un espacio.
 * Complejidad: O(M*N)
 */
void imprimirMatriz(const vector<vector<int>> &matriz) {
    for (int i = 0; i < M; i++) {
        for (int j = 0; j < N; j++) {
            cout << matriz[i][j];
            if (j < N - 1) {
                cout << ' ';
            }
        }
        cout << '\n';
    }
}

int main() {
    cin >> M >> N;

    laberinto.assign(M, vector<int>(N, 0));
    solBT.assign(M, vector<int>(N, 0));
    solRP.assign(M, vector<int>(N, 0));

    for (int i = 0; i < M; i++) {
        for (int j = 0; j < N; j++) {
            cin >> laberinto[i][j];
        }
    }

    resolverBacktracking(0, 0);
    resolverRamificacionPoda();

    imprimirMatriz(solBT);
    cout << '\n';
    imprimirMatriz(solRP);

    return 0;
}