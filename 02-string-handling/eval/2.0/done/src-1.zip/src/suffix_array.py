"""
ESTRUCTURAS DE DATOS: SUFFIX ARRAY Y LCP ARRAY (ALGORITMO DE KASAI)

1. Suffix Array (SA): Ordena alfabéticamente todos los sufijos de un texto.
2. LCP Array: Mide cuántas letras comparten en común los sufijos contiguos.
3. Búsqueda rápida: Encuentra un patrón en el texto mediante Búsqueda Binaria.
4. Subcadena repetida: Encuentra la secuencia repetida más larga.

COMPLEJIDAD:
- Construcción SA: O(n log n) en tiempo | O(n) en memoria
- Construcción LCP: O(n) en tiempo     | O(n) en memoria
- Buscar Patrón:   O(m log n) tiempo  | O(1) memoria extra
"""

from typing import List


def build_suffix_array(s: str) -> List[int]:
    """
    Construye el Suffix Array ordenando los sufijos por "duplicación de rango".
    
    Idea simple:
    - En vez de comparar letras una por una, asignamos un 'rango' (número) a cada sufijo.
    - En el paso k=1 comparamos de 1 en 1 letra.
    - En el paso k=2 comparamos bloques de 2 letras aprovechando los rangos anteriores.
    - En el paso k=4 comparamos bloques de 4, luego 8, 16... duplicando en cada iteración.
    """
    n = len(s)
    
    # PASO 1: Guardamos los índices originales [0, 1, 2, ..., n-1]
    sa = list(range(n))
    
    # PASO 2: El rango inicial de cada posición es simplemente el código ASCII de su letra
    rank = [ord(c) for c in s]
    
    k = 1  # Cantidad de caracteres que analizaremos en cada bloque (1, 2, 4, 8...)

    while True:
        # Función auxiliar para armar la "pareja de ordenamiento" de cada sufijo
        # Pareja = (Rango de la primera mitad, Rango de la segunda mitad)
        def key(i):
            rango_actual = rank[i]
            rango_siguiente = rank[i + k] if (i + k < n) else -1  # -1 si el sufijo ya terminó
            return (rango_actual, rango_siguiente)

        # PASO 3: Ordenamos los índices usando las parejas calculadas como criterio
        sa.sort(key=key)

        # PASO 4: Asignamos nuevos rangos numéricos (0, 1, 2...) según el nuevo orden
        tmp = [0] * n
        tmp[sa[0]] = 0
        for i in range(1, n):
            # Si el sufijo actual tiene la misma pareja que el anterior, conservan el mismo rango.
            # Si es mayor, le sumamos 1 al rango.
            mismo_rango = (key(sa[i]) == key(sa[i - 1]))
            tmp[sa[i]] = tmp[sa[i - 1]] if mismo_rango else tmp[sa[i - 1]] + 1
        
        rank = tmp

        # CONDICIÓN DE SALIDA:
        # Si el último elemento ya tiene el rango (n - 1), significa que TODOS
        # los rangos son únicos y el arreglo ya está completamente ordenado.
        if rank[sa[-1]] == n - 1 or k > n:
            break
            
        k *= 2  # Duplicamos el tamaño de bloque para la siguiente vuelta (1 -> 2 -> 4 -> 8...)

    return sa


def kasai_lcp(s: str, sa: List[int]) -> List[int]:
    """
    Calcula el arreglo LCP (Longest Common Prefix) usando el Algoritmo de Kasai.
    
    ¿Qué guarda lcp[i]?
    Guarda el número de letras idénticas al inicio entre el sufijo 'sa[i]' 
    y el sufijo anterior 'sa[i-1]'.
    """
    n = len(s)
    rank = [0] * n
    lcp = [0] * n
    h = 0  # Contador de letras consecutivas iguales

    # PASO 1: Invertimos el Suffix Array para saber rápido la posición en SA de cada sufijo
    # Ejemplo: rank[i] me dice en qué lugar del Suffix Array quedó el sufijo que empieza en 'i'
    for i, p in enumerate(sa):
        rank[p] = i

    # PASO 2: Recorremos los sufijos en su orden original en el texto (de izquierda a derecha)
    for i in range(n):
        pos_en_sa = rank[i]

        # El primer sufijo del SA (pos_en_sa == 0) no tiene ningún sufijo antes con qué compararse
        if pos_en_sa > 0:
            # 'j' es el índice de inicio del sufijo que está JUSTO ANTES en el Suffix Array
            j = sa[pos_en_sa - 1]

            # Avanzamos mientras las letras de ambos sufijos sigan siendo iguales
            while i + h < n and j + h < n and s[i + h] == s[j + h]:
                h += 1

            # Guardamos la cantidad de letras coincidentes
            lcp[pos_en_sa] = h

            # TRUCO DE KASAI: En el siguiente sufijo (i+1), el prefijo común solo puede
            # reducirse como máximo en 1. Así evitamos volver a comparar desde cero (O(n) total).
            if h > 0:
                h -= 1

    return lcp


def search_pattern(s: str, sa: List[int], pattern: str) -> List[int]:
    """
    Busca todas las posiciones donde aparece 'pattern' usando Búsqueda Binaria.
    
    Como los sufijos en el Suffix Array están ordenados alfabéticamente,
    todas las coincidencias del patrón quedan agrupadas en un bloque continuo.
    """
    n, m = len(s), len(pattern)
    if m == 0:
        return []

    # Función rápida para cortar el sufijo 'i' a la longitud del patrón
    def suffix_at(i: int) -> str:
        return s[sa[i]: sa[i] + m]

    # BÚSQUEDA 1: Encontrar el LÍMITE IZQUIERDO (el primer sufijo que coincide)
    lo, hi = 0, n
    while lo < hi:
        mid = (lo + hi) // 2
        if suffix_at(mid) < pattern:
            lo = mid + 1
        else:
            hi = mid
    left = lo  # Primer índice del rango donde aparece el patrón

    # BÚSQUEDA 2: Encontrar el LÍMITE DERECHO (el primer sufijo que ya supera al patrón)
    hi = n
    while lo < hi:
        mid = (lo + hi) // 2
        if suffix_at(mid) <= pattern:
            lo = mid + 1
        else:
            hi = mid
    right = lo  # Límite superior (exclusivo)

    # Devolvemos las posiciones reales del texto donde empieza el patrón, ordenadas
    return sorted(sa[left:right])


def longest_repeated_substring(s: str, sa: List[int], lcp: List[int]) -> str:
    """
    Encuentra la subcadena repetida más larga del texto.
    
    Regla: La respuesta está representada por el valor MÁXIMO dentro del LCP Array,
    ya que indica la mayor cantidad de letras repetidas entre dos sufijos.
    """
    if not lcp:
        return ""

    # PASO 1: Buscamos la posición que contiene el valor máximo en el LCP Array
    best_i = max(range(len(lcp)), key=lambda i: lcp[i])
    best_len = lcp[best_i]

    # Si el valor máximo es 0, no hay ninguna repetición
    if best_len == 0:
        return ""

    # PASO 2: Recuperamos el inicio del sufijo desde el Suffix Array y cortamos la cadena
    start = sa[best_i]
    return s[start: start + best_len]


if __name__ == "__main__":
    # EJECUCIÓN Y CASOS DE PRUEBA
    s = "banana"

    print("=== 1. CONSTRUCCIÓN DEL SUFFIX ARRAY ===")
    sa = build_suffix_array(s)
    print(f'Texto: "{s}"')
    print(f'Suffix Array: {sa}')
    # Explicación visual del SA:
    # 5 -> "a"
    # 3 -> "ana"
    # 1 -> "anana"
    # 0 -> "banana"
    # 4 -> "na"
    # 2 -> "nana"
    assert sa == [5, 3, 1, 0, 4, 2]

    print("\n=== 2. CONSTRUCCIÓN DEL LCP ARRAY ===")
    lcp = kasai_lcp(s, sa)
    print(f'LCP Array: {lcp}')
    assert lcp == [0, 1, 3, 0, 0, 2]

    print("\n=== 3. SUBCADENA REPETIDA MÁS LARGA ===")
    lrs = longest_repeated_substring(s, sa, lcp)
    print(f'Subcadena repetida más larga: "{lrs}" (Longitud: {max(lcp)})')
    assert lrs == "ana"

    print("\n=== 4. BÚSQUEDA DE PATRONES ===")
    matches = search_pattern(s, sa, "ana")
    print(f'Ocurrencias del patrón "ana" en los índices: {matches}')
    assert matches == [1, 3]

    print("\n✔ Todos los casos de prueba pasaron correctamente.")