"""
ALGORITMO DE HASHING DE CADENAS

COMPLEJIDAD:
1. Precómputo: O(n) en tiempo y espacio (hacemos una sola pasada sobre el texto).
2. Hash de cualquier subcadena: O(1) tiempo (operación matemática instantánea).
3. Rabin-Karp: O(n + m) tiempo total (compara el patrón en tiempo constante).
"""

from typing import List, Tuple


class StringHasher:
    """
    CLASE PRINCIPAL: Precomputa los hashes acumulados (prefijos).
    Esto nos permite 'cortar' y obtener el hash de cualquier subcadena en O(1).
    """

    def __init__(
        self,
        s: str,
        base1: int = 131,
        mod1: int = 10 ** 9 + 7,
        base2: int = 137,
        mod2: int = 10 ** 9 + 9,
    ):
        self.s = s
        self.n = len(s)
        self.mod1, self.mod2 = mod1, mod2

        # 1. Creamos las tablas para guardar los hashes acumulados y las potencias de las bases.
        self.h1 = [0] * (self.n + 1)
        self.h2 = [0] * (self.n + 1)
        self.p1 = [1] * (self.n + 1)
        self.p2 = [1] * (self.n + 1)

        # 2. PRECÓMPUTO EN O(n):
        # Recorremos la cadena letra por letra calculando el hash polinomial.
        for i, ch in enumerate(s):
            v = ord(ch) 
            
            self.h1[i + 1] = (self.h1[i] * base1 + v) % mod1
            self.h2[i + 1] = (self.h2[i] * base2 + v) % mod2
            
            self.p1[i + 1] = (self.p1[i] * base1) % mod1
            self.p2[i + 1] = (self.p2[i] * base2) % mod2

    def get_hash(self, l: int, r: int) -> Tuple[int, int]:
        """
        OBTENER HASH EN O(1):
        Calcula el hash del rango s[l:r] en tiempo constante usando la fórmula:
        Hash(l, r) = H[r] - H[l] * Base^(r - l)  (aplicando módulo)
        """
        h1 = (self.h1[r] - self.h1[l] * self.p1[r - l]) % self.mod1
        h2 = (self.h2[r] - self.h2[l] * self.p2[r - l]) % self.mod2
        return (h1, h2)

    def equal(self, l1: int, r1: int, l2: int, r2: int) -> bool:
        """
        COMPARACIÓN EN O(1):
        Verifica si dos subcadenas de la misma longitud son iguales comparando sus hashes.
        """
        # Si no miden lo mismo, no pueden ser iguales
        if (r1 - l1) != (r2 - l2):
            return False
        # Si sus hashes son idénticos, asumimos que el texto es idéntico
        return self.get_hash(l1, r1) == self.get_hash(l2, r2)


def rabin_karp_search(text: str, pattern: str) -> List[int]:
    """ Algoritmo de Búsqueda Rabin-Karp.
    Busca la posición de 'pattern' dentro de 'text' evaluando ventanas en O(1).
    """
    n, m = len(text), len(pattern)
    
    if m == 0 or m > n:
        return []

    hasher = StringHasher(text)
    pattern_hasher = StringHasher(pattern)
    target = pattern_hasher.get_hash(0, m)

    matches = []
    
    for i in range(n - m + 1):
        if hasher.get_hash(i, i + m) == target:
            # Si los hashes coinciden, confirmamos letra por letra para evitar falsos positivos
            if text[i:i + m] == pattern:
                matches.append(i)
                
    return matches


# PRUEBAS DE EJECUCIÓN
if __name__ == "__main__":
    print("=== 1. Demostración de Búsqueda con Rabin-Karp ===")
    texto = "abracadabra"
    patron = "abra"
    resultado = rabin_karp_search(texto, patron)
    print(f'Buscando "{patron}" en "{texto}": Coincidencias en índices {resultado}')
    assert resultado == [0, 7]

    print("\n=== 2. Demostración de Comparación en O(1) ===")
    h = StringHasher("abcabc")
    
    # Compara "abc" 
    r1 = h.equal(0, 3, 3, 6)
    # Compara "abc"
    r2 = h.equal(0, 3, 1, 4)
    
    print(f'¿Subcadena "abc" es igual a "abc"? -> {r1}')
    print(f'¿Subcadena "abc" es igual a "bca"? -> {r2}')
    assert r1 is True
    assert r2 is False

    print("\n¡Todas las demostraciones ejecutaron correctamente!")