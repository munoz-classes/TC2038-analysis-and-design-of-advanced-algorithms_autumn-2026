# Hash String — Suffix Array

**Equipo 5-8 · Análisis de Algoritmos Avanzados**

Implementación en Python 3 de dos técnicas para procesamiento de cadenas:

- **Hashing de cadenas** (rolling hash con doble módulo + Rabin-Karp) → `string_hasher.py`
- **Suffix Array** (Manber-Myers) + **LCP Array** (Kasai) → `suffix_array.py`

## Requisitos

- Python 3.8 o superior (no requiere librerías externas).

Verificar versión instalada:

```bash
python3 --version
```

## Estructura

```
src/
├── string_hasher.py   # StringHasher 
├── suffix_array.py    # build_suffix_array 
└── README.md
```

## Ejecución

Cada archivo se puede correr directamente; al hacerlo ejecuta su propia
demostración con los casos de prueba de la presentación y valida los
resultados con `assert`:

```bash
python3 string_hasher.py
python3 suffix_array.py
```

Salida esperada de `string_hasher.py`:

```
=== Rabin-Karp ===
rabin_karp_search("abracadabra", "abra") -> [0, 7]

=== StringHasher.equal ===
h.equal(0, 3, 3, 6) -> True   # "abc" vs "abc"
h.equal(0, 3, 1, 4) -> False   # "abc" vs "bca"

Todos los casos de prueba pasaron correctamente.
```

Salida esperada de `suffix_array.py`:

```
=== build_suffix_array ===
build_suffix_array("banana") -> [5, 3, 1, 0, 4, 2]

=== kasai_lcp ===
kasai_lcp("banana", sa) -> [0, 1, 3, 0, 0, 2]

=== longest_repeated_substring ===
longest_repeated_substring -> "ana"  (max(lcp) = 3)

=== search_pattern ===
search_pattern("banana", sa, "ana") -> [1, 3]

Todos los casos de prueba pasaron correctamente.
```

## Uso como módulo

```python
from string_hasher import StringHasher, rabin_karp_search
from suffix_array import build_suffix_array, kasai_lcp, search_pattern

# Hashing de cadenas
h = StringHasher("abcabc")
h.equal(0, 3, 3, 6)          # True  -> "abc" == "abc"
rabin_karp_search("abracadabra", "abra")   # [0, 7]

# Suffix array
sa = build_suffix_array("banana")          # [5, 3, 1, 0, 4, 2]
lcp = kasai_lcp("banana", sa)              # [0, 1, 3, 0, 0, 2]
search_pattern("banana", sa, "ana")        # [1, 3]
```

## Casos de prueba de ejemplo

| Función | Entrada | Salida esperada |
|---|---|---|
| `rabin_karp_search` | `("abracadabra", "abra")` | `[0, 7]` |
| `StringHasher("abcabc").equal` | `(0, 3, 3, 6)` | `True` |
| `StringHasher("abcabc").equal` | `(0, 3, 1, 4)` | `False` |
| `build_suffix_array` | `"banana"` | `[5, 3, 1, 0, 4, 2]` |
| `kasai_lcp` | `("banana", sa)` | `[0, 1, 3, 0, 0, 2]` |
| `search_pattern` | `("banana", sa, "ana")` | `[1, 3]` |

## Complejidad (resumen)

| Estructura | Construcción | Consulta |
|---|---|---|
| StringHasher (hash de prefijos) | O(n) | O(1) por subcadena |
| Rabin-Karp (búsqueda de patrón) | — | O(n + m) |
| Suffix Array (Manber-Myers) | O(n log n)* | — |
| LCP Array (Kasai) | O(n) | — |
| Búsqueda de patrón sobre SA | — | O(m log n) |
