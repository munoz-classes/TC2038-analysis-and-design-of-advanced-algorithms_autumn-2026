Paso 1: Abrir visual studio 2022.

Paso 2: Crear un nuevo proyecto de consola de c++.

Paso 3: Arrastrar el archivo Manacher.cpp a la solución.

Paso 4: Ejecutar.

