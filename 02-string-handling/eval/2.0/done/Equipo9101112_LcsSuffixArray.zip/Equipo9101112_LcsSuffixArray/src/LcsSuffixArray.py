"""
Enfoque: Suffix Array
Se busca encontrar la cadena de caracteres más larga identica y continua entre dos cadenas dadas.

Complejidad: O(n log n)

Equipos 9 al 12
06/09/26
"""


def longest_common_substring_sa(s1, s2):

    # 1. concatenamos con separadores unicos ('#' y '$')
    T = s1 + '#' + s2 + '$'
    n = len(T)
    len_s1 = len(s1)
    
    # 2. construimos Suffix Array (version simplificada y didactica)
    # se extraen todos los sufijos y los ordenamos alfabeticamente
    suffixes = [(T[i:], i) for i in range(n)]
    suffixes.sort(key=lambda x: x[0])
    sa = [idx for _, idx in suffixes] # se guardan solo los indices originales
    
    # 3. construimos Arreglo LCP usando Algoritmo de Kasai
    rank = [0] * n
    for i in range(n):
        rank[sa[i]] = i # diccionario de posiciones
        
    lcp = [0] * n
    h = 0
    for i in range(n):
        if rank[i] > 0:
            j = sa[rank[i] - 1] # vecino anterior en el Suffix Array
            # contamos cuntas letras coinciden
            while i + h < n and j + h < n and T[i + h] == T[j + h]:
                h += 1
            lcp[rank[i]] = h
            if h > 0:
                h -= 1 # optimizacion de Kasai
                
    # 4. encontrar el maximo LCP que provenga de cadenas distintas
    max_len = 0
    start_idx = 0
    
    for i in range(1, n):
        idx1, idx2 = sa[i - 1], sa[i]
        
        # validamos si los indices cruzaron el delimitador '#'
        cond1 = (idx1 < len_s1) and (idx2 > len_s1)
        cond2 = (idx1 > len_s1) and (idx2 < len_s1)
        
        if (cond1 or cond2) and lcp[i] > max_len:
            max_len = lcp[i]
            start_idx = idx1
            
    return T[start_idx : start_idx + max_len]



# Casos de prueba

print("Pruebas de Longest Common Substring (Suffix Array)\n")

# Caso 1: Cadenas estándar
s1_1, s1_2 = "PROGRAMAR", "GRAMATICA"
print(f"Caso 1: Cadenas estándar")
print(f"S1: {s1_1} | S2: {s1_2}")
print(f"Resultado LCS: '{longest_common_substring_sa(s1_1, s1_2)}'\n")

# Caso 2: Simulación Bioinformática
s2_1, s2_2 = "AGACCTAGGCATAA", "CTTGACCTAGGTCG"
print(f"Caso 2: Simulación Bioinformática")
print(f"S1: {s2_1} | S2: {s2_2}")
print(f"Resultado LCS: '{longest_common_substring_sa(s2_1, s2_2)}'\n")

# Caso 3: Cadenas sin coincidencia
s3_1, s3_2 = "MOUSE", "PANDA"
print(f"Caso 3: Sin caracteres en común")
print(f"S1: {s3_1} | S2: {s3_2}")
print(f"Resultado LCS: '{longest_common_substring_sa(s3_1, s3_2)}'\n")

# Caso 4: Inclusión total
s4_1, s4_2 = "UNIVERSIDAD", "IVERSI"
print(f"Caso 4: Inclusión total")
print(f"S1: {s4_1} | S2: {s4_2}")
print(f"Resultado LCS: '{longest_common_substring_sa(s4_1, s4_2)}'\n")
