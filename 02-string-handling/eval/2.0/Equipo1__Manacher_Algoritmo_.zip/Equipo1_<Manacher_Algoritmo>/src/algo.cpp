﻿#include <iostream>
#include <vector>

using namespace std;

constexpr char SEP = '#';

static string cadparaimpar(const string& cad) {
    string res = "" + SEP;
    for (char c : cad) {
        res += c;
        res += "#";
    }
    return res;
}

static void reconstruircad(string& cad, int centro, int longitud) {
    string res = "";
    if (cad[centro] != SEP) {
        res.push_back(cad[centro]);
    }
    for (int i = 1; i < longitud; i++) {
        char car = cad[centro + i];
        if (car != SEP) {
            res = car + res + car;
        }
    }
    cad = res;
}
// Fuerza bruta
static void mtd1(const string& cad) { // O(N^2)
    string tempcad = cadparaimpar(cad);
    int centro = 0, longitud = 0;
    if (tempcad.size() >= 3) {
        int* man = new int[tempcad.size()];
        for (int i = 0;i < tempcad.size();i++) {
            man[i] = 0;
            while (i - man[i] - 1 >= 0 && i + man[i] + 1 < tempcad.size() && tempcad[i - man[i] - 1] == tempcad[i + man[i] + 1]) { // La parte izquierda es i - man[i] - 1 y la parte derecha es i + man[i] + 1, buscar hasta donde sea palíndromo.
                man[i]++;
            }
            if (man[i] > longitud) {
                centro = i;
                longitud = man[i];
            }
        }
        delete[] man;
    }
    reconstruircad(tempcad,centro,longitud);
    cout << tempcad << "\n";
}
// Manacher
static void mtd2(const string& cad) { // O(N)
    string tempcad = cadparaimpar(cad);
    int centro = 0, longitud = 0;
    if (tempcad.size() >= 3) {
        int* man = new int[tempcad.size()];
        int mejorcentro = 0, mayorlong = 0; // C y R respectivamente

        for (int i = 0; i < tempcad.size(); i++) {
            if (i < mayorlong) {// Mientras i esté en el rango de mayorlong.
                man[i] = min(mayorlong - i, man[mejorcentro * 2 - i]); // Copiar el valor del gemelo con respecto a mejorcentro o la distancia de i a r según cual sea menor.
            }
            else {
                man[i] = 0; // Inicializar a 0.
            }
            while (i - man[i] - 1 >= 0 && i + man[i] + 1 < tempcad.size() && tempcad[i - man[i] - 1] == tempcad[i + man[i] + 1]) { // La parte izquierda es i - man[i] - 1 y la parte derecha es i + man[i] + 1, buscar hasta donde sea palíndromo.
                man[i]++;
            }
            if (man[i] > longitud) {
                centro = i;
                longitud = man[i];
            }
            if (i + man[i] > mayorlong) { // Establecer el nuevo centro con su limite sí el palindromo revisado resultó ser más grande.
                mayorlong = i + man[i];
                mejorcentro = i;
            }
        }
        delete[] man;
    }
    reconstruircad(tempcad, centro, longitud);
    cout << tempcad << "\n";
}

int main()
{
    string cad = "ABABABABC";
    //string cad = "CCCCAADDAACCCE";
    cout << "mtd1 : \n";
    mtd1(cad);
    cout << "mtd2 : \n";
    mtd2(cad);
}