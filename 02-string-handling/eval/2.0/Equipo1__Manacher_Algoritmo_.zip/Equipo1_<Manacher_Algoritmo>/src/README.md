# Algoritmo de Manacher - Encontrar el Palíndromo Más Largo
Este proyecto contiene la implementación en C++ de dos algoritmos para encontrar la subcadena palindrómica más larga dentro de una cadena de texto dada:
1. `mtd1` (Fuerza Bruta / Expand Around Center): Enfoque con complejidad temporal de $\mathcal{O}(N^2)$.
2. `mtd2` (algoritmo de manacher): Enfoque optimizado mediante simetría especular con complejidad temporal de $\mathcal{O}(N)$.

---
## Requisitos del Sistema
Para compilar y ejecutar este programa se requiere:
- Compilador C++: `g++` (GNU C++ Compiler), `clang++` o MSVC con soporte para C++11 o superior (debido al uso de `constexpr`).
- Sistema Operativo: Compatible con Linux, macOS y Windows.
---
## Compilación y Ejecución
### Opción 1: Usando `g++` Terminal 
1. Compilar el archivo fuente:
   ```bash
   g++ -std=c++11 -O2 algo.cpp -o manacher
   ```
   *(El flag `-O2` es opcional pero recomendado para aplicar optimizaciones del compilador).*

2. **Ejecutar el programa:**
   - **En Linux / macOS:**
     ```bash
     ./manacher
     ```
   - **En Windows (CMD / PowerShell):**
     ```cmd
     manacher.exe
     ```

### Opción 2: Usando IDEs (Visual Studio, Code::Blocks, CLion, VS Code)
1. Abrir o incluir el archivo `algo.cpp` dentro del proyecto C++.
2. Asegurar que el estándar del lenguaje esté configurado en **C++11** o superior.
3. Compilar y ejecutar mediante la interfaz del IDE (`Build & Run` o `F5`).
---
## Casos de Prueba de Ejemplo

A continuación se presentan varios casos de prueba para validar el comportamiento del programa, indicando la entrada dada y la salida esperada en ambas funciones (`mtd1` y `mtd2`).

| ID | Cadena de Entrada (`cad`) | Salida Esperada (`mtd1` / `mtd2`) | Descripción / Tipo de Caso |
|:--:|:-------------------------|:---------------------------------|:---------------------------|
| **1** | `"ABABABABC"` | `ABABABA` | Palíndromo impar largo en patrón repetitivo. |
| **2** | `"CCCCAADDAACCCE"` | `CCCAADDAACCC` | Palíndromo de longitud par con repeticiones de caracteres. |
| **3** | `"babad"` | `bab` *(o `aba`)* | Caso de longitud impar. |
| **4** | `"cbbd"` | `bb` | Caso con palíndromo centrado en longitud par. |
| **5** | `"racecar"` | `racecar` | La cadena completa es un palíndromo impar. |
| **6** | `"noon"` | `noon` | La cadena completa es un palíndromo par. |
| **7** | `"abcdef"` | `a` *(o cualquier letra)* | Caso borde: Sin palíndromos mayores a 1 caracter. |
| **8** | `"a"` | `a` | Caso borde: Cadena de un único caracter. |

---
## Comparativa de Rendimiento (Complejidad)
| Algoritmo | Complejidad Temporal (Peor Caso) | Complejidad Espacial | Descripción |
| :--- | :---: | :---: | :--- |
| **`mtd1`** | $\mathcal{O}(N^2)$ | $\mathcal{O}(N)$ | Expande simétricamente desde cada centro sin reutilizar información previa. |
| **`mtd2`** | $\mathcal{O}(N)$ | $\mathcal{O}(N)$ | **Manacher:** Aprovecha la simetría de palíndromos previos para omitir redundancias. |

---

## Nota sobre la Estructura de Salida
El programa realiza la intercalación de separadores `#` para unificar el procesamiento de palíndromos pares e impares, y posteriormente reconstruye la cadena limpia mediante la función `reconstruircad`, imprimiendo el palíndromo obtenido directamente en consola.