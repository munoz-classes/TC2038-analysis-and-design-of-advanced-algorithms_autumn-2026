/*
 * Descripción: Tarea de implementación de Hash String por columnas
 * Lee un archivo, lo acomoda en una matriz lógica de n columnas,
 * rellena con n si no es múltiplo, y calcula la suma modular % 256SS
 * Autores: Jacquelin Velazquez Ramirez, A01773495 y Leonardo Rulfo Soto, A01773729
 * Fecha: 13 de septiembre de 2026
 */

#include <iostream>
#include <fstream>
#include <vector>
#include <string>

using namespace std;

/*
 * Función: imprimirHexadecimal
 * Propósito: Convierte un numero de 0 a 255 a hexadecimal de 2 digitos en mayúsculas
 * Parámetros: valor (entero entre 0 y 255)
 * Retorno: void
 * Complejidad: O(1) ya que solo procesa dos digitos
 */
void imprimirHexadecimal(int valor) {
    string digitosHex = "0123456789ABCDEF";
    int primerDigito = valor / 16;
    int segundoDigito = valor % 16;

    cout << digitosHex[primerDigito] << digitosHex[segundoDigito];
}

/*
 * Función: calcularHash
 * Propósito: Suma los valores ASCII acumulados por columna y muestra el hash en pantalla
 * Parámetros: texto (vector con caracteres leidos), n (numero de columnas)
 * Retorno: void
 * Complejidad: O(C), donde C es la cantidad total de caracteres (incluyendo el relleno)
 */
void calcularHash(const vector<int>& texto, int n) {
    vector<int> sumaColumnas(n, 0);
    int total = texto.size();
    int columna = 0;

    for (int i = 0; i < total; i = i + 1) {
        columna = i % n;
        sumaColumnas[columna] = (sumaColumnas[columna] + texto[i]) % 256;
    }

    for (int j = 0; j < n; j = j + 1) {
        imprimirHexadecimal(sumaColumnas[j]);
    }
    cout << endl;
}

/*
 * Función: main
 * Propósito: Punto de entrada. Lee parametros, procesa el archivo caracter por caracter
 * y aplica el relleno con el valor de n si es necesario
 * Retorno: 0 si concluye con exito
 * Complejidad: O(L), donde L es la longitud del archivo de texto
 */
int main() {
    string nombreArchivo = "";
    int n = 0;
    ifstream archivo;
    char caracter = '\0';
    vector<int> caracteres;
    int residuo = 0;
    int relleno = 0;

    cin >> nombreArchivo >> n;
    archivo.open(nombreArchivo);

    if (archivo.is_open()) {
        while (archivo.get(caracter)) {
            caracteres.push_back((int)caracter);
        }
        archivo.close();

        residuo = caracteres.size() % n;
        if (residuo != 0) {
            relleno = n - residuo;
            for (int i = 0; i < relleno; i = i + 1) {
                caracteres.push_back(n);
            }
        }

        calcularHash(caracteres, n);
    } else {
        cout << "Error: no se pudo abrir el archivo." << endl;
    }

    return 0;
}
