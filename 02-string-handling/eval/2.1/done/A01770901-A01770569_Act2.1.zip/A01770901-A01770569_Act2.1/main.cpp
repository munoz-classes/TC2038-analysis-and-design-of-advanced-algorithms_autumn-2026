/*
 * Programa: Implementacion de Hash String mediante suma de ASCII por columnas.
 * Nombres: Tabata Carolina Salinas Valdez / Alexandra Melgar
 * Matricula: A01770901 / A01770569
 * Fecha de creacion: 10/09/2026
 */

#include <fstream>
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>

using namespace std;

/*
 * Proposito:
 * Calcula el valor hash de un archivo sumando los valores ASCII de cada
 * columna y aplicando modulo 256. El ultimo renglon se completa con n.
 * Parametros:
 * archivo: Nombre del archivo de texto que se procesara.
 * n: Cantidad de columnas de la tabla.
 * Retorno:
 * Retorna un vector con n valores hash entre 0 y 255.
 * Complejidad:
 * O(m + n), m es la cantidad de caracteres del archivo.
 */
vector<int> calcularHash(const string& archivo, int n)
{
	ifstream entrada(archivo, ios::binary);
	vector<int> valores(n, 0);
	char caracter = '\0';
	int posicion = 0;
	int caracteres = 0;
	while (entrada.get(caracter))
	{
		unsigned char byte = static_cast<unsigned char>(caracter);
		valores[posicion] = (valores[posicion] + byte) % 256;
		posicion = (posicion + 1) % n;
		caracteres++;
	}
	int restantes = caracteres % n;
	if (restantes != 0)
	{
		for (int i = restantes; i < n; i++)
		{
			valores[i] = (valores[i] + n) % 256;
		}
	}
	return valores;
}

/*
 * Proposito:
 * Muestra los valores hash en hexadecimal, usando dos digitos y mayusculas.
 * Parametros:
 * valores: Vector que contiene los valores hash.
 * Retorno:
 * No retorna ningun valor.
 * Complejidad:
 * O(n), n es la cantidad de valores hash.
 */
void mostrarHash(const vector<int>& valores)
{
	cout << uppercase << hex << setfill('0');
	for (int valor : valores)
	{
		cout << setw(2) << valor;
	}
	cout << endl;
}

/*
 * Proposito:
 * Leer el nombre del archivo y el numero de columnas, calcular el hash
 * y muestra el resultado.
 * Parametros: No hay
 * Retorno:
 * 0 cuando el programa termina correctamente y 1 si no se puede abrir el archivo o si n no cumple con las restricciones indicadas.
 * Complejidad:
 * O(m + n), m es la cantidad de caracteres.
 */
int main()
{
	string archivo = "";
	int n = 0;
	cin >> archivo >> n;
	if (n < 16 || n > 64 || n % 4 != 0)
	{
		return 1;
	}
	ifstream prueba(archivo, ios::binary);
	if (!prueba.is_open())
	{
		return 1;
	}
	prueba.close();
	vector<int> valores = calcularHash(archivo, n);
	mostrarHash(valores);
	return 0;
}