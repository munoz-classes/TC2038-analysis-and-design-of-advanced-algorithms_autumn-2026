/*
Hash de archivo de texto: genera una huella hexadecimal de un archivo.
Lee desde la entrada estandar el nombre de un archivo de texto y un entero N
(multiplo de 4, con 16 <= n <= 64). Acomoda los caracteres del archivo
(incluyendo saltos de linea) en una tabla de N columnas, llenando renglon por
renglon. Si el total de caracteres no es multiplo de N, el ultimo renglon se
rellena con el valor de n. Para cada columna, calcula la suma de los codigos 
ASCII modulo 256, y concatena la representacion hexadecimal de dos digitos en
mayusculas de cada valor para formar el hash final.

Nota importante sobre el enunciado en Canvas:
Las instruccioens nos indican que la salida tiene longitud n/4, pero tambien pide
concatenar dos digitos hexadecimales por cada una de las N posiciones del arreglo,
lo que produce una salida de 2*n digitos. Ambas afirmaciones son matematicamente
incompatibles. Se opto por seguir la mecanica detallada (arreglo de longitud N, dos
digitos por posicion), por estar descrita con mayor precision, generando
una salida de 2*n caracteres.

Autores: 
    Iker Octavio Silva Campos - A01770545
    Alberto Guillen Rayas - A01770565
Fecha de creacion: 12 de septiembre de 2026

Complejidad computacional: O(L + N), en donde L es el numero de caracteres del archivo
y N el numero de columnas. El archivo se recorre una sola vez sin almacenarlo completo
en memoria; los recorridos del arreglo son de tamano N. Como N esta acotado (maximo 64),
en la practica domina L: el algoritmo es lineal respecto al tamano del archivo.
*/

#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <iomanip>

int main(){
    std::string nombreArchivo;
    std::cin >> nombreArchivo;
    int n = 0;
    std::cin >> n;
    std::ifstream archivo(nombreArchivo);
    std::vector<int> a(n, 0);
    int k = 0;
    //Lee el archivo caracter por caracter y suma cada codigo ASCII a la
    //columna que le corresponde segun su posicion (k % n).
    char c;
    while (archivo.get(c)){
        a[k % n] = a[k % n] + c;
        k++;
    }
    //Rellena las columnas faltantes del ultimo renglon con el valor N.
    int faltantes = 0;
    if (k % n != 0){
        faltantes = n - (k % n);
    }
    for (int r = 0; r < faltantes; r++){
        a[k % n] = a[k % n] + n;
        k++;
    }
    //Aplica modulo 256 a cada columna para que quepa en dos digitos hex.
    for (int i = 0; i < n; i++){
        a[i] = a[i] % 256;
    }
    //Concatena la representacion hexadecimal de dos digitos en mayusculas.
    std::cout << std::uppercase << std::setfill('0');
    for (int i = 0; i < n; i++){
        std::cout << std::setw(2) << std::hex << a[i];
    }
    std::cout << std::endl;
    return 0;
}

/*
CASOS DE PRUEBA
Todos con N = 16, salida de 32 caracteres hexadecimales

Caso 1 (texto corto, mucho relleno):
    Archivo: contiene "HOLA" (4 caracteres)
    Salida: 484F4C41101010101010101010101010

Caso 2 (texto que llena exacto los espacios, sin relleno):
    Archivo: contiene "unodostrescuatro" (16 caracteres)
    Salida: 756E6F646F737472657363756174726F

Caso 3 (relleno parcial, columnas con multiples caracteres):
    Archivo: contiene "unodostrescuatrocinco" (21 caracteres)
    Salida: D8D7DDC7DE838482758373857184827F

Caso 4 (modulo 256 en accion, columnas con tres caracteres):
    Archivo: contiene 40 veces la letra "a"
    Salida: 2323232323232323D2D2D2D2D2D2D2D2

Caso 5 (archivo vacio, caso borde):
    Archivo: existe pero sin contenido (0 caracteres)
    Salida: 00000000000000000000000000000000

Caso 6 (archivo inexistente, caso borde):
    Archivo: el nombre no corresponde a ningun archivo real
    Salida: 00000000000000000000000000000000
    Nota: al no poder abrirse, no se leen caracteres; el arreglo queda en
    ceros. Se opto por este comportamiento en vez de un mensaje de error para
    no alterar el formato de salida.
*/