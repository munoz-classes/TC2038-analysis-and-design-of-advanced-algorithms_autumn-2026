﻿/*Actividad 2.1 Implementación de "Hash String".
Codigo escrito por: José Pedro Rodríguez Munguía | A01769631 Santiago Chávez Robles | A01770514*/
#include <iostream>
#include <fstream>
#include <filesystem>
using namespace std;

// Funcion que acomoda los caracteres del archivo en columnas de longitud n.
// Cada posicion del arreglo representa una columna de la tabla.
// Si el ultimo renglon no llena exactamente n columnas, se rellena con n.
int acomodarCaracteres(const string& nombreArchivo, int n) {
    ifstream archivo(nombreArchivo);
    if (!archivo.is_open()) {
        return 0;
    }

    char caracter;
    int a[n] = {};
    int totalCaracteres = 0;

    // Se recorre el archivo caracter por caracter con i % n.
    for (int i = 0; archivo.get(caracter); i++) {
        a[i % n] = a[i % n] + static_cast<unsigned char>(caracter);

        totalCaracteres++;
    }

    // Si no se completa un renglon, se rellena con el valor de n.
    if (totalCaracteres % n != 0) {
        int resto = totalCaracteres % n;
        for (int i = resto; i < n; i++) {
            a[i] += n;
        }
    }

    // Se normaliza cada valor para que quede en el rango de 0 a 255.
    for (int i = 0; i < n; i++) {
        a[i] %= 256;
    }

    // Se convierte cada valor a hexadecimal de 2 digitos y se concatena.
    string hexDigits = "0123456789ABCDEF";
    string resultado = "";
    for (int i = 0; i < n; i++) {
        resultado = resultado + hexDigits[a[i] / 16];
        resultado = resultado + hexDigits[a[i] % 16];
    }

    // Debido a que cada posicion produce 2 digitos hexadecimales, su resultado longitud 2*n.
    cout << resultado << endl;

    return 0;
}

int main() {
    /*Codigo para ejecutar en Windows:
    g++ main.cpp -o main.exe
    cmd /c "main.exe < in.txt"
    */

    /*
    Orden de las entradas:
    - Nombre del archivo.
    - n, que debe ser un entero multiplo de 4 y estar en el rango [16, 64].
    */

    string nombreArchivo;
    int n;

    cin >> nombreArchivo;

    // Verificacion de la existencia del archivo.
    if (filesystem::exists(nombreArchivo) == false) {
        cout << "El archivo no existe" << endl;
        return 0;
    }

    cin >> n;

    // Verificacion de que n sea dentro del rango deseado y sea multiplo de 4.
    if (n < 16 or n > 64 or n % 4 != 0) {
        cout << "n no es valido" << endl;
        return 0;
    }

    cout << "Output del programa:" << endl;
    acomodarCaracteres(nombreArchivo, n);
    return 0;
}

