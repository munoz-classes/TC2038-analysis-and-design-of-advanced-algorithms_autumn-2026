/*
 * Descripcion: Calcula un hash hexadecimal de un archivo de texto.
 * Autor: Maria Fernanda Valdovinos Manon - A01773977
 * Fecha de creacion/modificacion: 13/09/2026
 */

#include <fstream>
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>

using namespace std;

/*
 * Lee los caracteres del archivo.
 * Parametro fileName: nombre del archivo.
 * Parametro characters: vector donde se guardan los caracteres.
 * Retorno: true si el archivo se pudo abrir; false si no.
 */
bool readFile(string fileName, vector<unsigned char>& characters) {
	ifstream file(fileName, ios::binary);
	char character;

	if (!file) {
		return false;
	}

	while (file.get(character)) {
		characters.push_back(static_cast<unsigned char>(character));
	}

	return true;
}

/*
 * Completa el ultimo renglon con el valor de n.
 * Parametro characters: caracteres del archivo.
 * Parametro n: numero de columnas.
 * Retorno: no retorna valor.
 */
void fillLastRow(vector<unsigned char>& characters, int n) {
	while (characters.size() % n != 0) {
		characters.push_back(static_cast<unsigned char>(n));
	}
}

/*
 * Calcula la suma de cada columna modulo 256.
 * Parametro characters: caracteres del archivo.
 * Parametro n: numero de columnas.
 * Retorno: arreglo con el resultado de cada columna.
 */
vector<int> calculateHash(const vector<unsigned char>& characters, int n) {
	vector<int> hash(n, 0);

	for (size_t i = 0; i < characters.size(); i++) {
		int column = i % n;
		hash[column] = (hash[column] + characters[i]) % 256;
	}

	return hash;
}

/*
 * Imprime los valores del hash en hexadecimal.
 * Parametro hash: valores calculados para cada columna.
 * Retorno: no retorna valor.
 */
void printHash(const vector<int>& hash) {
	for (int value : hash) {
		cout << uppercase << hex << setw(2) << setfill('0') << value;
	}

	cout << endl;
}

/*
 * Funcion principal del programa.
 * Retorno: 0 si termina correctamente; 1 si existe un error.
 */
int main() {
	string fileName;
	int n = 0;

	cin >> fileName >> n;

	if (!cin || n < 16 || n > 64 || n % 4 != 0) {
		return 1;
	}

	vector<unsigned char> characters;

	if (!readFile(fileName, characters)) {
		return 1;
	}

	fillLastRow(characters, n);

	vector<int> hash = calculateHash(characters, n);

	printHash(hash);

	return 0;
}
