ENTREGA HASH EN C++

Archivos:
- main.cpp
- CASOS_DE_PRUEBA.txt

Compilacion en Linux:
g++ -Wall -Wextra -pedantic main.cpp -o a.out

Ejecucion:
./a.out < entrada.txt

La entrada.txt debe contener el nombre del archivo y n. Ejemplo:

texto.txt 16

El programa lee el archivo incluyendo los saltos de linea, completa el ultimo renglon
cuando es necesario y calcula el hash por columnas.

Complejidad:
Tiempo: O(L + n)
Memoria: O(L + n)

L es el numero de caracteres del archivo y n es el numero de columnas.
