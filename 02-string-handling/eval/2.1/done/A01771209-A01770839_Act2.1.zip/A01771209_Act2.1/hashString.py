"""
Enfoque: Hash String
Implementación de un hash para cadenas de texto, basado en la suma de valores ASCI de los caracteres
    y su distribución en una tabla de tamaño n.

Complejidad: O(L)
    donde L es la longitud, el numero de caracteres del archivo txt

Propósito: Calcula una representación hash de un archivo de texto leyendo sus caracteres, 
    convirtiéndolos a ASCII, y sumándolos en columnas utilizando módulo 256.

Parámetros:
    nombreTxt: cadena de texto que indica la ruta o nombre del archivo a procesar.
    n: entero múltiplo de 4 (entre 16 y 64) que define el número de columnas de la tabla.

Retorno:
    Lista 'a' de longitud n con la suma modular de cada columna.
        El retorno es de longitud n y no n/4, ya que no se encontro ninguna regla o restriccion
        para poder reducirlo, asi que se considera como un error en la tarea.

Kiara Hermann San Lucas | A01771209
Fátima Montserrat Herrera González | A01770839
10/09/26
"""

def hashString(nombreTxt, n):

    # validar n entre dentro de las restricciones
    if not (16 <= n <= 64) or n % 4 != 0:
        print("Error: n debe ser multiplo de 4 yestar entre 16 y 64")
        return None

    # leer el archivo
    with open(nombreTxt, 'r', encoding='utf-8') as file:
        contenido = file.read()

    # convertir cada caracter a su valor en asci
    valAsci = [ord(caracter) for caracter in contenido]

    # ver si se necesita rellenar espacios en la tabla
    faltantes = len(valAsci) % n
    if faltantes != 0 or len(valAsci) == 0: 
        # si es un archivo vacio, los espacios faltantes deben de ser n, sino n - faltantes
        espaciosFaltantes = n if len(valAsci) == 0 else n - faltantes
        valAsci.extend([n] * espaciosFaltantes) # rellenar valor con n

    # Arreglo "a" y la suma por columnas 
    a = [0] * n
    for i, valor in enumerate(valAsci):
        colActual = i % n
        a[colActual] = (a[colActual] + valor) % 256 # sumamos asci y hacemos modulo 256

    # se convierte la lista de "a", a una cadena siendo hexadecimal
    # :02x es para que el numero siempre sea de dos caracteres (ej. 0 -> 00, 10 -> 0a)
    hashHexadecimal = "".join(f"{numero:02x}" for numero in a)

    return hashHexadecimal


# PRUEBAS
# A continuacion, se crean archivos temporales, ejecuta la funcion y muestra los resultados

def ejecutar_pruebas():
    print("--- INICIANDO CASOS DE PRUEBA ---\n")
    
    # Caso 1: Normal (Múltiplo exacto)
    # Archivo con exactamente 16 caracteres, n = 16. No debe haber relleno.
    with open("prueba1.txt", "w", encoding='utf-8') as f: 
        f.write("1234567890abcdef")
    print("Caso 1: Múltiplo exacto (16 caracteres, n=16)")
    print("Esperado: Cadena Hexadecimal de 16 elementos sin padding.")
    print("Obtenido:", hashString("prueba1.txt", 16), "\n")

    # Caso 2: Extremo de Relleno (Padding)
    # Archivo con 17 caracteres, n = 64. Debe rellenar 47 espacios con el valor 64.
    with open("prueba2.txt", "w", encoding='utf-8') as f: 
        f.write("1234567890abcdefg")
    print("Caso 2: Padding extremo (17 caracteres, n=64)")
    print("Esperado: Cadena Hexadecimal de 64 elementos, los últimos 47 calculados con el valor 64.")
    print("Obtenido:", hashString("prueba2.txt", 64), "\n")

    # Caso 3: Límite Inferior (Fallo de validación)
    # Valor de n = 12, lo cual está fuera de la restricción (16 <= n <= 64).
    with open("prueba3.txt", "w", encoding='utf-8') as f: 
        f.write("Hola mundo")
    print("Caso 3: Límite inferior (n=12)")
    print("Esperado: Mensaje de error por restricciones y retorno None.")
    print("Obtenido:", hashString("prueba3.txt", 12), "\n")

    # Caso 4: Archivo Vacío
    # Archivo sin texto (0 caracteres), n = 16. Debe rellenar toda la primera fila.
    with open("prueba4.txt", "w", encoding='utf-8') as f: 
        f.write("")
    print("Caso 4: Archivo vacío (0 caracteres, n=16)")
    print("Esperado: Cadena Hexadecimal de 16 elementos, calculados íntegramente con el relleno 16.")
    print("Obtenido:", hashString("prueba4.txt", 16), "\n")

# Punto de entrada del script
if __name__ == "__main__":
    ejecutar_pruebas()