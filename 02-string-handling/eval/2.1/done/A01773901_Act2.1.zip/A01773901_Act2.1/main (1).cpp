// Programa: Hash de un archivo de texto mediante suma de columnas en una
// tabla de n columnas, con posterior plegado en 4 grupos.
// Nombre: Alessandro Daturi Miranda (A01773901)
// Fecha: 13/09/2026

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <iomanip>

const int N_MINIMO = 16;
const int N_MAXIMO = 64;
const int N_MULTIPLO_DE = 4;
const int MODULO_BYTE = 256;
const int GRUPOS_DE_PLEGADO = 4;

// Lee todo el contenido de un archivo en modo binario, preservando cada
// byte tal cual esta en disco (incluye saltos de linea).
// Parametros:
//   rutaArchivo: ruta del archivo que se desea leer.
//   contenido: cadena de salida donde se guarda el contenido leido.
// Retorno: true si el archivo se pudo abrir y leer, false en caso contrario.
// Complejidad: O(L), donde L es el tamanio del archivo en bytes.
bool leerArchivoCompleto(const std::string& rutaArchivo, std::string& contenido) {
	std::ifstream archivo(rutaArchivo, std::ios::binary);
	if (!archivo.is_open()) {
		return false;
	}

	std::ostringstream bufer;
	bufer << archivo.rdbuf();
	contenido = bufer.str();
	return true;
}

// Agrega caracteres de relleno al final del contenido para que su longitud
// total sea multiplo de n. El caracter de relleno usado es el que tiene
// como codigo ASCII el propio valor de n.
// Parametros:
//   contenido: contenido original del archivo.
//   n: numero de columnas de la tabla (tambien es el codigo ASCII de relleno).
// Retorno: una nueva cadena con el relleno necesario ya agregado.
// Complejidad: O(L + n), copia el contenido (O(L)) y agrega a lo mas n - 1
// caracteres de relleno (O(n)).
std::string rellenarHastaMultiploDeN(const std::string& contenido, int n) {
	std::string contenidoRellenado = contenido;
	std::size_t longitud = contenidoRellenado.size();
	std::size_t residuo = longitud % n;

	if (residuo != 0) {
		std::size_t faltantes = n - residuo;
		char caracterRelleno = static_cast<char>(n);
		contenidoRellenado.append(faltantes, caracterRelleno);
	}

	return contenidoRellenado;
}

// Recorre el contenido ya rellenado (cuya longitud es multiplo de n) y
// acumula, para cada una de las n columnas, la suma de los codigos ASCII
// de los caracteres que caen en esa columna.
// Parametros:
//   contenidoRellenado: contenido del archivo ya rellenado a multiplo de n.
//   n: numero de columnas de la tabla.
// Retorno: arreglo de n posiciones con la suma modulo 256 de cada columna.
// Complejidad: O(L'), donde L' es la longitud del contenido rellenado
// (un solo recorrido lineal, acceso O(1) a cada acumulador).
std::vector<long long> calcularSumasPorColumna(const std::string& contenidoRellenado, int n) {
	std::vector<long long> sumasColumnas(n, 0);

	for (std::size_t indice = 0; indice < contenidoRellenado.size(); ++indice) {
		std::size_t columna = indice % n;
		unsigned char valorAscii = static_cast<unsigned char>(contenidoRellenado[indice]);
		sumasColumnas[columna] += valorAscii;
	}

	for (std::size_t columna = 0; columna < sumasColumnas.size(); ++columna) {
		sumasColumnas[columna] %= MODULO_BYTE;
	}

	return sumasColumnas;
}

// Pliega el arreglo de n sumas de columna en un arreglo final de n/4
// posiciones: la posicion k se obtiene sumando (modulo 256) las columnas
// k, k + n/4, k + 2n/4 y k + 3n/4.
// Parametros:
//   sumasColumnas: arreglo de n sumas de columna (una por columna).
//   n: numero de columnas original de la tabla.
// Retorno: arreglo final de n/4 posiciones con el resultado del plegado.
// Complejidad: O(n), cada una de las n/4 posiciones finales realiza un
// numero constante (4) de sumas.
std::vector<int> plegarSumasEnGrupos(const std::vector<long long>& sumasColumnas, int n) {
	int longitudGrupo = n / N_MULTIPLO_DE;
	std::vector<int> arregloFinal(longitudGrupo, 0);

	for (int k = 0; k < longitudGrupo; ++k) {
		long long total = 0;
		for (int grupo = 0; grupo < GRUPOS_DE_PLEGADO; ++grupo) {
			total += sumasColumnas[k + grupo * longitudGrupo];
		}
		arregloFinal[k] = total % MODULO_BYTE;
	}

	return arregloFinal;
}

// Convierte cada elemento del arreglo final a su representacion
// hexadecimal en mayusculas de 2 digitos (con cero a la izquierda si hace
// falta) y concatena todo en una sola cadena.
// Parametros:
//   arregloFinal: arreglo de n/4 posiciones producido por el plegado.
// Retorno: cadena con la representacion hexadecimal concatenada.
// Complejidad: O(m), donde m es la longitud del arreglo final (n/4).
std::string generarCadenaHexadecimal(const std::vector<int>& arregloFinal) {
	std::ostringstream salida;
	salida << std::uppercase << std::hex << std::setfill('0');

	for (std::size_t indice = 0; indice < arregloFinal.size(); ++indice) {
		salida << std::setw(2) << arregloFinal[indice];
	}

	return salida.str();
}

// Valida que n cumpla las restricciones del problema.
// Parametros:
//   n: valor a validar.
// Retorno: true si n es multiplo de 4 y esta entre 16 y 64, false si no.
// Complejidad: O(1).
bool esNValido(int n) {
	bool esMultiplo = n % N_MULTIPLO_DE == 0;
	bool estaEnRango = n >= N_MINIMO && n <= N_MAXIMO;
	return esMultiplo && estaEnRango;
}

// Orquesta la lectura de entrada, el calculo del hash y la impresion del
// resultado.
// Parametros: ninguno (la entrada se toma de la entrada estandar).
// Retorno: 0 si el programa termina correctamente, 1 si ocurre un error.
// Complejidad: O(L + n), donde L es el tamanio del archivo de entrada
// (dominante en la practica, ya que n <= 64).
int main() {
	std::string nombreArchivo;
	int n = 0;

	if (!(std::cin >> nombreArchivo >> n)) {
		std::cerr << "Error: no se pudo leer el nombre de archivo y/o el entero n." << std::endl;
		return 1;
	}

	if (!esNValido(n)) {
		std::cerr << "Error: n debe ser multiplo de 4 y estar entre 16 y 64." << std::endl;
		return 1;
	}

	std::string contenido;
	if (!leerArchivoCompleto(nombreArchivo, contenido)) {
		std::cerr << "Error: no se pudo abrir el archivo '" << nombreArchivo << "'." << std::endl;
		return 1;
	}

	std::string contenidoRellenado = rellenarHastaMultiploDeN(contenido, n);
	std::vector<long long> sumasColumnas = calcularSumasPorColumna(contenidoRellenado, n);
	std::vector<int> arregloFinal = plegarSumasEnGrupos(sumasColumnas, n);
	std::string resultadoHex = generarCadenaHexadecimal(arregloFinal);

	std::cout << resultadoHex << std::endl;

	return 0;
}
