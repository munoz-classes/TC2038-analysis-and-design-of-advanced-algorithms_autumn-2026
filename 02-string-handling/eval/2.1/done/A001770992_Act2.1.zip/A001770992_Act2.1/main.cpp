/*
 * Se siguen las reglas de n columnas y dos digitos por columna:
 * la longitud resultante es 2*n. El enunciado tambien dice n/4,
 * lo cual es incompatible con esas reglas
 *
 * Casos de prueba (contenido exacto del archivo, sin comillas):
 * 1. Vacio, n = 16: 32 ceros
 * 2. "abc", n = 16: "616263" seguido de "10" 13 veces
 * 3. "ABCDEFGHIJKLMNOP", n = 16:
 *    4142434445464748494A4B4C4D4E4F50
 * 4. 128 letras 'a' y un salto de linea LF, n = 64:
 *    "CC" seguido de "02" 63 veces
 */

#include <fstream>
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>

using namespace std;

/*
 * Lee el nombre del archivo y n, calcula el hash y lo imprime
 * Parametros ninguno; los datos se reciben por entrada estandar
 * Retorno 0 si termina correctamente, 1 si ocurre un error
 * Complejidad tiempo O(m + n), espacio O(n + l) donde m es el
 * numero de bytes del archivo y l la longitud de su nombre
 * Lectura y suma O(m) Relleno e impresion: O(n)
 */
int main() {
	string nombreArchivo = "";
	int n = 0;

	if (!(cin >> nombreArchivo >> n) || n < 16 || n > 64 || n % 4 != 0) {
		cerr << "Entrada invalida.\n";
		return 1;
	}

	ifstream archivo(nombreArchivo, ios::binary);
	if (!archivo) {
		cerr << "No se pudo abrir el archivo.\n";
		return 1;
	}

	vector<int> sumas(n, 0);
	char caracter = '\0';
	int columna = 0;

	// get conserva espacios y saltos de linea; unsigned char evita negativos
	while (archivo.get(caracter)) {
		sumas[columna] = (sumas[columna] + static_cast<unsigned char>(caracter)) % 256;
		columna = (columna + 1) % n;
	}

	if (!archivo.eof()) {
		cerr << "Error al leer el archivo.\n";
		return 1;
	}

	// solo se rellena si el ultimo renglon quedo incompleto
	if (columna != 0) {
		for (int i = columna; i < n; i++) {
			sumas[i] = (sumas[i] + n) % 256;
		}
	}

	cout << uppercase << hex << setfill('0');
	for (int i = 0; i < n; i++) {
		cout << setw(2) << sumas[i];
	}
	cout << '\n';

	return 0;
}
