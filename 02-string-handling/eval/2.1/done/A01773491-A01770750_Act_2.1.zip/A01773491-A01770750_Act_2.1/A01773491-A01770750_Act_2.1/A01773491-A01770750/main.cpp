// main.cpp
// Alan Joseph Salazar Segura - A01773491
// Marco Aurelio Tamez Robles - A01770750
// Genera el hash hexadecimal de un archivo de texto usando n columnas.

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <stdexcept>
#include <unistd.h>
using namespace std;
 
// Constantes con nombre.
const int MODULO_ASCII = 256;
const string DIGITOS_HEX = "0123456789ABCDEF";
 
// Suma por columnas los caracteres del archivo y rellena el ultimo renglon con n.
// Complejidad temporal: O(m + n), donde m es el numero de caracteres del archivo.
// Complejidad espacial: O(n), por el arreglo de sumas.
vector<int> sumarColumnas(const string &nombreArchivo, int n) {
    vector<int> a(n, 0);
    ifstream archivo(nombreArchivo.c_str());
    if (!archivo.is_open()) {
        throw runtime_error("Error: no se pudo abrir el archivo: " + nombreArchivo);
    }
    char c;
    int i = 0;
    while (archivo.get(c)) {
        a[i] = (a[i] + static_cast<unsigned char>(c)) % MODULO_ASCII;
        i = (i + 1) % n;
    }
    if (i != 0) {
        for (int j = i; j < n; j++) {
            a[j] = (a[j] + n) % MODULO_ASCII;
        }
    }
    return a;
}
 
// Convierte el arreglo de sumas a una cadena hexadecimal en mayusculas.
// Complejidad temporal: O(n), donde n es el tamano del arreglo.
// Complejidad espacial: O(n), por la cadena de salida.
string aHexadecimal(const vector<int> &a) {
    string salida;
    salida.reserve(a.size() * 2);
    for (size_t idx = 0; idx < a.size(); idx++) {
        salida += DIGITOS_HEX[a[idx] / 16];
        salida += DIGITOS_HEX[a[idx] % 16];
    }
    return salida;
}
 
// Lee el nombre del archivo y n
int main() {
    bool interactivo = isatty(STDIN_FILENO);
    string nombreArchivo;
    int n;
    if (interactivo) {
        cout << "Nombre del archivo a hashear: ";
    }
    cin >> nombreArchivo;
    if (interactivo) {
        cout << "Valor de n (multiplo de 4, entre 16 y 64): ";
    }
    cin >> n;
    try {
        vector<int> a = sumarColumnas(nombreArchivo, n);
        cout << aHexadecimal(a) << "\n";
    } catch (const runtime_error &e) {
        cerr << e.what() << "\n";
        return 1;
    }
    return 0;
}