/*
 * Descripcion: Programa que calcula el hash hexadecimal de un archivo de
 *              texto. Acomoda los caracteres del archivo (incluyendo los
 *              saltos de linea) en una tabla de n columnas, rellena el
 *              ultimo renglon con el valor n cuando hace falta, suma el
 *              ASCII de cada columna modulo 256 y entrega la concatenacion
 *              en hexadecimal (mayusculas, dos digitos por columna).
 * Autor: René Cano A01773558, Sebastián Plata A01774031
 * Fecha de creacion/modificacion: 11/09/2026
 */

#include <iostream>
#include <fstream>
#include <string>
#include <cstdio>
using namespace std;

const int MAX_COLUMNAS = 64;

/*
 * Lee todo el contenido de un archivo de texto, incluyendo los saltos de
 * linea, y lo devuelve en una sola cadena.
 * Parametro nombreArchivo: nombre del archivo de texto a leer.
 * Regresa: cadena con todos los caracteres del archivo.
 * Complejidad: O(L) en tiempo y O(L) en espacio, donde L es el numero de
 *              caracteres del archivo.
 */
string leerArchivo(const string &nombreArchivo) {
    ifstream archivo(nombreArchivo);
    string texto = "";
    char caracter = ' ';
    while (archivo.get(caracter)) {
        texto += caracter;
    }
    archivo.close();
    return texto;
}

/*
 * Calcula, para cada columna, la suma de los valores ASCII de los caracteres
 * que caen en ella modulo 256. Si el numero de caracteres no es multiplo de
 * columnas, rellena las celdas restantes del ultimo renglon con el valor
 * columnas.
 * Parametro texto: contenido del archivo ya leido.
 * Parametro columnas: numero de columnas de la tabla (valor de n).
 * Parametro sumas: arreglo de salida donde se guardan las sumas por columna.
 * Regresa: nada (el resultado queda en el arreglo sumas).
 * Complejidad: O(L) en tiempo y O(1) en espacio adicional, donde L es el
 *              numero de caracteres del archivo.
 */
void calcularSumasColumnas(const string &texto, int columnas, int sumas[]) {
    int longitud = texto.length();
    int i = 0;
    for (i = 0; i < longitud; i++) {
        int columna = i % columnas;
        int valor = (unsigned char) texto[i];
        sumas[columna] = (sumas[columna] + valor) % 256;
    }

    int resto = longitud % columnas;
    if (resto != 0) {
        int j = 0;
        for (j = resto; j < columnas; j++) {
            sumas[j] = (sumas[j] + columnas) % 256;
        }
    }
}

/*
 * Convierte el arreglo de sumas a una cadena hexadecimal en mayusculas,
 * usando dos digitos por cada columna.
 * Parametro sumas: arreglo con las sumas por columna.
 * Parametro columnas: numero de columnas a convertir (valor de n).
 * Regresa: cadena hexadecimal resultante.
 * Complejidad: O(n) en tiempo y O(n) en espacio, donde n es el numero de
 *              columnas.
 */
string arregloAHex(int sumas[], int columnas) {
    string resultado = "";
    char buffer[3] = {0};
    int i = 0;
    for (i = 0; i < columnas; i++) {
        sprintf(buffer, "%02X", sumas[i]);
        resultado += buffer;
    }
    return resultado;
}

/*
 * Funcion principal: lee de la entrada el nombre del archivo y el valor de n,
 * calcula el hash del archivo y lo imprime.
 * Complejidad global: O(L + n), dominada por la lectura y el recorrido de los
 *                     L caracteres del archivo.
 */
int main() {
    string nombreArchivo = "";
    int columnas = 0;
    cin >> nombreArchivo >> columnas;

    string texto = leerArchivo(nombreArchivo);

    int sumas[MAX_COLUMNAS] = {0};
    calcularSumasColumnas(texto, columnas, sumas);

    string hash = arregloAHex(sumas, columnas);
    cout << hash << endl;

    return 0;
}