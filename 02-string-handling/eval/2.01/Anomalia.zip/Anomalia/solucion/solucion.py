def encontrar_firma_genetica(S: str) -> str:
    """
    Algoritmo de Manacher para encontrar el palíndromo más largo en O(n).
    """
    if not S:
        return ""

    # Transformación para unificar palíndromos de longitud par e impar
    t = "#" + "#".join(S) + "#"
    n = len(t)
    
    radios = [0] * n
    centro_actual = 0 
    borde_derecho = 0

    for i in range(n):
        # 1. Propiedad del espejo: reutilizar cálculos previos si estamos dentro del borde
        if i < borde_derecho:
            espejo = 2 * centro_actual - i
            radios[i] = min(borde_derecho - i, radios[espejo])

        # 2. Expandir el palíndromo centrado en i comprobando los límites
        while (i - radios[i] - 1 >= 0 and 
               i + radios[i] + 1 < n and 
               t[i - radios[i] - 1] == t[i + radios[i] + 1]):
            radios[i] += 1

        # 3. Actualizar el estado si superamos el borde derecho conocido
        if i + radios[i] > borde_derecho:
            centro_actual = i
            borde_derecho = i + radios[i]

    # Mapear el índice del resultado a la cadena original
    centro_maximo = radios.index(max(radios))
    longitud_maxima = radios[centro_maximo]
    inicio = (centro_maximo - longitud_maxima) // 2

    return S[inicio : inicio + longitud_maxima]


if __name__ == "__main__":
    import sys
    entrada = sys.stdin.read().strip()
    if entrada:
        print(encontrar_firma_genetica(entrada))