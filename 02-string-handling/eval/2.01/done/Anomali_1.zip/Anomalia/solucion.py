
# convertir cualquier cadena en una impar
def transformar(s):
    t = "#"
    for ch in s:
        t += ch + "#"
    return t


def manacher(s):
    #prepara la cadena
    t = transformar(s)
    n = len(t)
    radio = [0] * n #que tan grande es el palíndromo en cada posición
    centro = 0
    derecha = 0
    mejor_centro = 0
    mejor_radio = 0

    #si estamos dentro de un palíndromo q ya vimos, reutilizamos lo calculado antes
    for i in range(n):
        if i < derecha:
            espejo = 2 * centro - i
            radio[i] = min(derecha - i, radio[espejo])

        #compara los caracteres de los lados para ver si el palíndromo crece
        while i - radio[i] - 1 >= 0 and i + radio[i] + 1 < n and t[i - radio[i] - 1] == t[i + radio[i] + 1]:
            radio[i] += 1

        #si el palíndromo se pasa del límite derecho, actualizamos el centro y la derecha
        if i + radio[i] > derecha:
            centro = i
            derecha = i + radio[i]

        #se guarda el mejor palíndromo encontrado hasta ahora
        if radio[i] > mejor_radio:
            mejor_radio = radio[i]
            mejor_centro = i

    #calcula donde empieza y termina el palíndromo original
    inicio = (mejor_centro - mejor_radio) // 2
    return s[inicio:inicio + mejor_radio]

s = input().strip()
print(manacher(s))