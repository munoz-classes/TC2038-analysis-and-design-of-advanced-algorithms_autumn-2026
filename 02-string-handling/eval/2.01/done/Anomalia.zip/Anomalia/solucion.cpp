// ============================================================================
//  La firma genetica oculta - subsecuencia palindromica contigua mas larga
//  Tecnica: Algoritmo de Manacher.  Complejidad: O(n) tiempo, O(n) espacio.
//
//  Entrada : una linea con la cadena del genoma (solo A, C, G, T).
//  Salida  : la subsecuencia palindromica contigua mas larga.
//            Si hay empate, cualquiera de longitud maxima es valida.
// ============================================================================
#include <bits/stdc++.h>
using namespace std;

string firmaGenetica(const string& s) {
    if (s.empty()) return "";

    // Transformamos: entre cada caracter va un '#', y ^ / $ son centinelas.
    //   GATCGGCAT  ->  ^#G#A#T#C#G#G#C#A#T#$
    // Los '#' unifican palindromos pares e impares; ^ y $ evitan comprobar bordes.
    string t = "^";
    for (char c : s) { t += '#'; t += c; }
    t += "#$";

    int n = (int)t.size(), c = 0, r = 0;
    vector<int> p(n, 0);                       // p[i] = radio del palindromo en i

    for (int i = 1; i < n - 1; i++) {
        if (i < r) p[i] = min(r - i, p[2 * c - i]);       // reutiliza el espejo
        while (t[i + p[i] + 1] == t[i - p[i] - 1]) p[i]++; // expande lo necesario
        if (i + p[i] > r) { c = i; r = i + p[i]; }         // actualiza centro/borde
    }

    int len = 0, ctr = 0;                      // radio maximo = longitud en el original
    for (int i = 1; i < n - 1; i++)
        if (p[i] > len) { len = p[i]; ctr = i; }

    return s.substr((ctr - len) / 2, len);     // traduce el centro al indice real
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    string s;
    if (!(cin >> s)) { cout << "\n"; return 0; }   // lee el genoma (un token)
    cout << firmaGenetica(s) << "\n";
    return 0;
}
