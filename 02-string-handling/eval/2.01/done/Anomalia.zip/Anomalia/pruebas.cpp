// ============================================================================
//  pruebas.cpp - Banco de pruebas para la solucion de Manacher
//  Compilar:  g++ -O2 -std=c++17 -o pruebas pruebas.cpp
//  Ejecutar:  ./pruebas
//
//  Contiene:
//    1) La funcion firmaGenetica (identica a solucion.cpp).
//    2) Casos EXTREMOS explicitos con validacion.
//    3) Prueba de estres aleatoria contra una referencia por fuerza bruta.
//    4) Pruebas de RENDIMIENTO a n = 1,000,000 (peor caso de expansion).
// ============================================================================
#include <bits/stdc++.h>
#include <chrono>
using namespace std;
using namespace std::chrono;

// ------------------------- Solucion (Manacher, O(n)) ------------------------
string firmaGenetica(const string& s) {
    if (s.empty()) return "";
    string t = "^";
    for (char c : s) { t += '#'; t += c; }
    t += "#$";
    int n = (int)t.size(), c = 0, r = 0;
    vector<int> p(n, 0);
    for (int i = 1; i < n - 1; i++) {
        if (i < r) p[i] = min(r - i, p[2 * c - i]);
        while (t[i + p[i] + 1] == t[i - p[i] - 1]) p[i]++;
        if (i + p[i] > r) { c = i; r = i + p[i]; }
    }
    int len = 0, ctr = 0;
    for (int i = 1; i < n - 1; i++)
        if (p[i] > len) { len = p[i]; ctr = i; }
    return s.substr((ctr - len) / 2, len);
}

// ------------------------------- Utilidades ---------------------------------
bool esPalindromo(const string& x) {
    int i = 0, j = (int)x.size() - 1;
    while (i < j) if (x[i++] != x[j--]) return false;
    return true;
}

// Referencia O(n^2): longitud del palindromo mas largo (expansion desde centro)
int longitudBruta(const string& s) {
    int n = (int)s.size();
    if (n == 0) return 0;
    auto expand = [&](int l, int r) {
        while (l >= 0 && r < n && s[l] == s[r]) { l--; r++; }
        return r - l - 1;
    };
    int best = 1;
    for (int i = 0; i < n; i++) {
        best = max(best, expand(i, i));
        best = max(best, expand(i, i + 1));
    }
    return best;
}

int pruebas = 0, fallos = 0;

// Valida que la respuesta sea: palindromo, subcadena de s, y de longitud maxima.
void validar(const string& nombre, const string& s) {
    pruebas++;
    string ans = firmaGenetica(s);
    int esperado = longitudBruta(s);
    bool okPal = esPalindromo(ans);
    bool okSub = (s.find(ans) != string::npos) || ans.empty();
    bool okLen = ((int)ans.size() == esperado);
    if (okPal && okSub && okLen) {
        printf("  [OK]   %-28s -> \"%s\" (len %d)\n", nombre.c_str(), ans.c_str(), (int)ans.size());
    } else {
        fallos++;
        printf("  [FALLO]%-28s -> \"%s\" | pal=%d sub=%d len=%d(esp %d)\n",
               nombre.c_str(), ans.c_str(), okPal, okSub, (int)ans.size(), esperado);
    }
}

int main() {
    printf("=== 1) CASOS EXTREMOS EXPLICITOS ===\n");
    validar("cadena vacia", "");
    validar("un caracter", "A");
    validar("dos iguales", "AA");
    validar("dos distintos", "AC");
    validar("sin palindromo largo", "ACGT");
    validar("ejemplo 1 del enunciado", "GATCGGCAT");
    validar("ejemplo 2 del enunciado", "ATACGCGA");
    validar("ejemplo 3 del enunciado", "ACTG");
    validar("palindromo par completo", "ACGTTGCA");     // longitud 8
    validar("palindromo impar completo", "ACGTGCA");     // longitud 7
    validar("palindromo al inicio", "GGGGACGT");
    validar("palindromo al final", "ACGTGGGG");
    validar("empate de maximos", "AACAAGGCGG");          // "AACAA" y "GGCGG"
    validar("todo igual (corto)", string(64, 'G'));
    validar("alternado corto", "ACACACAC");
    validar("casi palindromo", "ACGTGCAT");              // difiere en 1

    printf("\n=== 2) PRUEBA DE ESTRES ALEATORIA (vs fuerza bruta) ===\n");
    mt19937 rng(12345);
    const char* AL = "ACGT";
    int casos = 0;
    for (int len = 0; len <= 40; len++) {
        for (int rep = 0; rep < 3000; rep++) {
            string s;
            for (int k = 0; k < len; k++) s += AL[rng() & 3];
            string ans = firmaGenetica(s);
            if (!esPalindromo(ans) || (int)ans.size() != longitudBruta(s) ||
                (!ans.empty() && s.find(ans) == string::npos)) {
                printf("  [FALLO] s=\"%s\" ans=\"%s\"\n", s.c_str(), ans.c_str());
                fallos++;
            }
            casos++;
        }
    }
    // Algunos aleatorios medianos (hasta 4000) para forzar palindromos largos
    for (int rep = 0; rep < 300; rep++) {
        int len = 1 + rng() % 4000;
        string s;
        // sesgo hacia repeticiones para generar palindromos grandes
        for (int k = 0; k < len; k++) s += AL[rng() % (2 + rng() % 2)];
        string ans = firmaGenetica(s);
        if (!esPalindromo(ans) || (int)ans.size() != longitudBruta(s)) {
            printf("  [FALLO mediano] len=%d ans_len=%d\n", len, (int)ans.size());
            fallos++;
        }
        casos++;
    }
    printf("  %d casos aleatorios comparados contra fuerza bruta.\n", casos);
    pruebas += casos;

    printf("\n=== 3) RENDIMIENTO A n = 1,000,000 ===\n");
    const int N = 1000000;

    // (a) todo igual: peor caso para la expansion ingenua; respuesta = toda la cadena
    {
        string s(N, 'A');
        auto t0 = high_resolution_clock::now();
        string ans = firmaGenetica(s);
        auto t1 = high_resolution_clock::now();
        double ms = duration_cast<microseconds>(t1 - t0).count() / 1000.0;
        bool ok = ((int)ans.size() == N) && esPalindromo(ans);
        printf("  [%s] todo 'A'        len=%d  tiempo=%.1f ms\n", ok ? "OK" : "FALLO", (int)ans.size(), ms);
        if (!ok) fallos++; pruebas++;
    }

    // (b) alternado ACAC...: respuesta esperada = N-1 (palindromo impar)
    {
        string s(N, 'A');
        for (int i = 1; i < N; i += 2) s[i] = 'C';
        auto t0 = high_resolution_clock::now();
        string ans = firmaGenetica(s);
        auto t1 = high_resolution_clock::now();
        double ms = duration_cast<microseconds>(t1 - t0).count() / 1000.0;
        bool ok = ((int)ans.size() == N - 1) && esPalindromo(ans);
        printf("  [%s] alternado ACAC.. len=%d (esp %d)  tiempo=%.1f ms\n",
               ok ? "OK" : "FALLO", (int)ans.size(), N - 1, ms);
        if (!ok) fallos++; pruebas++;
    }

    // (c) aleatorio: validamos que sea palindromo; medimos tiempo
    {
        string s(N, 'A');
        for (int i = 0; i < N; i++) s[i] = AL[rng() & 3];
        auto t0 = high_resolution_clock::now();
        string ans = firmaGenetica(s);
        auto t1 = high_resolution_clock::now();
        double ms = duration_cast<microseconds>(t1 - t0).count() / 1000.0;
        bool ok = esPalindromo(ans) && !ans.empty();
        printf("  [%s] aleatorio        len=%d  tiempo=%.1f ms\n", ok ? "OK" : "FALLO", (int)ans.size(), ms);
        if (!ok) fallos++; pruebas++;
    }

    printf("\n=== RESUMEN ===\n");
    printf("  Pruebas: %d   Fallos: %d   -> %s\n",
           pruebas, fallos, fallos == 0 ? "TODO CORRECTO" : "HAY FALLOS");
    return fallos == 0 ? 0 : 1;
}
