def palindromo_manacher(secuencia):
#O(1) solamente es una comparación básica de tamaño
  if len(secuencia) <= 1:
    return secuencia

# O(n) para la construcción de la cadena 
# Insertamos '#' para manejar longitudes pares e impares por igual
  t = "^#" + "#".join(secuencia) + "#$"
  longitud = len(t)

# O(n) para inicializar el arreglo de radios
  radio = [0] * longitud

#O(1) para las asignaciones iniciales 
  centro = 0
  limite_derecha = 0

  mejor_longitud = 0
  mejor_centro = 0

# O(n) por el bucle completo 
  for i in range(1, longitud - 1):
    espejo = 2 * centro - i

    # Copiamos el radio del espejo si estamos dentro del borde
    if i < limite_derecha:
      radio[i] = min(limite_derecha - i, radio[espejo])

    # Expandimos hacia los lados (la razon por la cual es O(n))
    while t[i + radio[i] + 1] == t[i - radio[i] - 1]:
      radio[i] += 1

    # Actualizamos el centro si encontramos un nuevo borde derecho
    if i + radio[i] > limite_derecha:
      centro = i
      limite_derecha = i + radio[i]

    # Guardamos el palíndromo más largo
    if radio[i] > mejor_longitud:
      mejor_longitud = radio[i]
      mejor_centro = i

  # Calculamos la posición en la cadena original
  inicio = (mejor_centro - mejor_longitud) // 2
  return secuencia[inicio : inicio + mejor_longitud]

print(palindromo_manacher("GATCGGCAT"))
print(palindromo_manacher("ATACGCGA"))
print(palindromo_manacher("ACTG"))



