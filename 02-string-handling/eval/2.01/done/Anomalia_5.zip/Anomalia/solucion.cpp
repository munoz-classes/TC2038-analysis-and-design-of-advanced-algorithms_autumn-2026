/*
 * Problema: "Firma genética" - Longest Palindromic Substring
 * Dada una cadena S (compuesta por A, C, G, T), encontrar la subsecuencia
 * palindromica contigua mas larga.
 *
 * Tecnica: Algoritmo de Manacher -> O(n) tiempo, O(n) espacio.
 *
 * Idea:
 * 1. Se transforma S insertando separadores (#) entre cada caracter y
 *    en los extremos, para tratar palindromos de longitud par e impar
 *    de forma uniforme.
 * 2. Se recorre la cadena transformada manteniendo el "centro" y el
 *    "borde derecho" del palindromo mas a la derecha encontrado hasta
 *    el momento. Para cada posicion i, si esta dentro del rango
 *    [centro, borde derecho], se reutiliza el valor del espejo de i
 *    respecto al centro (evitando recomputar desde cero), y luego se
 *    intenta expandir mas alla de ese valor.
 */

#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
using namespace std;

// Retorna la subsecuencia palindromica contigua mas larga de s.
// Si hay varias con la misma longitud, retorna la primera encontrada.
string longestPalindrome(const string &s) {
    if (s.empty()) return "";

    // 1) Transformar la cadena: "ACGT" -> "^#A#C#G#T#$"
    //    '^' y '$' son centinelas para no chequear limites en el while.
    string t = "^";
    for (char c : s) {
        t += '#';
        t += c;
    }
    t += "#$";

    int n = (int)t.size();
    vector<int> p(n, 0); // p[i] = radio del palindromo centrado en i (en t)
    int center = 0, right = 0;

    for (int i = 1; i < n - 1; i++) {
        // Reutilizar informacion del espejo si i esta dentro del rango conocido
        if (i < right) {
            int mirror = 2 * center - i;
            p[i] = min(right - i, p[mirror]);
        }

        // Intentar expandir el palindromo centrado en i
        while (t[i + p[i] + 1] == t[i - p[i] - 1]) {
            p[i]++;
        }

        // Actualizar el centro/borde derecho si este palindromo llega mas lejos
        if (i + p[i] > right) {
            center = i;
            right = i + p[i];
        }
    }

    // 2) Buscar el radio maximo
    int maxLen = 0, centerIndex = 0;
    for (int i = 1; i < n - 1; i++) {
        if (p[i] > maxLen) {
            maxLen = p[i];
            centerIndex = i;
        }
    }

    // 3) Traducir la posicion en t de vuelta a la posicion original en s
    int start = (centerIndex - maxLen) / 2;
    return s.substr(start, maxLen);
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    string s;
    cin >> s; // la cadena del genoma, ej: "ACGTAACGTACG"

    string resultado = longestPalindrome(s);

    cout << resultado << "\n";

    cout << resultado.size() << "\n";

    return 0;
}
