#ifndef PALINDROMO_H
#define PALINDROMO_H

#include <string>
#include <utility>

/*
Expande desde un centro para encontrar el palindromo mas largo centrado ahi.
Sirve para palindromos pares e impares segun donde arranquen izquierda y derecha.
Parametros
    texto: la cadena donde se busca
    izquierda: indice inicial del dedo izquierdo (base 0)
    derecha: indice inicial del dedo derecho (base 0)
Retorno
    un pair<int,int> con el inicio y fin (base 0) del palindromo encontrado.
*/

std::pair<int, int> expandirDesdeCentro(const std::string &texto, int izquierda, int derecha){
    int n = static_cast<int>(texto.size());
    while (izquierda >= 0 && derecha < n && texto[izquierda] == texto[derecha]){
        izquierda--;
        derecha++;
    }
    return std::make_pair(izquierda + 1, derecha - 1);
}

/*
Encuentra el palindromo contiguo mas largo dentro de texto.
Prueba cada posicion como centro, en sus dos variantes (impar y par),
expandiendo desde el centro y quedandose con el mas largo encontrado.
Parametro
    texto: la cadena donde se busca el palindromo
Retorno
    un pair<int, int> con el inicio y fin (base 0) del palindromo mas largo.
*/

std::pair<int, int> palindromoMasLargo(const std::string &texto){
    int mejorInicio = 0;
    int mejorFin = 0;
    int n = static_cast<int>(texto.size());
    for (int i = 0; i < n; i++){
        std::pair<int, int> impar = expandirDesdeCentro(texto, i, i);
        std::pair<int, int> par = expandirDesdeCentro(texto, i, i + 1);
        int mejorActual = mejorFin - mejorInicio + 1;
        int longitudImpar = impar.second - impar.first + 1;
        int longitudPar = par.second - par.first + 1;
        if (longitudImpar > mejorActual){
            mejorInicio = impar.first;
            mejorFin = impar.second;
        }
        mejorActual = mejorFin - mejorInicio + 1;
        if (longitudPar > mejorActual){
            mejorInicio = par.first;
            mejorFin = par.second;
        }
    }
    return std::make_pair(mejorInicio, mejorFin);
}

#endif