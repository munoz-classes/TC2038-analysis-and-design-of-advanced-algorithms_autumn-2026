#ifndef COMUN_H
#define COMUN_H

#include <vector>
#include <string>
#include <utility>
#include <algorithm>

/*
Encuentra el substring contiguo comun mas largo entre dos cadenas.
Usa programacion dinamica con optimizacion de espacio: en lugar de la
tabla completa n x m, mantiene solo la fila actual y la anterior (O(m) espacio).
Si alguna cadena esta vacia, no existe substring comun y se devuelve (-1, -1),
que al reportarse en base 1 se imprime como "0 0".
Parametros
    x: primera cadena (transmission1); sus posiciones son las que se reportan
    y: segunda cadena (transmission2)
Retorno
    un pair<int, int> con inicio y fin (base 0) del substring comun mas largo en x.
*/

std::pair<int, int> substringComunMasLargo(const std::string &x, const std::string &y){
    int n = static_cast<int>(x.size());
    int m = static_cast<int>(y.size());
    if (n == 0 || m == 0){
        return std::make_pair(-1, -1);
    }
    std::vector<int> filaAnterior(m, 0);
    std::vector<int> filaActual(m, 0);
    int mejorLongitud = 0;
    int mejorFin = 0;
    for (int i = 0; i < n; i++){
        for (int j = 0; j < m; j++){
            if (x[i] == y[j]){
                if (j == 0){
                    filaActual[j] = 1;
                }
                else{
                    filaActual[j] = filaAnterior[j-1] + 1;
                }
            }
            else{
                filaActual[j] = 0;
            }
            if (filaActual[j] > mejorLongitud){
                mejorLongitud = filaActual[j];
                mejorFin = i;
            }
        }
        std::swap(filaAnterior, filaActual);
        std::fill(filaActual.begin(), filaActual.end(), 0);
    }
    int mejorInicio = mejorFin - mejorLongitud + 1;
    return std::make_pair(mejorInicio, mejorFin);
}

#endif