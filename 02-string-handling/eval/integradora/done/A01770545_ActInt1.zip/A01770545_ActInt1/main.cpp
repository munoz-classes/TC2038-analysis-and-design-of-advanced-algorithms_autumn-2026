/*
Analiza transmisiones de datos en busca de codigo malicioso y patrones.
Lee cinco archivos de nombre fijo (dos transmisiones y tres codigos) que
contienen caracteres hexadecimales, y produce tres analisis: 
    1) Si cada codigo aparece como subcadena contigua en cada transmision y 
donde inicia
    2) el palindromo mas largo dentro de cada transmision
    3) el substring comun mas largo entre ambas transmisiones
Todas las posiciones se reportan iniciando en 1.

Autores:
    Iker Octavio Silva Campos - A01770545
    Alberto Guillen Rayas - A01770565
Fecha de creacion: 13 de septiembre de 2026

Supuestos tomados ante ambiguedades del enunciado de la actividad:
    - Los saltos de linea se interpretan como formato de la transmision, no como
parte de los datos; se eliminan al cargar cada archivo, de modo que cada archivo
se procesa como una unica secuencia continua de caracteres hex. Las posiciones no
cuentan los saltos de linea.
    - Todas las posiciones de salida se reportan en base 1 (el primer caracter es la
posicion 1), segun lo pedido explicitamente para las partes 2 y 3 y por consistencia en 
la parte 1.
    - En caso de empate (varios resultados de la misma longitud maxima), tanto en la parte
2 como en la parte 3, se reporta el primero que aparece en la transmision analizada, por
recorrerse de izquierda a derecha con comparacion estricta (solo se actualiza el mejor ante una 
longitud mayor).
*/

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include "busqueda.h"
#include "palindromo.h"
#include "comun.h"

/*
Lee un archivo de texto y devuelve su contenido conservando unicamente los
caracteres hexadecimales validos (0-9 y A-F). Descarta saltos de linea,
espacios y cualquier otro caracter ajeno al alfabeto hexadecimal.
Parametro
    nombreArchivo: nombre del archivo a leer (debe existir en la ruta de ejecucion)
Retorno
    una cadena con unicamente los caracteres hexadecimales del archivo.
*/

std::string cargarArchivo(const std::string &nombreArchivo){
    std::string resultado = "";
    std::ifstream archivo(nombreArchivo);
    char c = ' ';
    while (archivo.get(c)){
        if ((c >= '0' && c <= '9') || (c >= 'A' && c <= 'F')){
            resultado += c;
        }
    }
    archivo.close();
    return resultado;
}

/*
Punto de entrada. Carga los cinco archivos fijos y ejecuta las tres partes del
analisis, imprimiendo sus resultados en el oden que pide el enunciado de la actividad.
Retorno
    0 al terminar correctamente
*/

int main(){
    std::string transmission1 = cargarArchivo("transmission1.txt");
    std::string transmission2 = cargarArchivo("transmission2.txt");
    std::vector<std::string> mcodes;
    mcodes.push_back(cargarArchivo("mcode1.txt"));
    mcodes.push_back(cargarArchivo("mcode2.txt"));
    mcodes.push_back(cargarArchivo("mcode3.txt"));
    //Parte 1: deteccion de codigo malicioso (busqueda de subcadenas)
    for (size_t j = 0; j < mcodes.size(); j++){
        int pos = buscarKMP(transmission1, mcodes[j]);
        if (pos == -1){
            std::cout << "false" << std::endl;
        }
        else{
            std::cout << "true" << " " << (pos + 1) << std::endl;
        }
    }
    for (size_t j = 0; j < mcodes.size(); j++){
        int pos = buscarKMP(transmission2, mcodes[j]);
        if (pos == -1){
            std::cout << "false" << std::endl;
        }
        else{
            std::cout << "true" << " " << (pos + 1) << std::endl;
        }
    }
    //Parte 2: palindromo mas largo en cada transmision
    std::pair<int, int> palT1 = palindromoMasLargo(transmission1);
    std::cout << (palT1.first + 1) << " " << (palT1.second + 1) << std::endl;
    std::pair<int, int> palT2 = palindromoMasLargo(transmission2);
    std::cout << (palT2.first + 1) << " " << (palT2.second + 1) << std::endl;
    //Parte 3: substring comun mas largo entre las dos transmisiones
    std::pair<int, int> comun = substringComunMasLargo(transmission1, transmission2);
    std::cout << (comun.first + 1) << " " << (comun.second + 1) << std::endl;

    return 0;
}

/*
CASOS DE PRUEBA

Caso 1 (archivos de ejemplo pequenos):
  transmission1.txt: A3F / 5A2 / C1   (se carga como A3F5A2C1)
  transmission2.txt: A2C9B / F5A0      (se carga como A2C9BF5A0)
  mcode1.txt: F5A
  mcode2.txt: A2C
  mcode3.txt: 3F6
  Salida esperada:
    true 3        (F5A en transmission1, posicion 3)
    true 5        (A2C en transmission1, posicion 5)
    false         (3F6 no esta en transmission1)
    true 6        (F5A en transmission2, posicion 6)
    true 1        (A2C en transmission2, posicion 1)
    false         (3F6 no esta en transmission2)
    1 1           (palindromo mas largo en transmission1: un solo char)
    1 1           (palindromo mas largo en transmission2: un solo char)
    3 5           (substring comun mas largo: F5A, posiciones 3-5 en transmission1)

Caso 2 (prueba de filtrado y palindromo largo):
  Este caso incluye a proposito caracteres que NO son hexadecimales validos
  (la letra G, un espacio, y una 'a' minuscula) para verificar que cargarArchivo
  los descarta y solo conserva 0-9 y A-F mayusculas.
  transmission1.txt: GCCCCCG / ADAC / GCaA / AAAACC  (se carga como CCCCCADACCAAAAACC)
  transmission2.txt: DGCA / DAGCCAC / ACA(espacio) / A  (se carga como DCADACCACACAA)
  mcode1.txt: AAA
  mcode2.txt: GAC   (se carga como AC)
  mcode3.txt: DAGC  (se carga como DAC)
  Salida esperada:
    true 11       (AAA en transmission1, posicion 11)
    true 8        (AC en transmission1, posicion 8)
    true 7        (DAC en transmission1, posicion 7)
    false         (AAA no esta en transmission2)
    true 5        (AC en transmission2, posicion 5)
    true 4        (DAC en transmission2, posicion 4)
    9 17          (palindromo mas largo en transmission1: CCAAAAACC)
    2 6           (palindromo mas largo en transmission2)
    5 11          (substring comun mas largo en transmission1)

Caso 3 (archivo mcode vacio - comportamiento documentado):
  Si un archivo mcode esta vacio (0 caracteres tras el filtrado), el programa
  reporta "true" para ese codigo. Esto ocurre porque en buscarKMP la condicion
  de coincidencia total (j == m) se cumple de inmediato cuando m es 0, ya que j
  arranca en 0. Matematicamente es consistente (la cadena vacia esta contenida
  en cualquier cadena), aunque el enunciado garantiza que los archivos contienen
  datos, por lo que este caso no deberia presentarse en las pruebas reales.
  transmission1.txt: A3F5A2C1
  mcode1.txt: (vacio)
  mcode2.txt: A2C
  mcode3.txt: 3F6
  Salida para las lineas de mcode1 (vacio): true 2 (en cada transmision no vacia)

Caso 4 (transmision vacia - con guarda):
  Si una transmision esta vacia (0 caracteres tras el filtrado), la parte 3
  no tiene substring comun posible. Sin proteccion, la aritmetica de posiciones
  producia un rango invalido (inicio mayor que fin). Se agrego una guarda en
  substringComunMasLargo que devuelve (-1, -1) ante una cadena vacia, imprimiendo
  "0 0" como rango nulo. La parte 2 (palindromo) sobre una transmision vacia
  reporta "1 1" por su inicializacion; como el enunciado garantiza datos no
  vacios, este caso no deberia presentarse en las pruebas reales.
  transmission1.txt: (vacio)
  transmission2.txt: A2C9BF5A0
  mcode1.txt: F5A
  mcode2.txt: A2C
  mcode3.txt: 3F6
  Salida esperada:
    false / false / false       (transmission1 vacia no contiene ningun mcode)
    true 6 / true 1 / false      (mcodes en transmission2)
    1 1                          (palindromo en transmission1 vacia: ver nota)
    1 1                          (palindromo en transmission2)
    0 0                          (sin substring comun: transmission1 vacia)

Caso 5 (mcode identico a toda la transmision):
  Verifica que un codigo que coincide exactamente con la transmision completa
  se detecte desde la posicion 1, y que el substring comun entre dos transmisiones
  identicas sea la cadena entera.
  transmission1.txt: A2C9BF5A0
  transmission2.txt: A2C9BF5A0
  mcode1.txt: A2C9BF5A0
  mcode2.txt: A2C
  mcode3.txt: 3F6
  Salida esperada:
    true 1        (mcode1 es igual a toda transmission1, inicia en 1)
    true 1        (A2C en transmission1)
    false         (3F6 no esta)
    true 1        (mcode1 es igual a toda transmission2)
    true 1        (A2C en transmission2)
    false         (3F6 no esta)
    1 1           (sin palindromos de 2+ en transmission1)
    1 1           (sin palindromos de 2+ en transmission2)
    1 9           (substring comun mas largo: toda la cadena, transmisiones identicas)

Caso 6 (transmision de un solo caracter repetido):
  Caso limite que estresa la busqueda KMP (muchos prefijos-sufijos repetidos) y
  confirma que toda la cadena se reconoce como palindromo y como substring comun.
  transmission1.txt: AAAAAA
  transmission2.txt: AAAAAA
  mcode1.txt: AAA
  mcode2.txt: A2C
  mcode3.txt: 3F6
  Salida esperada:
    true 1        (AAA en transmission1, inicia en 1)
    false         (A2C no esta en AAAAAA)
    false         (3F6 no esta)
    true 1        (AAA en transmission2)
    false         (A2C no esta)
    false         (3F6 no esta)
    1 6           (toda la cadena AAAAAA es palindromo)
    1 6           (toda la cadena AAAAAA es palindromo)
    1 6           (substring comun mas largo: toda la cadena)
*/