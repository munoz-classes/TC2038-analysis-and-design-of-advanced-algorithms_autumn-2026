#ifndef BUSQUEDA_H
#define BUSQUEDA_H

#include <vector>
#include <string>

/*
Construye la tabla LPS (Longest Prefix that is also Suffix) del patron.
La tabla indica, para cada posicion, la longitud del prefijo mas largo
que tambien es sufijo, y permite a KMP no retroceder en el texto.
Parametro
    patron: la cadena cuyo patron se preprocesa
Retorno
    un vector<int> del mismo tamano que patron con los valores LPS.
*/

std::vector<int> construirLPS(const std::string &patron){
    int m = patron.size();
    std::vector<int> lps(m, 0);
    int longitud = 0;
    size_t i = 1;
    while (i < patron.size()){
        if (patron[i] == patron[longitud]){
            longitud++;
            lps[i] = longitud;
            i++;
        }
        else{
            if (longitud != 0){
                longitud = lps[longitud - 1];
            }
            else{
                i++;
            }
        }
    }
    return lps;
}

/*
Busca la primera aparicion de patron dentro de texto usando el algoritmo KMP.
Parametros
    texto: la cadena donde se busca (la transmision)
    patron: la cadena que se busca (el mcode)
Retorno
    la posicion base 0 donde inicia la primera aparicion, o -1 si no aparece.
*/

int buscarKMP(const std::string &texto, const std::string &patron){
    std::vector<int> lps = construirLPS(patron);
    size_t n = texto.size();
    size_t m = patron.size();
    int resultado = -1;
    size_t i = 0;
    size_t j = 0;
    while (i < n){
        if (texto[i] == patron[j]){
            i++;
            j++;
        }
        else{
            if (j != 0){
                j = lps[j - 1];
            }
            else{
                i++;
            }
        }
        if (j == m){
            resultado = static_cast<int>(i) - static_cast<int>(m);
            i = n;
        }
    }
    return resultado;
}

#endif