/*Actividad 1.2 Implementación de la técnica de programación
"Programación dinámica" y "algoritmos avaros".
Codigo Escritó por: José Pedro Rodríguez Munguía | A01769631*/

#include <bits/stdc++.h>
using namespace std;

vector<int> dp; //Cantidad minima de monedas necesaria para formar cada monto
int casobase(int cambio);

/**
 * Algoritmo mediante programación dinámica
 * Complejidad Temporal: O(n * k)
 * Complejidad Espacial: O(k)
 */
int dinamico(vector<int> N, int cambio_dinamico){
    
    //Llama a caso base y revisa en caso de que se cumpla (igual a 0) o su precio sea menor 0
    int caso = casobase(cambio_dinamico);
    if (caso == -1){
        return -1;
    }
    if (caso == 0){
        return 0;
    }

    //Devuelve la solución si ya se encontró previamente
    if (dp[cambio_dinamico] != -1){
        return dp[cambio_dinamico];
    }

    //En caso de no cumplir con caso base, se parsean las demonimaciones hasta encontrar la mejor
    int mejor = -1;
    for (int i = 0; i < static_cast<int>(N.size()); i++){
        int cambio_menos_denominaciones = cambio_dinamico - N[i];
        int resultado = dinamico(N, cambio_menos_denominaciones);

        //Si tiene solucion (no es -1), se compara con la mejor opcion actual
        //Si no hay solución previa, entonces es establece la actual como mejor
        if (resultado != -1){
            resultado++;
            if (mejor == -1 or resultado < mejor){
                mejor = resultado;
            }
        }
    }

    dp[cambio_dinamico] = mejor;
    return dp[cambio_dinamico];
}

/**
 * Función para comprobar casos base
 * 
 * Complejidad Temporal: O(1)
 * Complejidad Espacial: O(1)
 */
int casobase(int cambio){
    
    if (cambio == 0){
        return 0;
    }
    if (cambio < 0){
        return -1;
    }
    else{
        return 1;
    }
    
}

/**
 * Algoritmo mediante programación avara
 * 
 * Complejidad Temporal: O(n log n + k)
 * Complejidad Espacial: O(n)
 */
vector<int> avaro(vector<int> N, int cambio_avaro){
    //Ordena las denominaciones (En caso de no estar en orden)
    sort(N.begin(), N.end(), greater<int>());
    vector<int> cantidades(N.size(), 0);

    //Itera cada denominacion para obtener la cantidad de monedas y sumando esta en "cantidades"
    for (int i = 0; i < static_cast<int>(N.size()); i++) {
        while (cambio_avaro >= N[i]) {
            cambio_avaro = cambio_avaro - N[i];
            cantidades[i]++;
        }
    }

    if (cambio_avaro != 0)
        return {};
    return cantidades;
}

int main() {
    /*Codigo para ejecutar en Windows:
    g++ main.cpp -o main.exe
    cmd /c "main.exe < in.txt"
    */

    /*Orden de las entradas:
    - Cantidad de demoninaciones.
    - Una entrada para cada demoinación hasta cumplir la "n" cantidad de denominaciones.
    -Precio del producto.
    -Precio en el que se pago.
    */

    int n, P, Q;
    scanf("%d", &n);
    vector<int> N(n);
    for (int i = 0; i < n; i++){
        scanf("%d", &N[i]);
    }
    scanf("%d", &P);
    scanf("%d", &Q); 
    int cambio = Q - P;
    
    //Verifica caso invalido
    if (cambio < 0) {
        return 0;
    }

    //Se asigna como tamaño cambio + 1, con 0 como dato inicial y -1 al no tener un dato calculado
    dp.assign(cambio + 1, -1);
    dp[0] = 0;

    //Se llama al algoritmo dinamico y se consigue su resultado para imprimir si tiene solución
    int resultado_dinamico = dinamico(N, cambio);
    if (resultado_dinamico != -1) {
        sort(N.begin(), N.end(), greater<int>());
        vector<int> n_demoninacion_dinamico(N.size(), 0);
        int restante = cambio;

        for (int i = 0; i < static_cast<int>(N.size()) && restante > 0; i++) {
            while (restante >= N[i] && dp[restante] == dp[restante - N[i]] + 1) {
                n_demoninacion_dinamico[i]++;
                restante -= N[i];
            }
        }

        if (restante == 0) {
            for (int i = 0; i < static_cast<int>(N.size()); i++) {
                if (n_demoninacion_dinamico[i] > 0) {
                    printf("- %d: %d\n", N[i], n_demoninacion_dinamico[i]);
                }
            }
        }
    }

    //Se llama al algoritmo avaro y se imprime su resultado solo si existe solucion
    vector<int> n_demoninacion_avaro = avaro(N, cambio);
    int solucion_avaro = !n_demoninacion_avaro.empty();

    if (solucion_avaro) {
        printf("Avaro:\n");
        for (int i = 0; i < static_cast<int>(N.size()); i++) {
            if (n_demoninacion_avaro[i] > 0) {
                printf("- %d: %d\n", N[i], n_demoninacion_avaro[i]);
            }
        }
    }


    return 0;
}