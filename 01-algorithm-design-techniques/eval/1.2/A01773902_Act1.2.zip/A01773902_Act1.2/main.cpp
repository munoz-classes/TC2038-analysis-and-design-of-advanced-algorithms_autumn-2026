/*
 * Actividad 1.2: Cambio de monedas usando Programacion Dinamica y Algoritmo Avaro
 *
 * Entrada (por redireccion estandar):
 *   N          -> numero de denominaciones disponibles
 *   N enteros  -> valores de cada denominacion (uno por linea)
 *   P          -> precio del producto
 *   Q          -> monto con el que se paga el producto
 *
 * Salida:
 *   N enteros -> numero de monedas de cada denominacion (de mayor a menor)
 *                usando Programacion Dinamica
 *   N enteros -> numero de monedas de cada denominacion (de mayor a menor)
 *                usando Algoritmo Avaro
 */

#include <iostream>
#include <vector>
#include <algorithm>
#include <climits>

using namespace std;

/*
 * calcularCambioDP
 * Calcula el numero minimo de monedas necesarias para dar el cambio
 * utilizando programacion dinamica (bottom-up).
 *
 * Parametros:
 *   denominaciones - vector con las denominaciones disponibles, ordenadas
 *                    de mayor a menor
 *   cambio         - cantidad exacta de cambio que se debe entregar
 *
 * Regreso:
 *   vector<int> con el numero de monedas usadas de cada denominacion,
 *   en el mismo orden que "denominaciones" (de mayor a menor)
 *
 * Complejidad: O(cambio * n), donde n es el numero de denominaciones
 */
vector<int> calcularCambioDP(const vector<int>& denominaciones, int cambio) {
    int n = denominaciones.size();
    vector<int> minMonedas(cambio + 1, INT_MAX);
    vector<int> monedaUsada(cambio + 1, -1);
    minMonedas[0] = 0;

    for (int monto = 1; monto <= cambio; monto++) {
        for (int i = 0; i < n; i++) {
            int valor = denominaciones[i];
            if (valor <= monto && minMonedas[monto - valor] != INT_MAX) {
                if (minMonedas[monto - valor] + 1 < minMonedas[monto]) {
                    minMonedas[monto] = minMonedas[monto - valor] + 1;
                    monedaUsada[monto] = valor;
                }
            }
        }
    }

    vector<int> conteo(n, 0);
    int restante = cambio;
    while (restante > 0 && monedaUsada[restante] != -1) {
        int valor = monedaUsada[restante];
        for (int i = 0; i < n; i++) {
            if (denominaciones[i] == valor) {
                conteo[i]++;
                break;
            }
        }
        restante -= valor;
    }

    return conteo;
}

/*
 * calcularCambioAvaro
 * Calcula el numero de monedas necesarias para dar el cambio utilizando
 * un algoritmo avaro: en cada paso se toma la mayor cantidad posible de
 * la denominacion mas grande disponible.
 *
 * Parametros:
 *   denominaciones - vector con las denominaciones disponibles, ordenadas
 *                    de mayor a menor
 *   cambio         - cantidad exacta de cambio que se debe entregar
 *
 * Regreso:
 *   vector<int> con el numero de monedas usadas de cada denominacion,
 *   en el mismo orden que "denominaciones" (de mayor a menor)
 *
 * Complejidad: O(n), donde n es el numero de denominaciones
 */
vector<int> calcularCambioAvaro(const vector<int>& denominaciones, int cambio) {
    int n = denominaciones.size();
    vector<int> conteo(n, 0);
    int restante = cambio;

    for (int i = 0; i < n; i++) {
        conteo[i] = restante / denominaciones[i];
        restante = restante % denominaciones[i];
    }

    return conteo;
}

int main() {
    int n;
    cin >> n;

    vector<int> denominaciones(n);
    for (int i = 0; i < n; i++) {
        cin >> denominaciones[i];
    }

    int p, q;
    cin >> p >> q;

    int cambio = q - p;

    // Ordenar denominaciones de mayor a menor para reportar en ese orden
    sort(denominaciones.begin(), denominaciones.end(), greater<int>());

    vector<int> resultadoDP = calcularCambioDP(denominaciones, cambio);
    vector<int> resultadoAvaro = calcularCambioAvaro(denominaciones, cambio);

    for (int i = 0; i < n; i++) {
        cout << resultadoDP[i] << "\n";
    }
    for (int i = 0; i < n; i++) {
        cout << resultadoAvaro[i] << "\n";
    }

    return 0;
}
