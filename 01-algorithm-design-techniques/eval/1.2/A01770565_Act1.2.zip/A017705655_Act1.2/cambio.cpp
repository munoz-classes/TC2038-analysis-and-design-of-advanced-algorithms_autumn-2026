/*
Alberto Guillen Rayas
A01770565
Actividad 1.2
*/

#include <iostream>
#include <vector>
#include<algorithm>
using namespace std;


//Algoritmo avaro
//complejidad O(n log n) por el ordenamiento
std::vector<int> cambioA(std::vector<int> denominaciones,int cambio){
    
    //ibtenemos la longitud de elementos y creamos un vector lleno de 0 dependiendo de la longitud
    int n = denominaciones.size();
    std::vector<int>resultado(n,0);

    std::sort(denominaciones.rbegin(), denominaciones.rend());

    //calcular las monedas
    for(int i = 0; i < n; i++){
        resultado[i] = cambio /denominaciones[i];

        cambio= cambio % denominaciones[i];
    }
    return resultado;
}

// Algoritmo Programacion Dinamica
// O(N*cambio)

const int infinto = 1e9;

std::vector<int> cambioDP(std::vector<int> denominacion, int cambio) {
    int n = denominacion.size();
    std::sort(denominacion.rbegin(), denominacion.rend());

    // Arreglo de minimo de monedas
    std::vector<int> dp(cambio + 1, infinto);
    dp[0] = 0; // Caso base: 0 cambio requiere 0 monedas

    // Arreglo para registrar la moneda elegida para cada monto
    std::vector<int> usada(cambio + 1, -1);

    // Llenado de la tabla DP
    for (int m = 1; m <= cambio; m++) {
        for (int d = 0; d < n; d++) {
            int coin = denominacion[d];

            if (m >= coin && dp[m - coin] != infinto) {
                // Solo actualizamos si encontramos una solucion con MENOS monedas
                if (dp[m - coin] + 1 < dp[m]) {
                    dp[m] = dp[m - coin] + 1;
                    usada[m] = coin; // Guardamos la moneda elegida
                }
            }
        } 
    }

    // Contamos cuántas monedas de cada tipo se usaron
    std::vector<int> resultado(n, 0);
    int actual = cambio;

    while (actual > 0 && usada[actual] != -1) {
        int coin = usada[actual];
        
        // Buscamos a que indice corresponde la moneda elegida
        for (int d = 0; d < n; d++) {
            if (denominacion[d] == coin) {
                resultado[d]++;
                break;
            }
        }
        actual -= coin; // Descontamos la moneda tomada
    }

    return resultado;
}

int main(){
    int N;
    cin >> N;

    // Leemos las N denominaciones
    std::vector<int> denominaciones(N);
    for (int i = 0; i < N; i++) {
        cin >> denominaciones[i];
    }

    int P, Q;
    cin >> P;
    cin >> Q;

    // Calculamos el cambio a entregar
    int cambio = Q - P;

    // 1. Calculamos e imprimimos el resultado de Programación Dinámica
    std::vector<int> resDP = cambioDP(denominaciones, cambio);
    for (int i = 0; i < N; i++) {
        cout << resDP[i] << endl;
    }

    // 2. Calculamos e imprimimos el resultado del Algoritmo Avaro
    std::vector<int> resAvaro = cambioA(denominaciones, cambio);
    for (int i = 0; i < N; i++) {
        cout << resAvaro[i] << endl;
    }

    return 0;
}
