/*
 * Tarea: Problema del cambio de monedas (Versión C++).
 * Primero lo resuelvo con Programación Dinámica y luego con el algoritmo Avaro (Greedy).
 * Autor: Leonardo Rulfo Soto - A01773729
 * Fecha de creación: 27/08/2026
 */

#include <iostream>
#include <vector>
#include <algorithm> // Para usar sort()
#include <climits>   // Para usar INT_MAX

using namespace std; 

// Método de Programación Dinámica.
// Aquí guardamos el mínimo de monedas y vamos construyendo la solución paso a paso.
void resolverConProgramacionDinamica(const vector<int>& monedas, int cambio, vector<int>& resultado) {
    int n = monedas.size();
    
    // Vectores para ir guardando los resultados parciales (memorización). 
    vector<int> min_monedas(cambio + 1, INT_MAX);
    vector<int> ultima_moneda(cambio + 1, -1);
    
    min_monedas[0] = 0; // Para dar 0 de cambio, ocupamos 0 monedas

    // Llenamos la tabla desde 1 peso hasta el cambio total
    for (int i = 1; i <= cambio; i++) {
        for (int j = 0; j < n; j++) {
            int sobrante = i - monedas[j];
            
            // Checamos si la moneda cabe y si ya calculamos una solución válida para ese sobrante
            if (sobrante >= 0 && min_monedas[sobrante] != INT_MAX) {
                if (min_monedas[sobrante] + 1 < min_monedas[i]) {
                    min_monedas[i] = min_monedas[sobrante] + 1;
                    ultima_moneda[i] = j; // Guardo qué moneda acabo de usar
                }
            }
        }
    }

    // Limpiamos el vector de salida por si tenía algo antes
    fill(resultado.begin(), resultado.end(), 0);

    // Reconstruimos la solución viendo el historial de las monedas que usamos
    int monto_actual = cambio;
    while (monto_actual > 0 && ultima_moneda[monto_actual] != -1) {
        int indice_moneda = ultima_moneda[monto_actual];
        resultado[indice_moneda]++;
        monto_actual -= monedas[indice_moneda]; // Le restamos la moneda al total
    }
}

// Método Avaro (Greedy).
// Este está más simple, siempre agarramos la moneda de mayor valor que quepa.
void resolverConAlgoritmoAvaro(const vector<int>& monedas, int cambio, vector<int>& resultado) {
    int sobrante = cambio;
    int n = monedas.size();

    for (int i = 0; i < n; i++) {
        resultado[i] = sobrante / monedas[i]; // Sacamos cuántas monedas de esta denominación caben
        sobrante = sobrante % monedas[i];     // Actualizamos lo que nos falta dar de cambio
    }
}

// Imprimimos el vector emparejando la cantidad con su denominación
void imprimirVector(const vector<int>& resultado, const vector<int>& monedas) {
    for (int i = 0; i < resultado.size(); i++) {
        // Filtramos los ceros para que la salida se vea más limpia
        if (resultado[i] > 0) {
            cout << resultado[i] << " moneda(s) de " << monedas[i] << "\n";
        }
    }
}

int main() {
    int n = 0;
    int precio = 0;
    int pago = 0;

    // Leemos cuántas denominaciones de monedas hay
    if (!(cin >> n)) {
        return 1; // Terminamos si lee basura
    }

    // Declaramos el vector del tamaño exacto de n
    vector<int> monedas(n);
    
    // Leemos el valor de cada una de las monedas
    for (int i = 0; i < n; i++) {
        cin >> monedas[i];
    }

    // Leemos cuánto costó y con cuánto pagaron
    if (!(cin >> precio >> pago)) {
        return 1;
    }

    int cambio = pago - precio;

    // Super importante: acomodamos las monedas de mayor a menor.
    sort(monedas.begin(), monedas.end(), greater<int>());

    // Vectores listos con ceros para guardar las respuestas de los dos métodos
    vector<int> res_dp(n, 0);
    vector<int> res_avaro(n, 0);

    // Ejecutamos
    resolverConProgramacionDinamica(monedas, cambio, res_dp);
    resolverConAlgoritmoAvaro(monedas, cambio, res_avaro);

    // Mostramos los resultados con sus separadores (primero DP, luego Greedy)
    cout << "\n--- Solucion con Programacion Dinamica ---\n";
    imprimirVector(res_dp, monedas);

    cout << "\n--- SolucioXXXXXn con Algoritmo Avaro (Greedy) ---\n";
    imprimirVector(res_avaro, monedas);
    
    return 0;
}