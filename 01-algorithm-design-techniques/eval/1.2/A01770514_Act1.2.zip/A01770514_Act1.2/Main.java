import java.util.Scanner;
import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        if (!scanner.hasNextInt()) {
            scanner.close();
            return;
        }
        int n = scanner.nextInt();
        int[] monedas = new int[n];

        /*
         * Complejidad temporal: O(N)
         * Complejidad espacial: O(N)
         */
        for (int i = 0; i < n; i++) {
            while (!scanner.hasNextInt()) {
                scanner.next();
            }
            monedas[i] = scanner.nextInt();
        }

        while (!scanner.hasNextInt()) {
            scanner.next();
        }
        int p = scanner.nextInt();

        while (!scanner.hasNextInt()) {
            scanner.next();
        }
        int q = scanner.nextInt();

        int cambio = q - p;

        if (cambio < 0) {
            scanner.close();
            return;
        }

        /*
         * Complejidad temporal: O(N log N)
         * Complejidad espacial: O(N)
         */
        Arrays.sort(monedas);

        int[] Greedy = algGreedy(monedas, cambio);
        int[] DP = algDP(monedas, cambio);

        /*
         * Complejidad temporal: O(N)
         * Complejidad espacial: O(1)
         */
        System.out.printf("%-15s %-15s %-15s\n", "MONEDA", "CANT. GREEDY", "CANT. DP");
        System.out.println("=============================================");

        for (int i = n - 1; i >= 0; i--) {
            System.out.printf("$%-14d %-15d %-15d\n", monedas[i], Greedy[i], DP[i]);
        }

        scanner.close();
    }

    /**
     * Algoritmo ávaro (GREEDY):
     * Complejidad temporal: O(N + K)
     * Complejidad espacial: O(N)
     */
    public static int[] algGreedy(int[] monedas, int cambio) {
        int n = monedas.length;
        int[] count = new int[n];
        int resto = cambio;

        for (int i = n - 1; i >= 0; i--) {
            while (resto >= monedas[i]) {
                count[i]++;
                resto -= monedas[i];
            }
        }
        if (resto > 0) {
            return new int[n];
        }

        return count;
    }

    /**
     * Algoritmo de Programación Dinámica (DP)
     * Complejidad temporal: O(N * C)
     * Complejidad espacial: O(N + C)
     */
    public static int[] algDP(int[] monedas, int cambio) {
        int n = monedas.length;
        int[] count = new int[n];

        if (cambio <= 0) return count;

        int[] minMonedas = new int[cambio + 1];
        int[] monedaUsada = new int[cambio + 1];

        for (int i = 0; i <= cambio; i++) {
            minMonedas[i] = Integer.MAX_VALUE - 1;
        }
        minMonedas[0] = 0;

        for (int c = 1; c <= cambio; c++) {
            for (int i = 0; i < n; i++) {
                if (c >= monedas[i]) {
                    if (minMonedas[c - monedas[i]] + 1 < minMonedas[c]) {
                        minMonedas[c] = minMonedas[c - monedas[i]] + 1;
                        monedaUsada[c] = i;
                    }
                }
            }
        }

        if (minMonedas[cambio] == Integer.MAX_VALUE - 1) {
            return count;
        }

        int restante = cambio;
        while (restante > 0) {
            int monedaIndex = monedaUsada[restante];
            count[monedaIndex]++;
            restante -= monedas[monedaIndex];
        }
        return count;
    }
}
