﻿#include <iostream>
#include <vector>
#include <algorithm>
#include <climits>

static void programacióndinámica(int cambio, int* denominaciones, int n) {
    std::cout << "Programación Dinámica\n";
    int* al = new int[cambio + 1];
    int* usado = new int[cambio + 1];
    al[0] = 0;
    usado[0] = -1;
    for (int i = 1; i <= cambio; i++) {
        al[i] = INT32_MAX;
        for (int j = 0; j < n; j++) {
            int moneda = denominaciones[j];
            
            if (moneda <= i && al[i - moneda] + 1 < al[i]) {
                al[i] = al[i - moneda] + 1;
                usado[i] = j;
            }
        }
    }
    if (al[cambio] != INT32_MAX) {
        int* conteo = new int[n]();
        int monto = cambio;
        while (monto > 0) {
            int idx = usado[monto];
            if (idx < 0 || idx >= n) {
                monto = 0;
            }
            else {
                conteo[idx]++;
                monto -= denominaciones[idx];
            }

        }
        for (int i = 0; i < n; i++) {
            std::cout << "monedas de " << denominaciones[i] << " : " << conteo[i] << "\n";
        }
        
        delete[] conteo;
    }
    else {
        std::cout << "No es posible\n";
    }
    delete[] al;
    delete[] usado;
}

static void algoritmoavaro(int cambio, int* denominaciones, int n) {
    std::cout << "Algoritmo avaro\n";
    int resto = cambio;
    for (int i = 0; i < n; i++) {
        int res = resto / denominaciones[i];
        resto %= denominaciones[i];
        std::cout << "monedas de " << denominaciones[i] << " : " << res << "\n";
    }
    if (resto != 0) {
        std::cout <<" No es posible\n";
    }
}

int main() {
    int N = 0;
    std::cin >> N;

    int* denominaciones = new int[N];
    for (int i = 0; i < N; ++i) {
        std::cin >> denominaciones[i];
    }

    int P = 0, Q = 0;
    std::cin >> P >> Q;

    int cambio = Q - P;
    if (cambio > 0) {
        std::sort(denominaciones, denominaciones + N, std::greater<int>());
        programacióndinámica(cambio, denominaciones, N);
        algoritmoavaro(cambio, denominaciones, N);
    }
    else if (cambio == 0){
        std::cout << "No hay cambio\n";
    }
    else {
        std::cout << "No es suficiente dinero\n";
    }

    delete[] denominaciones;
    return 0;
}