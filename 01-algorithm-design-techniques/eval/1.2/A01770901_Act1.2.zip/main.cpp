/*
 * Programa: Problema del cambio de monedas 
 *.Nombre: Tabata Carolina Salinas Valdez
 * Matricula: A01770901
 * Fecha: 28/08/2026
 */

#include <iostream>

using namespace std;

/*
 * Proposito:
 * Cantidad minima de monedas necesarias para dar el cambio
 * utilizando programacion dinamica.
 * Parametros:
 * denominaciones: Arreglo con las denominaciones disponibles.
 * n: Numero de denominaciones.
 * cambio: Cantidad total de cambio que se debe entregar.
 * monedas: Arreglo donde se almacenara la cantidad de monedas utilizada
 * por cada denominacion.
 * Complejidad:
 * O(n * cambio), n= num de denom.
 */
void programacionDinamica(int denominaciones[], int n, int cambio,
                          int monedas[])
{
	int infinito = cambio + 1;
	int* minimo = new int[cambio + 1];
	int* ultimaMoneda = new int[cambio + 1];

	for (int i = 0; i <= cambio; i++)
	{
		minimo[i] = infinito;
		ultimaMoneda[i] = -1;
	}

	minimo[0] = 0;

	for (int cantidad = 1; cantidad <= cambio; cantidad++)
	{
		for (int i = 0; i < n; i++)
		{
			if (denominaciones[i] <= cantidad)
			{
				int anterior = minimo[cantidad - denominaciones[i]] + 1;

				if (anterior < minimo[cantidad])
				{
					minimo[cantidad] = anterior;
					ultimaMoneda[cantidad] = i;
				}
			}
		}
	}

	for (int i = 0; i < n; i++)
	{
		monedas[i] = 0;
	}

	int cantidad = cambio;

	while (cantidad > 0 && ultimaMoneda[cantidad] != -1)
	{
		int posicion = ultimaMoneda[cantidad];

		monedas[posicion]++;
		cantidad = cantidad - denominaciones[posicion];
	}

	delete[] minimo;
	delete[] ultimaMoneda;
}

/*
 * Proposito:
 * Cambio utilizando un algoritmo avaro, seleccionando
 * en cada paso la denominacion de mayor valor posible.
 *
 * Parametros:
 * denominaciones: Arreglo con las denominaciones disponibles.
 * n: Numero de denominaciones.
 * cambio: Cantidad total de cambio que se debe entregar.
 * monedas: Arreglo donde se almacenara la cantidad de monedas utilizada
 * por cada denominacion.
 *
 * Complejidad:
 * O(n * cambio), n es el numero de denominaciones y cambio
 * es la cantidad que se debe entregar.
 */
void algoritmoAvaro(int denominaciones[], int n, int cambio, int monedas[])
{
	for (int i = 0; i < n; i++)
	{
		monedas[i] = 0;
	}

	for (int i = 0; i < n; i++)
	{
		while (cambio >= denominaciones[i])
		{
			cambio = cambio - denominaciones[i];
			monedas[i]++;
		}
	}
}

/*
 * Proposito:
 * Ordenar las denominaciones de mayor a menor y mantiener la relacion
 * entre cada denominacion y la cantidad de monedas correspondiente.
 *
 * Parametros:
 * denominaciones: Arreglo con las denominaciones disponibles.
 * n: Numero de denominaciones.
 *
 *
 * Complejidad:
 * O(n^2), por el metodo de ordenamiento.
 */
void ordenarDenominaciones(int denominaciones[], int n)
{
	for (int i = 0; i < n - 1; i++)
	{
		for (int j = i + 1; j < n; j++)
		{
			if (denominaciones[i] < denominaciones[j])
			{
				int temporal = denominaciones[i];
				denominaciones[i] = denominaciones[j];
				denominaciones[j] = temporal;
			}
		}
	}
}

/*
 * Proposito:
 * Leer los datos, calcular el cambio y mostrar las soluciones
 * mediante programacion dinamica y algoritmo avaro.
 *
 * Parametros:
 * No tiene parametros.
 *
 * Retorno:
 * Retorna 0 cuando el programa termina correctamente.
 *
 * Complejidad:
 * O(n^2 + n * cambio), considerando el ordenamiento y los algoritmos
 * utilizados para encontrar el cambio.
 */
int main()
{
	int n = 0;
	cin >> n;
	int* denominaciones = new int[n];
    for (int i = 0; i < n; i++)
	{
		cin >> denominaciones[i];
	}
	int precio = 0;
	int pago = 0;

	cin >> precio;
	cin >> pago;
	int cambio = pago - precio;

	ordenarDenominaciones(denominaciones, n);

	int* monedasDinamica = new int[n];
	int* monedasAvaro = new int[n];
	programacionDinamica(denominaciones, n, cambio, monedasDinamica);
	algoritmoAvaro(denominaciones, n, cambio, monedasAvaro);
	for (int i = 0; i < n; i++)
	{
		cout << monedasDinamica[i] << endl;
	}
	for (int i = 0; i < n; i++)
	{
		cout << monedasAvaro[i] << endl;
	}
	delete[] denominaciones;
	delete[] monedasDinamica;
	delete[] monedasAvaro;
	return 0;
}