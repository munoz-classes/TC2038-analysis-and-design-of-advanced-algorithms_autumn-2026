#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

// -----------------------------------------------------------------------------
// Parte 1: Programación Dinámica
//
// Complejidad Temporal: O(N * C)
// donde N es el número de monedas disponibles y C es el cambio a dar (Q - P).
// Hacemos dos ciclos anidados para calcular el mínimo de monedas de 1 hasta C.
//
// Complejidad Espacial: O(C)
// Usamos arreglos de tamaño (C + 1) para guardar los cálculos y la moneda usada.
// -----------------------------------------------------------------------------
void resolverDinamica(const vector<int>& monedas, int cambio) {
    int n = monedas.size();
    int infinito = 1e9;
    
    // dp[i] guarda el mínimo de monedas para juntar el monto i
    vector<int> dp(cambio + 1, infinito);
    // padre[i] guarda qué moneda usamos para llegar al monto i (para reconstruir la respuesta)
    vector<int> padre(cambio + 1, -1);
    
    dp[0] = 0; // Para 0 pesos se necesitan 0 monedas
    
    for (int i = 1; i <= cambio; i++) {
        for (int j = 0; j < n; j++) {
            if (monedas[j] <= i) {
                if (dp[i - monedas[j]] + 1 < dp[i]) {
                    dp[i] = dp[i - monedas[j]] + 1;
                    padre[i] = j;
                }
            }
        }
    }
    
    // Contar cuántas monedas usamos de cada denominación
    vector<int> conteo(n, 0);
    int aux = cambio;
    
    if (dp[cambio] != infinito) {
        while (aux > 0) {
            int indiceMoneda = padre[aux];
            if (indiceMoneda == -1) break;
            conteo[indiceMoneda]++;
            aux -= monedas[indiceMoneda];
        }
    }
    
    // Imprimir de mayor a menor denominación
    for (int i = n - 1; i >= 0; i--) {
        cout << conteo[i] << "\n";
    }
}

// -----------------------------------------------------------------------------
// Parte 2: Algoritmo Avaro (Greedy)
//
// Complejidad Temporal: O(N)
// Recorremos las denominaciones una sola vez tomando las más grandes primero.
//
// Complejidad Espacial: O(N)
// Solo guardamos un vector para contar las monedas usadas por denominación.
// -----------------------------------------------------------------------------
void resolverAvaro(const vector<int>& monedas, int cambio) {
    int n = monedas.size();
    vector<int> conteo(n, 0);
    int restante = cambio;
    
    // Recorrer de la moneda más grande a la más chica
    for (int i = n - 1; i >= 0; i--) {
        if (restante >= monedas[i]) {
            conteo[i] = restante / monedas[i];
            restante = restante % monedas[i];
        }
    }
    
    // Imprimir de mayor a menor denominación
    for (int i = n - 1; i >= 0; i--) {
        cout << conteo[i] << "\n";
    }
}

int main() {
    // Lectura de datos
    int n;
    if (!(cin >> n)) return 0;
    
    vector<int> monedas(n);
    for (int i = 0; i < n; i++) {
        cin >> monedas[i];
    }
    
    int p, q;
    cin >> p >> q;
    
    int cambio = q - p;
    
    // monedas estén de menor a mayor
    sort(monedas.begin(), monedas.end());
    
    // Programación Dinámica
    resolverDinamica(monedas, cambio);
    
    // Algoritmo Avaro
    resolverAvaro(monedas, cambio);
    
    return 0;
}