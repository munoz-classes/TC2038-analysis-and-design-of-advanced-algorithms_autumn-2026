import java.util.ArrayList;
import java.util.Arrays;

// Claudia Vanessa Hermosillo Diaz A01773449 (tomando como referencia el codigo visto en clase en python) y con muchos comentarios para explicar todo 

public class Monedas {

    // void main donde se define el arreglo de monedas y el cambio que se pasaran a 
    // la funcion obtener_vuelta para obtener el resultado y posteriormente imprimirse
    public static void main(String[] args) {
        int[] monedas = {2, 5, 10};
        int cambio = 10;
        ArrayList<Integer> resultado = obtener_vuelta(monedas, cambio);
        System.out.println(resultado);
    }

// definición de la función obtener_vuelta con el arreglo de monedas y el cambio como parametros
    public static ArrayList<Integer> obtener_vuelta(int[] monedas, int cambio) {
        // primero reacomodamos el arreglo de monedas 
        Arrays.sort(monedas);

        //creamos el array que guarda el resultado
        ArrayList<Integer> resultado = new ArrayList<>();

        /* 
        como la funcion sort de array reacomoda los numeros en orden numérico, para poder ir de la moneda más grande
        a la más chica recorremos el array desde su ultimo elemento hasta el primero (a diferencia del codigo en python 
        donde se reacomodo de mayor a menor) lo demás sigue la misma lógica
        */

        for(int i = monedas.length - 1; i >= 0; i--) {
            while(cambio >= monedas[i]) {
                cambio -= monedas[i];
                resultado.add(monedas[i]);
                
            }
        }
        if (cambio == 0) {
            return resultado;
        } else {
            return new ArrayList<>();
        }
    }
}