#ifndef DP_H
#define DP_H

#include <vector>
#include <climits>
using namespace std;

// va calculando el minimo de monedas para cada monto del 0 al cambio
// O(n * cambio)
bool progDinamica(vector<int>& monedas, int cambio, vector<int>& resultado) {
	int n = monedas.size();
	vector<int> minMonedas(cambio + 1, INT_MAX);
	vector<int> usada(cambio + 1, -1);
	minMonedas[0] = 0;

	int monto = 1;
	while (monto <= cambio) {
		int i = 0;
		while (i < n) {
			if (monedas[i] <= monto && minMonedas[monto - monedas[i]] != INT_MAX) {
				int candidato = minMonedas[monto - monedas[i]] + 1;
				if (candidato < minMonedas[monto]) {
					minMonedas[monto] = candidato;
					usada[monto] = monedas[i];
				}
			}
			i = i + 1;
		}
		monto = monto + 1;
	}

	resultado.assign(n, 0);
	if (minMonedas[cambio] == INT_MAX) {
		return false;
	}

	// de aqui para abajo se reconstruye que monedas se usaron
	int restante = cambio;
	while (restante > 0) {
		int moneda = usada[restante];
		int idx = 0;
		while (monedas[idx] != moneda) {
			idx = idx + 1;
		}
		resultado[idx] = resultado[idx] + 1;
		restante = restante - moneda;
	}
	return true;
}

#endif
