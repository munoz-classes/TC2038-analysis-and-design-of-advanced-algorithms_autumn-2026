// Cambio de monedas - Programacion Dinamica y Avaro
// Ileana Tapia Castillo - A01773374
// 29/08/2026

#include <iostream>
#include <vector>
#include <algorithm>
#include "dp.h"
#include "avaro.h"

using namespace std;

void imprimir(vector<int>& resultado, bool ok) {
	int i = 0;
	while (i < (int)resultado.size()) {
		cout << (ok ? resultado[i] : 0) << endl;
		i = i + 1;
	}
}

int main() {
	// lee N y las N denominaciones
	int n;
	cin >> n;

	vector<int> monedas;
	int i = 0;
	while (i < n) {
		int val;
		cin >> val;
		monedas.push_back(val);
		i = i + 1;
	}
	sort(monedas.rbegin(), monedas.rend());

	// precio y con cuanto se paga, el cambio es la resta
	int precio;
	int pago;
	cin >> precio;
	cin >> pago;
	int cambio = pago - precio;

	vector<int> resDp;
	vector<int> resAvaro;
	bool okDp = progDinamica(monedas, cambio, resDp);
	bool okAvaro = avaro(monedas, cambio, resAvaro);

	imprimir(resDp, okDp);
	imprimir(resAvaro, okAvaro);

	return 0;
}
