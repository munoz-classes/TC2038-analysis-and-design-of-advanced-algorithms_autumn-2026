#ifndef AVARO_H
#define AVARO_H

#include <vector>
using namespace std;

// en cada denominacion agarra todas las monedas que le quepan al restante
// O(n)
bool avaro(vector<int>& monedas, int cambio, vector<int>& resultado) {
	int n = monedas.size();
	resultado.assign(n, 0);
	int restante = cambio;

	int i = 0;
	while (i < n) {
		int cantidad = restante / monedas[i];
		resultado[i] = cantidad;
		restante = restante - cantidad * monedas[i];
		i = i + 1;
	}
	return restante == 0;
}

#endif
