/*
Actividad 1.2 Implementacion de la tecnica de programacion "Programacion dinamica" y "algoritmos avaros"
Cambio de monedas: Calcula cuantas monedas de cada valor o denominacion se usan para dar un cambio, con la
minima cantidad de monedas posible.
Lee N valores o denominaciones, un precio P y un pago Q desde la entrada.
El cambio a dar es el resultado de Q - P.
Se resuelve el problema con dos tecnicas y muestra ambos resultados:
primero el de programacion dinamica, y luego un algoritmo avaro.
Cada resultado es el conteo de monedas por valor, de mayor a menor, uno por linea.

Autor: Iker Octavio Silva Campos - A01770545
Fecha de creacion: 26 de agosto de 2026
*/

#include <iostream>
#include <vector>
#include <algorithm>

/*
Calcula el cambio con programacion dinamica, garantizando la minima cantidad de monedas.
Construye una tabla con el minimo de monedas para cada monto de 0 al cambio, y luego reconstruye cuantas monedas
de cada valor o denominacion se usaron.
Parametros:
    valores: las denominaciones de moneda disponibles.
    cambio: el monto de cambio a formar.
Retorno:
    un vector con el conteo de monedas por denominacion, ordenado de mayor a menor.
    Devuelve un vector vacio si el cambio no se puede formar con los valores dados.
Complejidad: 
    O(N * C), en donde N es el numero de valores y C es el cambio.
    La complejidad depende del valor del cambio, no solamente de cuantos datos hay.
    Si el cambio fuese gigantesco, el algoritmo se volveria lento. Es su costo por garantizar el optimo.
*/

std::vector<int> dinamica(std::vector<int> valores, int cambio){
    int INFINITO = 1000000;
    std::vector<int> tablaDinamica(cambio + 1, INFINITO);
    tablaDinamica[0] = 0;
    for (int monto = 1; monto <= cambio; monto++){
        for (size_t i = 0; i < valores.size(); i++){
            if (valores[i] <= monto){
                int opcion = 1 + tablaDinamica[monto - valores[i]];
                if (opcion < tablaDinamica[monto]){
                    tablaDinamica[monto] = opcion;
                }
            }
        }
    }
    if (tablaDinamica[cambio] >= INFINITO){
        std::vector<int> vacio;
        return vacio;
    }
    std::sort(valores.begin(), valores.end(), std::greater<int>());
    std::vector<int> conteos(valores.size(), 0);
    int monto = cambio;
    while (monto > 0){
        bool encontrada = false;
        for (size_t i = 0; i < valores.size() && !encontrada; i++){
            if (monto - valores[i] >= 0 && tablaDinamica[monto - valores[i]] + 1 == tablaDinamica[monto]){
                conteos[i] = conteos[i] + 1;
                monto = monto - valores[i];
                encontrada = true;
            }
        }
    }
    return conteos;
}

/*
Calcula el cambio con un algoritmo avaro: toma el mayor valor que quepa en cada paso. Es rapido, pero no siempre da la
solucion optima.
Parametros:
    valores: las denominaciones de moneda disponibles.
    cambio: el monto de cambio a formar.
Retorno:
    un vector con el conteo de monedas por denominacion, ordenado de mayor a menor valor.
Complejidad:
    O(N log N), dominada por el ordenamiento de los valores.
*/

std::vector<int> greedy(std::vector<int> valores, int cambio){
    std::sort(valores.begin(), valores.end(), std::greater<int>());
    std::vector<int> conteos;
    for (size_t i = 0; i < valores.size(); i++){
        int cantidad = cambio / valores[i];
        conteos.push_back(cantidad);
        cambio = cambio % valores[i];
    }
    return conteos;
}

/*
Funcion principal: Lee los datos, calcula el cambio y muestra los conteos de monedas usando ambas tecnicas.
Si el cambio no se puede completar, avisa con un mensaje y no ejecuta el algoritmo avaro.
Retorno: 0 si es que el programa termina correctamente.
*/

int main() {
    int n = 0;
    std::cin >> n;
    std::vector<int> valores;
    for (int i = 0; i < n; i++){
        int val = 0;
        std::cin >> val;
        valores.push_back(val);
    }
    int p = 0;
    int q = 0;
    std::cin >> p;
    std::cin >> q;
    int cambio = q - p;
    std::vector<int> resultadoDinamica = dinamica(valores, cambio);
    if (resultadoDinamica.size() == 0){
        std::cout << "No es posible dar el cambio" << std::endl;
    } else { 
        for (size_t i = 0; i < resultadoDinamica.size(); i++){
            std::cout << resultadoDinamica[i] << std::endl;
        }
        std::vector<int> resultadoGreedy = greedy(valores, cambio);
        for (size_t i = 0; i < resultadoGreedy.size(); i++){
            std::cout << resultadoGreedy[i] << std::endl;
        }
    }
    return 0;
}

/*
CASOS DE PRUEBA:
Cada diagonal representa un cambio de linea:

Caso 1 (normal, valores aleatorios. Hay monedas de 1,3,4. El precio es 0 y recibimos 6 de pago):
    Entrada: 3 / 1 / 3 / 4 / 0 / 6
    Salida: 0 / 2 / 0 / 1 / 0 / 2
Caso 2 (Cambio de 0, pagó exacto):
    Entrada: 3 / 1 / 3 / 4 / 10 / 10
    Salida: 0 / 0 / 0 / 0 / 0 / 0
Caso 3 (Un solo valor de moneda disponible):
    Entrada: 1 / 1 / 7 / 10
    Salida: 3 / 3
Caso 4 (El cambio no se puede dar con los valores de monedas disponibles):
    Entrada: 3 / 2 / 5 / 10 / 4 / 5
    Salida: No es posible dar el cambio
*/