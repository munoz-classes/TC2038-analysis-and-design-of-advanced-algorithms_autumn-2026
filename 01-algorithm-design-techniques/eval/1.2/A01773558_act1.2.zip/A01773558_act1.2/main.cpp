/*
 * Actividad 1.2 - Problema del cambio de monedas
 * Alumno: Rene Cano (matricula: A01773558)
 * Descripcion: Resuelve el problema del cambio de monedas usando dos
 *              tecnicas vistas en clase: programacion dinamica y un
 *              algoritmo avaro (greedy).
 *
 * Entrada (por entrada estandar):
 *   - N: numero de denominaciones
 *   - N valores enteros: las denominaciones disponibles (uno por linea)
 *   - P: precio del producto
 *   - Q: billete o moneda con el que se paga
 *   El cambio a devolver es (Q - P).
 *
 * Salida:
 *   - N valores: numero de monedas por denominacion (de mayor a menor),
 *     usando PROGRAMACION DINAMICA.
 *   - N valores: lo mismo pero usando el ALGORITMO AVARO.
 */

#include <iostream>
#include <vector>
#include <algorithm>
#include <functional>
using namespace std;

int main(){
    int n;
    cin >> n;

    // Leer las denominaciones
    vector<int> denominaciones(n);
    for (int i = 0; i < n; i++){
        cin >> denominaciones[i];

    }

    int precio, pago;
    cin >> precio >> pago;

    int cambio = pago - precio;

    // Ordenar de mayor a menor para imprimir en ese orden
    sort(denominaciones.begin(), denominaciones.end(), greater<int>());

    // 1) PROGRAMACION DINAMICA
    // Complejidad: O(cambio * N) en tiempo y O(cambio) en espacio.
    // Se calcula el minimo numero de monedas para cada cantidad
    // desde 0 hasta 'cambio'. Ademas guardamos que moneda se uso
    // en cada cantidad para poder reconstruir la solucion.

    const int INF = 1000000000;
    vector<int> dp(cambio + 1, INF); // minimo de monedas por cantidad
    vector<int> monedaUsada(cambio + 1, -1); // moneda usada en cada cantidad
    dp[0] = 0;

    for (int cantidad = 1; cantidad <= cambio; cantidad++){
        for (int j=0; j < n; j++){
            int moneda = denominaciones[j];
            if (moneda <= cantidad && dp[cantidad - moneda] + 1 < dp[cantidad]){
                dp[cantidad] = dp[cantidad - moneda] + 1;
                monedaUsada[cantidad] = moneda;
            }
        }
    }

    // Reconstruir cuantas monedas de cada denominacion se usaron
    vector<int> conteoDP(n, 0);
    int resto = cambio;
    while (resto > 0 && monedaUsada[resto] != -1){
        int moneda = monedaUsada[resto];
        for (int j = 0; j < n; j++){
            if (denominaciones[j] == moneda) {
                conteoDP[j]++;
                break;
            }
        }
        resto -= moneda;
    }

    // Imprimir resultado de programacion dinamica
    for (int j = 0; j < n; j++){
        cout << conteoDP[j] << "\n";
    }


    // 2) ALGORITMO AVARO
    // Complejidad: O(N) en tiempo (mas O(N log N) por el ordenamiento
    // que ya hicimos arriba) y O(N) en espacio.
    // En cada paso se toma la mayor cantidad posible de la moneda
    // mas grande que quepa en lo que falta por dar.
    vector<int> conteoAvaro(n,0);
    int restante = cambio;
    for (int j = 0; j < n; j++){
        conteoAvaro[j] = restante / denominaciones[j];
        restante = restante % denominaciones[j];

    }

    // Imprimir resultado del algoritmo avaro
    for (int j = 0; j < n; j++){
        cout << conteoAvaro[j] << "\n";
    }


    return 0;
}