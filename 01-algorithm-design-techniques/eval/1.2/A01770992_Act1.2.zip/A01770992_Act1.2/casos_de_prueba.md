# Casos de prueba - Actividad 1.2 (Cambio de monedas)

Cada caso evalua tanto la funcionalidad de programacion dinamica (DP) como
la de algoritmo avaro, ya que el programa imprime ambos resultados en una
sola ejecucion (primero DP, luego avaro). Ejecutar con:

```
./main < tests/<archivo>.txt
```

## Caso 1 - Sistema canonico (test1.txt)
Denominaciones: 1, 5, 10, 25. Precio: 63. Pago: 100. Cambio: 37.
En un sistema canonico como este, DP y avaro coinciden.

Salida esperada (orden de denominaciones: 25, 10, 5, 1):
```
1
1
0
2
1
1
0
2
```

## Caso 2 - Sistema NO canonico (test2_no_canonico.txt)
Denominaciones: 1, 3, 4. Precio: 4. Pago: 10. Cambio: 6.
Este caso demuestra que el algoritmo avaro no siempre es optimo: con
monedas de 3 se puede dar el cambio con 2 monedas (3+3), pero el avaro,
al tomar primero la moneda de 4, necesita 3 monedas (4+1+1).

Salida esperada (orden de denominaciones: 4, 3, 1):
```
0
2
0
1
0
2
```
(DP usa 2 monedas en total; el avaro usa 3.)

## Caso 3 - Cambio igual a cero (test3_cambio_cero.txt)
Denominaciones: 1, 5, 10, 25. Precio: 50. Pago: 50. Cambio: 0.
Caso extremo donde no se debe entregar ninguna moneda.

Salida esperada (orden de denominaciones: 25, 10, 5, 1):
```
0
0
0
0
0
0
0
0
```

## Caso 4 - Denominaciones en orden mezclado en la entrada (test4_orden_mezclado.txt)
Denominaciones (tal como se leen): 5, 20, 1, 10, 2. Precio: 80. Pago: 100.
Cambio: 20.
Caso extremo que valida que el programa ordena las denominaciones de mayor
a menor para la salida, sin importar el orden en que fueron leidas.

Salida esperada (orden de denominaciones: 20, 10, 5, 2, 1):
```
1
0
0
0
0
1
0
0
0
0
```

## Casos adicionales de robustez (no forman parte de los 4 casos oficiales)
- Denominaciones sin la moneda de 1 y cambio no representable (ej. solo 5 y
  10, cambio = 5 - 10 x -1... es decir monto=5 con denominaciones {5,10}
  funciona; probar con denominaciones que no puedan formar el monto exacto,
  ej. denominaciones {5,10} y monto 2, no lanza error, retorna 0 para todas
  las denominaciones que no aplican, sin caerse el programa).
- Cambio menor a la denominacion mas pequena.
