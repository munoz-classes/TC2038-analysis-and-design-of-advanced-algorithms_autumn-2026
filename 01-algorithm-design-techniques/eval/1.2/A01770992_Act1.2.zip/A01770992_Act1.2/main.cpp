/*
 * Descripcion: Resuelve el problema del cambio de monedas utilizando dos
 *              tecnicas de programacion: programacion dinamica (DP) y un
 *              algoritmo avaro (greedy). El programa lee N denominaciones,
 *              un precio P y un pago Q, calcula el cambio (Q - P) y muestra,
 *              de mayor a menor, el numero de monedas de cada denominacion
 *              requerido para dar el cambio, primero con DP y despues con
 *              el algoritmo avaro.
 * Autor: Yael Sebastian Gonzalez Hernandez, Matricula: A01770992
 * Fecha de creacion: 29/08/2026
 */

#include <iostream>
#include <vector>
#include <algorithm>
#include <climits>
#include <unordered_map>

const int SIN_SOLUCION = INT_MAX / 2;

/*
 * Lee desde la entrada estandar las N denominaciones de moneda disponibles.
 * Parametros:
 *   cantidadDenominaciones: numero de denominaciones a leer.
 * Valor de retorno:
 *   vector con las N denominaciones en el orden en que fueron leidas.
 * Complejidad computacional: O(N), donde N es cantidadDenominaciones.
 */
std::vector<int> leerDenominaciones(int cantidadDenominaciones) {
    std::vector<int> denominaciones(cantidadDenominaciones, 0);
    for (int indice = 0; indice < cantidadDenominaciones; indice = indice + 1) {
        std::cin >> denominaciones[indice];
    }
    return denominaciones;
}

/*
 * Calcula, mediante programacion dinamica, el numero minimo de monedas de
 * cada denominacion necesarias para completar un monto dado.
 * Parametros:
 *   monto: cantidad de cambio que se debe formar.
 *   denominacionesOrdenadas: denominaciones disponibles, de mayor a menor.
 * Valor de retorno:
 *   vector alineado con denominacionesOrdenadas, con el numero de monedas
 *   de cada denominacion que forman el cambio optimo.
 * Complejidad computacional: O(monto * N), donde N es el numero de
 *   denominaciones. El espacio utilizado es O(monto).
 */
std::vector<int> calcularCambioDp(int monto, const std::vector<int>& denominacionesOrdenadas) {
    std::vector<int> numeroMinimoMonedas(monto + 1, SIN_SOLUCION);
    std::vector<int> monedaUsada(monto + 1, 0);
    numeroMinimoMonedas[0] = 0;

    for (int subMonto = 1; subMonto <= monto; subMonto = subMonto + 1) {
        for (int indice = 0; indice < static_cast<int>(denominacionesOrdenadas.size()); indice = indice + 1) {
            int denominacionActual = denominacionesOrdenadas[indice];
            if (denominacionActual <= subMonto && numeroMinimoMonedas[subMonto - denominacionActual] + 1 < numeroMinimoMonedas[subMonto]) {
                numeroMinimoMonedas[subMonto] = numeroMinimoMonedas[subMonto - denominacionActual] + 1;
                monedaUsada[subMonto] = denominacionActual;
            }
        }
    }

    std::unordered_map<int, int> conteoPorDenominacion;
    for (int indice = 0; indice < static_cast<int>(denominacionesOrdenadas.size()); indice = indice + 1) {
        conteoPorDenominacion[denominacionesOrdenadas[indice]] = 0;
    }

    int montoRestante = monto;
    while (montoRestante > 0 && monedaUsada[montoRestante] != 0) {
        conteoPorDenominacion[monedaUsada[montoRestante]] = conteoPorDenominacion[monedaUsada[montoRestante]] + 1;
        montoRestante = montoRestante - monedaUsada[montoRestante];
    }

    std::vector<int> resultado;
    for (int indice = 0; indice < static_cast<int>(denominacionesOrdenadas.size()); indice = indice + 1) {
        resultado.push_back(conteoPorDenominacion[denominacionesOrdenadas[indice]]);
    }
    return resultado;
}

/*
 * Calcula, mediante un algoritmo avaro, el numero de monedas de cada
 * denominacion necesarias para completar un monto dado, tomando siempre
 * la denominacion mas grande posible en cada paso.
 * Parametros:
 *   monto: cantidad de cambio que se debe formar.
 *   denominacionesOrdenadas: denominaciones disponibles, de mayor a menor.
 * Valor de retorno:
 *   vector alineado con denominacionesOrdenadas, con el numero de monedas
 *   de cada denominacion que el algoritmo avaro utiliza.
 * Complejidad computacional: O(N), donde N es el numero de denominaciones.
 */
std::vector<int> calcularCambioAvaro(int monto, const std::vector<int>& denominacionesOrdenadas) {
    std::vector<int> resultado;
    int montoRestante = monto;
    for (int indice = 0; indice < static_cast<int>(denominacionesOrdenadas.size()); indice = indice + 1) {
        int denominacionActual = denominacionesOrdenadas[indice];
        int monedasUsadas = montoRestante / denominacionActual;
        montoRestante = montoRestante - monedasUsadas * denominacionActual;
        resultado.push_back(monedasUsadas);
    }
    return resultado;
}

/*
 * Imprime, una por linea, la cantidad de monedas contenida en un vector
 * de resultados.
 * Parametros:
 *   conteoMonedas: vector con el numero de monedas por denominacion.
 * Valor de retorno: ninguno.
 * Complejidad computacional: O(N), donde N es el tamano de conteoMonedas.
 */
void imprimirConteoMonedas(const std::vector<int>& conteoMonedas) {
    for (int indice = 0; indice < static_cast<int>(conteoMonedas.size()); indice = indice + 1) {
        std::cout << conteoMonedas[indice] << "\n";
    }
}

/*
 * Funcion principal. Lee las denominaciones, el precio y el pago, calcula
 * el cambio y muestra la solucion obtenida con programacion dinamica y con
 * el algoritmo avaro.
 * Complejidad computacional: O(cambio * N), dominada por la etapa de
 *   programacion dinamica.
 */
int main() {
    int cantidadDenominaciones = 0;
    std::cin >> cantidadDenominaciones;

    std::vector<int> denominaciones = leerDenominaciones(cantidadDenominaciones);

    int precio = 0;
    int pago = 0;
    std::cin >> precio;
    std::cin >> pago;

    int cambio = pago - precio;

    std::vector<int> denominacionesOrdenadas = denominaciones;
    std::sort(denominacionesOrdenadas.begin(), denominacionesOrdenadas.end(), std::greater<int>());

    std::vector<int> resultadoDp = calcularCambioDp(cambio, denominacionesOrdenadas);
    std::vector<int> resultadoAvaro = calcularCambioAvaro(cambio, denominacionesOrdenadas);

    imprimirConteoMonedas(resultadoDp);
    imprimirConteoMonedas(resultadoAvaro);

    return 0;
}
