# A01770422_Act1.2 — Cambio de monedas (programación dinámica y algoritmo avaro)

## Cómo ejecutarlo en Linux con entrada redirigida

```bash
python3 main.py < in.txt
```

o, dándole permiso de ejecución (ya trae shebang `#!/usr/bin/env python3`):

```bash
chmod +x main.py
./main.py < in.txt
```

## Formato de entrada

Un valor por línea:

```
N          # cuántas denominaciones hay
d1
...
dN         # las N denominaciones
P          # precio del producto
Q          # con cuánto se pagó
```

El cambio a devolver es `Q - P`.

## Formato de salida

Primero N líneas con el número de monedas de cada denominación **de mayor a
menor** según **programación dinámica**, y luego otras N líneas con lo mismo
según el **algoritmo avaro**. Si alguno de los dos métodos no encuentra
solución exacta, imprime ceros en sus N líneas.

## Ejemplo (el `in.txt` incluido)

Entrada: denominaciones 10, 5, 2 — precio 0, se paga con 18 → cambio 18.

```
1      <- DP:    1 moneda de 10
0      <- DP:    0 monedas de 5
4      <- DP:    4 monedas de 2   (total 5 monedas, óptimo)
0      <- Avaro: se atoró
0
0
```

## Por qué el avaro se atora

El avaro toma en cada paso la moneda más grande que quepa y **nunca se
arrepiente** de una decisión ya tomada. Con el cambio de 18 y las monedas
{10, 5, 2} agarra el 10, luego el 5 y se queda con 3 pendientes, que no puede
formar con monedas de 2. La solución sí existía (10 + 2 + 2 + 2 + 2), pero el
avaro ya se había comprometido con el 5. La programación dinámica, en cambio,
resuelve todos los montos de 1 hasta el cambio y se queda con el mejor camino,
así que siempre encuentra la solución óptima si existe.

## Complejidad

| Método | Tiempo | Espacio |
|---|---|---|
| Programación dinámica | O(cambio × N) | O(cambio) |
| Algoritmo avaro | O(N log N) por el ordenamiento | O(N) |

## Contenido de la carpeta

- `main.py` — el programa.
- `in.txt` — caso de prueba de ejemplo.
- `imagenes/` — fotos del pizarrón y de las diapositivas con el análisis y el
  pseudocódigo que se fue refinando en clase (de la versión con `IF`, a la de
  `while`, a la de `for` con su complejidad, hasta la firma final en Python).
