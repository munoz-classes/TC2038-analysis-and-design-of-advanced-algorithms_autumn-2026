#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Actividad 1.2 - Problema del cambio de monedas
Matricula: A01770422

Resuelvo el mismo problema con dos tecnicas distintas y comparo sus resultados:

  1) Programacion dinamica: siempre me da el numero MINIMO de monedas,
     y si el cambio no se puede formar me lo dice con certeza.

  2) Algoritmo avaro (greedy): en cada paso agarro la moneda mas grande que
     quepa. Es rapidisimo, pero se atora: si al final le sobra cambio,
     se queda sin solucion aunque SI existiera una con monedas mas chicas.

ENTRADA (por entrada estandar, un valor por linea):
    N        -> cuantas denominaciones hay
    d1..dN   -> las N denominaciones, una por linea
    P        -> precio del producto
    Q        -> con cuanto se pago

SALIDA:
    N lineas con las monedas de cada denominacion (de mayor a menor) segun
    programacion dinamica, y luego otras N lineas con lo mismo segun el avaro.

Como lo corro en Linux con entrada redirigida:
    python3 main.py < in.txt
    ./main.py < in.txt      (si le doy permiso con: chmod +x main.py)
"""

import sys


def leer_entrada():
    """Leo TODA la entrada de un jalon y la parto en numeros.

    Lo hago asi porque a mi no me importa si el archivo trae un numero por
    linea, varios separados por espacios, o lineas en blanco de mas: al
    partir todo el texto por espacios me quedo nada mas con los numeros,
    en el mismo orden en que vienen.
    """
    numeros = sys.stdin.read().split()

    # Si me llega la entrada vacia prefiero no truenar: simplemente no hay nada
    # que resolver y regreso None para que el programa termine tranquilo.
    if not numeros:
        return None

    numeros = [int(x) for x in numeros]

    i = 0
    n = numeros[i]
    i += 1

    # Aqui recorto las N denominaciones que siguen.
    denominaciones = numeros[i:i + n]
    i += n

    # Y al final vienen el precio y con lo que se pago.
    p = numeros[i]
    q = numeros[i + 1]

    return n, denominaciones, p, q


def cambio_dinamica(cambio, denominaciones):
    """Programacion dinamica: construyo la respuesta de abajo hacia arriba.

    Mi idea es esta: en vez de adivinar que monedas dar, resuelvo primero el
    problema para el monto 1, luego para el 2, luego para el 3... hasta llegar
    al cambio que me piden. Cuando llego a un monto 'a', ya tengo resueltos
    todos los montos menores, asi que solo pruebo cada denominacion y me quedo
    con la que menos monedas me deje.

    Regreso una lista con cuantas monedas de cada denominacion uso, o None si
    el cambio de plano no se puede formar con esas denominaciones.
    """
    # dp[a] = el minimo numero de monedas con el que puedo formar el monto 'a'.
    # Arranco todo en infinito para decir "todavia no se como formar esto".
    INFINITO = float('inf')
    dp = [INFINITO] * (cambio + 1)

    # usada[a] = el indice de la moneda que use para llegar al monto 'a'.
    # Esta lista es mi "miga de pan": al final la recorro al reves para saber
    # exactamente que monedas conforman la respuesta.
    usada = [-1] * (cambio + 1)

    # El monto 0 lo formo con cero monedas: no doy nada. De aqui parte todo.
    dp[0] = 0

    for a in range(1, cambio + 1):
        for i, moneda in enumerate(denominaciones):
            # Solo considero la moneda si cabe en el monto y si usarla me deja
            # con menos monedas de las que ya tenia apuntadas para este monto.
            if 0 < moneda <= a and dp[a - moneda] + 1 < dp[a]:
                dp[a] = dp[a - moneda] + 1
                usada[a] = i

    # Si al llegar al final sigo en infinito, es que no hay forma de armar el
    # cambio exacto. Lo digo con None en lugar de inventar una respuesta.
    if dp[cambio] == INFINITO:
        return None

    # Reconstruyo la solucion: le voy quitando al monto la moneda que apunte
    # en 'usada' y la voy contando, hasta quedar en cero.
    conteo = [0] * len(denominaciones)
    a = cambio
    while a > 0:
        i = usada[a]
        conteo[i] += 1
        a -= denominaciones[i]

    return conteo


def cambio_avaro(cambio, denominaciones):
    """Algoritmo avaro: siempre agarro la moneda mas grande que quepa.

    Aqui no pienso a futuro. Ordeno las denominaciones de mayor a menor y de
    cada una tomo todas las que pueda antes de pasar a la siguiente. Es muy
    rapido y con monedas "normales" (10, 5, 2, 1) me da la respuesta optima.

    Su problema es justo que no se arrepiente: como nunca regresa a soltar una
    moneda que ya tomo, hay denominaciones donde termina con cambio pendiente
    aunque si existiera solucion. Por eso, si al final me sobra algo, regreso
    None: el avaro se atoro.
    """
    conteo = [0] * len(denominaciones)
    restante = cambio

    # Recorro los indices ordenados por valor de moneda, de mayor a menor,
    # para no perder de vista en que posicion original iba cada denominacion.
    for i in sorted(range(len(denominaciones)),
                    key=lambda k: denominaciones[k], reverse=True):
        moneda = denominaciones[i]
        if moneda <= 0:
            continue  # una moneda de valor 0 o negativo la ignoro: no sirve
        # Con una division saco de golpe cuantas monedas de este valor caben.
        cuantas = restante // moneda
        conteo[i] = cuantas
        restante -= cuantas * moneda

    # Si no logre bajar el restante hasta cero, el avaro fallo.
    if restante != 0:
        return None

    return conteo


def main():
    datos = leer_entrada()
    if datos is None:
        return

    n, denominaciones, p, q = datos

    # El cambio es lo que sobra de lo que pago menos lo que costo.
    # Si el precio fuera mayor que el pago no hay nada que devolver, asi que
    # lo dejo en cero para no trabajar con numeros negativos.
    cambio = max(0, q - p)

    # Necesito el orden de mayor a menor para imprimir, pero no quiero perder
    # la posicion original de cada denominacion, asi que ordeno los INDICES.
    orden = sorted(range(n), key=lambda k: denominaciones[k], reverse=True)

    resultado_dp = cambio_dinamica(cambio, denominaciones)
    resultado_avaro = cambio_avaro(cambio, denominaciones)

    # Cuando alguna de las dos tecnicas no encontro solucion, imprimo ceros:
    # asi la salida conserva siempre las mismas N lineas por metodo y se puede
    # comparar renglon con renglon sin sorpresas.
    if resultado_dp is None:
        resultado_dp = [0] * n
    if resultado_avaro is None:
        resultado_avaro = [0] * n

    # Junto todo en una sola cadena y la imprimo de una vez, que sale mas
    # barato que hacer un print por linea.
    salida = []
    for i in orden:
        salida.append(str(resultado_dp[i]))
    for i in orden:
        salida.append(str(resultado_avaro[i]))

    sys.stdout.write("\n".join(salida) + "\n")


if __name__ == "__main__":
    main()
