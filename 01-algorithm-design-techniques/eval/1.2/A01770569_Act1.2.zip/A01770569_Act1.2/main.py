import sys

datos = list(map(int, sys.stdin.read().split()))

N = datos[0]

monedas = datos[1:N+1]
P = datos[N+1]
Q = datos[N+2]

cambio = Q - P

monedas.sort(reverse=True)

# PROGRAMACION DINAMICA
mejor = [0] + [999999] * cambio
usada = [-1] * (cambio + 1)

for cantidad in range(1, cambio + 1):
    for i in range(N):
        if monedas[i] <= cantidad:
            if mejor[cantidad - monedas[i]] + 1 < mejor[cantidad]:
                mejor[cantidad] = mejor[cantidad - monedas[i]] + 1
                usada[cantidad] = i

resultadoDP = [0] * N
cantidad = cambio

while cantidad > 0:
    i = usada[cantidad]
    resultadoDP[i] += 1
    cantidad -= monedas[i]

# ALGORITMO AVARO
resultadoAvaro = [0] * N
restante = cambio

for i in range(N):
    resultadoAvaro[i] = restante // monedas[i]
    restante = restante % monedas[i]

# Resultado programación dinámica
for i in range(N):
    print(resultadoDP[i])

# Resulatdo avaro 
for i in range(N):
    print(resultadoAvaro[i])
