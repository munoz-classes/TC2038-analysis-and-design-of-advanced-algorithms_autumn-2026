"""
Enfoque: Greedy
Devolver cambio de monedas en base al billete entregado y el precio que se debe pagar.

Complejidad: O(m)
    siendo m el monto de cmabio y n el numero de denominaciones

Kiara Hermann San Lucas | A01771209
27/08/26
"""

def cambioMonedas(denominaciones, precio, billete):

    cambio = billete - precio
    resultado = []

    for moneda in denominaciones:
        cant = cambio // moneda
        resultado.append(cant)
        cambio %= moneda

    return resultado

# Casos prueba

# Caso 1: Cambio estándar con múltiples denominaciones
# Cambio a dar: 50 - 37 = 13
denominaciones1 = [20, 10, 5, 2, 1]
costo1, billete1 = 37, 50
res1 = cambioMonedas(denominaciones1, costo1, billete1)
print(f"Caso 1 | Denominaciones: {denominaciones1} | Precio: {costo1} | Pago: {billete1}")
print(f"Cambio total: {billete1 - costo1} | Resultado: {res1}\n")

# Caso 2: El pago es exacto (Cambio = 0)
# Cambio a dar: 100 - 100 = 0
denominaciones2 = [50, 20, 10, 5]
costo2, billete2 = 100, 100
res2 = cambioMonedas(denominaciones2, costo2, billete2)
print(f"Caso 2 | Denominaciones: {denominaciones2} | Precio: {costo2} | Pago: {billete2}")
print(f"Cambio total: {billete2 - costo2} | Resultado: {res2}\n")

# Caso 3: Cambio exacto con una sola denominación de mayor valor
# Cambio a dar: 200 - 100 = 100
denominaciones3 = [100, 50, 20, 10, 5]
costo3, billete3 = 100, 200
res3 = cambioMonedas(denominaciones3, costo3, billete3)
print(f"Caso 3 | Denominaciones: {denominaciones3} | Precio: {costo3} | Pago: {billete3}")
print(f"Cambio total: {billete3 - costo3} | Resultado: {res3}\n")

# Caso 4: Fallo del algoritmo avaro (Demostración de suboptimidad)
# Cambio a dar: 10 - 4 = 6
# Este enfoque dará [1, 0, 2]
# La solución óptima es 2 monedas de 3
denominaciones4 = [4, 3, 1]
costo4, billete4 = 4, 10
res4 = cambioMonedas(denominaciones4, costo4, billete4)
print(f"Caso 4 | Denominaciones: {denominaciones4} | Precio: {costo4} | Pago: {billete4}")
print(f"Cambio total: {billete4 - costo4} | Resultado: {res4}\n")