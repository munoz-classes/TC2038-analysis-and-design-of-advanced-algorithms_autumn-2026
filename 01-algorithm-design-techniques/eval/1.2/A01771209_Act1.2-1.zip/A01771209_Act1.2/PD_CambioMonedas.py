"""
Enfoque: Programación Dinámica
Devolver cambio de monedas en base al billete entregado y el precio que se debe pagar.

Complejidad: O(m x n)
    siendo m el monto de cmabio y n el numero de denominaciones

Kiara Hermann San Lucas | A01771209
27/08/26
"""

def cambioMonedasDP(denominaciones, precio, billete):
    cambio = billete - precio
    
    # dp[i] almacena el numero minimo de monedas para obtener el monto 'i'
    dp = [float('inf')] * (cambio + 1)
    dp[0] = 0
    
    # parent[i] guarda la moneda usada para formar el monto 'i'
    parent = [-1] * (cambio + 1)
    
    for i in range(1, cambio + 1):
        for moneda in denominaciones:
            if i - moneda >= 0 and dp[i - moneda] + 1 < dp[i]:
                dp[i] = dp[i - moneda] + 1
                parent[i] = moneda

    # si no es posible dar el cambio exacto con las denominaciones dadas
    if dp[cambio] == float('inf'):
        return None

    # reconstruccion de la solucion para contar cuantas monedas de cada denominacion se usaron
    conteo_monedas = {moneda: 0 for moneda in denominaciones}
    curr = cambio
    while curr > 0:
        moneda_usada = parent[curr]
        conteo_monedas[moneda_usada] += 1
        curr -= moneda_usada

    # retornar las cantidades alineadas con el orden de la lista 'denominaciones'
    return [conteo_monedas[moneda] for moneda in denominaciones]


# Casos prueba

# Caso 1: Cambio estándar
# Cambio a dar: 50 - 37 = 13
denominaciones1 = [20, 10, 5, 2, 1]
costo1, billete1 = 37, 50
res1 = cambioMonedasDP(denominaciones1, costo1, billete1)
print(f"Caso 1 | Denominaciones: {denominaciones1} | Precio: {costo1} | Pago: {billete1}")
print(f"Cambio total: {billete1 - costo1} | Resultado: {res1}\n")

# Caso 2: Pago exacto
denominaciones2 = [50, 20, 10, 5]
# Cambio a dar: 100 - 100 = 0
costo2, billete2 = 100, 100
res2 = cambioMonedasDP(denominaciones2, costo2, billete2)
print(f"Caso 2 | Denominaciones: {denominaciones2} | Precio: {costo2} | Pago: {billete2}")
print(f"Cambio total: {billete2 - costo2} | Resultado: {res2}\n")

# Caso 3: Moneda única de gran valor
# Cambio a dar: 200 - 100 = 100
denominaciones3 = [100, 50, 20, 10, 5]
costo3, billete3 = 100, 200
res3 = cambioMonedasDP(denominaciones3, costo3, billete3)
print(f"Caso 3 | Denominaciones: {denominaciones3} | Precio: {costo3} | Pago: {billete3}")
print(f"Cambio total: {billete3 - costo3} | Resultado: {res3}\n")

# Caso 4: Sistema no canónico (Solución óptima alcanzada)
# Cambio a dar: 10 - 4 = 6
denominaciones4 = [4, 3, 1]
costo4, billete4 = 4, 10
res4 = cambioMonedasDP(denominaciones4, costo4, billete4)
print(f"Caso 4 | Denominaciones: {denominaciones4} | Precio: {costo4} | Pago: {billete4}")
print(f"Cambio total: {billete4 - costo4} | Resultado: {res4}\n")