#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

// Programacion dinamica
vector<int> cambioDinamico(const vector<int>& monedas, int cambio) {
    int n = monedas.size();
    const int INF = cambio + 1;

    vector<int> dp(cambio + 1, INF);
    vector<int> ultimaMoneda(cambio + 1, -1);

    dp[0] = 0;

    for (int cantidad = 1; cantidad <= cambio; cantidad++) {
        for (int i = 0; i < n; i++) {
            if (monedas[i] <= cantidad &&
                dp[cantidad - monedas[i]] + 1 < dp[cantidad]) {
                dp[cantidad] = dp[cantidad - monedas[i]] + 1;
                ultimaMoneda[cantidad] = i;
            }
        }
    }

    vector<int> resultado(n, 0);

    if (dp[cambio] == INF) {
        return resultado;
    }

    int cantidad = cambio;
    while (cantidad > 0) {
        int i = ultimaMoneda[cantidad];
        resultado[i]++;
        cantidad -= monedas[i];
    }

    return resultado;
}

// Algoritmo avaro
vector<int> cambioAvaro(const vector<int>& monedas, int cambio) {
    int n = monedas.size();
    vector<int> resultado(n, 0);

    for (int i = 0; i < n; i++) {
        resultado[i] = cambio / monedas[i];
        cambio %= monedas[i];
    }

    return resultado;
}

int main() {
    int N;
    cin >> N;

    vector<int> monedas(N);
    for (int i = 0; i < N; i++) {
        cin >> monedas[i];
    }

    int P, Q;
    cin >> P >> Q;

    int cambio = Q - P;

    // Se ordenan las denominaciones de mayor a menor.
    sort(monedas.begin(), monedas.end(), greater<int>());

    // Primero: programacion dinamica.
    vector<int> dinamico = cambioDinamico(monedas, cambio);
    for (int i = 0; i < N; i++) {
        cout << dinamico[i] << endl;
    }

    // Despues: algoritmo avaro.
    vector<int> avaro = cambioAvaro(monedas, cambio);
    for (int i = 0; i < N; i++) {
        cout << avaro[i] << endl;
    }

    return 0;
}
