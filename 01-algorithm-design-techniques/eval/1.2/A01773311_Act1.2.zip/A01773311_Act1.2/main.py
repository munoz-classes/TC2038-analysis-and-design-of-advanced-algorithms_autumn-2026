# Programa que calcula el cambio de monedas usando programacion dinamica y algoritmo avaro
# Autor: Jose Angel Vargas Carranza, A01773311
# Fecha de creacion: 27/08/2026

import sys


def resolverDinamica(cambio, denominaciones):
    # Calcula el numero minimo de monedas por denominacion usando programacion dinamica
    # cambio: cantidad total a devolver
    # denominaciones: lista de denominaciones disponibles
    # regresa: lista con el conteo de monedas usadas por cada denominacion (mismo orden que denominaciones)
    infinito = float("inf")
    minimoMonedas = [0] + [infinito] * cambio
    monedaUsada = [0] * (cambio + 1)

    for valorActual in range(1, cambio + 1):
        for denominacion in denominaciones:
            if denominacion <= valorActual and minimoMonedas[valorActual - denominacion] + 1 < minimoMonedas[valorActual]:
                minimoMonedas[valorActual] = minimoMonedas[valorActual - denominacion] + 1
                monedaUsada[valorActual] = denominacion

    conteoPorDenominacion = {denominacion: 0 for denominacion in denominaciones}
    restante = cambio
    while restante > 0:
        denominacion = monedaUsada[restante]
        conteoPorDenominacion[denominacion] += 1
        restante -= denominacion

    return [conteoPorDenominacion[denominacion] for denominacion in denominaciones]


def resolverAvaro(cambio, denominaciones):
    # Calcula el numero de monedas por denominacion usando el algoritmo avaro
    # cambio: cantidad total a devolver
    # denominaciones: lista de denominaciones disponibles (de mayor a menor)
    # regresa: lista con el conteo de monedas usadas por cada denominacion (mismo orden que denominaciones)
    conteos = []
    restante = cambio
    for denominacion in denominaciones:
        conteos.append(restante // denominacion)
        restante = restante % denominacion

    return conteos


def main():
    # Lee la entrada estandar, calcula el cambio y muestra el resultado de ambas tecnicas
    datos = sys.stdin.read().split()
    indice = 0

    numDenominaciones = int(datos[indice])
    indice += 1

    denominaciones = []
    for _ in range(numDenominaciones):
        denominaciones.append(int(datos[indice]))
        indice += 1

    precio = int(datos[indice])
    indice += 1
    pago = int(datos[indice])

    cambio = pago - precio
    denominaciones.sort(reverse=True)

    resultadoDinamica = resolverDinamica(cambio, denominaciones)
    for cantidad in resultadoDinamica:
        print(cantidad)

    resultadoAvaro = resolverAvaro(cambio, denominaciones)
    for cantidad in resultadoAvaro:
        print(cantidad)


if __name__ == "__main__":
    main()
