
# Actividad 1.2 - Problema del cambio de monedas
# Alumno: A01770703


def cambio_dp(monedas, cambio):
    # Complejidad : O(n * cambio)

    n = len(monedas)
    resultado = [0] * n

    if cambio <= 0:
        return resultado

    numero_grande = 999999999

    # Complejidad espacial: O(cambio)
    minimo_monedas = [numero_grande] * (cambio + 1)
    minimo_monedas[0] = 0

    # Complejidad espacial: O(cambio)
    ultima_moneda = [-1] * (cambio + 1)

   
    for monto in range(1, cambio + 1):
        for i in range(n):
            valor_moneda = monedas[i]

            if valor_moneda <= monto:
                candidato = minimo_monedas[monto - valor_moneda] + 1

                if candidato < minimo_monedas[monto]:
                    minimo_monedas[monto] = candidato
                    ultima_moneda[monto] = i

    if minimo_monedas[cambio] >= numero_grande:
        return [-1] * n

   
    monto_restante = cambio

    while monto_restante > 0:
        i = ultima_moneda[monto_restante]

        resultado[i] = resultado[i] + 1

        monto_restante = monto_restante - monedas[i]

    return resultado


def cambio_greedy(monedas, cambio):
    # Complejidad: O(n)


    n = len(monedas)
    resultado = [0] * n

    if cambio <= 0:
        return resultado

    monto_restante = cambio

    # Complejidad : O(n)
    for i in range(n):
        valor_moneda = monedas[i]

        if valor_moneda <= 0:
            continue

        cuantas = monto_restante // valor_moneda

        resultado[i] = cuantas

        monto_restante = monto_restante - (cuantas * valor_moneda)

    if monto_restante != 0:
        return [-1] * n

    return resultado


def main():

    print("\n--- PROBLEMA DEL CAMBIO DE MONEDAS ---")
    print("Introduce los datos que se te solicitan.\n")

    # Numero de tipos de monedas
    n = int(input("¿Cuántos tipos de monedas tienes?: "))

    monedas = []

    # Complejidad temporal: O(n)
    for i in range(n):
        valor = int(input(f"¿Cuál es el valor de la moneda {i + 1}?: "))
        monedas.append(valor)

    # Precio del producto
    p = int(input("¿Cuál es el precio del producto?: "))

    # Dinero entregado
    q = int(input("¿Cuánto dinero entregaste?: "))

    # Complejidad : O(n log n)
    # Se ordenan las monedas de mayor a menor.
    monedas.sort(reverse=True)

    # Complejidad temporal: O(1)
    cambio = q - p

    print("\nCambio a entregar:", cambio)
    print("Monedas ordenadas:", monedas)

    # Programación Dinámica
   
    resultado_dp = cambio_dp(monedas, cambio)

    # Greedy
    # Complejidad : O(n)
    resultado_greedy = cambio_greedy(monedas, cambio)

    print("\n--- RESULTADO PROGRAMACIÓN DINÁMICA ---")

    # Complejidad : O(n)
    for i in range(n):
        print(f"Moneda de {monedas[i]}: {resultado_dp[i]}")

    print("\n--- RESULTADO GREEDY ---")

    # Complejidad : O(n)
    for i in range(n):
        print(f"Moneda de {monedas[i]}: {resultado_greedy[i]}")

   



main()
