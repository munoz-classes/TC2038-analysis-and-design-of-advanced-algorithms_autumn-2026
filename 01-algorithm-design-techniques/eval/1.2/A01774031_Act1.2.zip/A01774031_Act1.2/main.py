# Actividad 1.2 - Cambio de monedas
# A01774031 - Sebastian Plata Mercado

import sys


def leer_datos():
    # Complejidad: O(N)
    numeros = sys.stdin.read().split()
    n = int(numeros[0])
    denominaciones = []
    for i in range(1, n + 1):
        denominaciones.append(int(numeros[i]))
    precio = int(numeros[n + 1])
    pago = int(numeros[n + 2])
    return denominaciones, precio, pago


def cambio_dinamico(denominaciones, cambio):
    # Complejidad: O(cambio * N)
    n = len(denominaciones)
    conteo = [0] * n
    if cambio <= 0:
        return conteo

    monedas = [0] + [cambio + 1] * cambio
    usada = [-1] * (cambio + 1)

    for cantidad in range(1, cambio + 1):
        for i in range(n):
            valor = denominaciones[i]
            if valor <= cantidad and monedas[cantidad - valor] + 1 < monedas[cantidad]:
                monedas[cantidad] = monedas[cantidad - valor] + 1
                usada[cantidad] = i

    if monedas[cambio] > cambio:
        return conteo

    actual = cambio
    while actual > 0:
        i = usada[actual]
        conteo[i] += 1
        actual -= denominaciones[i]

    return conteo


def cambio_avaro(denominaciones, cambio):
    # Complejidad: O(N)
    n = len(denominaciones)
    conteo = [0] * n
    restante = cambio

    for i in range(n):
        if restante <= 0:
            break
        conteo[i] = restante // denominaciones[i]
        restante -= conteo[i] * denominaciones[i]

    return conteo


def main():
    denominaciones, precio, pago = leer_datos()
    denominaciones.sort(reverse=True)
    cambio = pago - precio

    resultado_dp = cambio_dinamico(denominaciones, cambio)
    resultado_avaro = cambio_avaro(denominaciones, cambio)

    for c in resultado_dp:
        print(c)
    for c in resultado_avaro:
        print(c)


main()
