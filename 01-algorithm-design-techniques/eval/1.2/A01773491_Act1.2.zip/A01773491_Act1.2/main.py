#!/usr/bin/env python3
# Actividad 1.2 - Cambio de monedas
# A01773491 - Alan Joseph Salazar Segura

import sys


def leer_entrada():
    # Complejidad: O(N log N) por el ordenamiento
    datos = sys.stdin.read().split()
    if not datos:
        return None

    try:
        valores = [int(d) for d in datos]
    except ValueError:
        return None

    n = valores[0]
    if n < 0 or len(valores) < n + 3:
        return None

    # Se descartan monedas de valor <= 0 para que el avaro siempre termine
    denominaciones = sorted([v for v in valores[1:n + 1] if v > 0],
                            reverse=True)
    precio = valores[n + 1]
    pago = valores[n + 2]

    return denominaciones, precio, pago


def cambio_dp(denominaciones, cantidad):
    """Programacion dinamica. Complejidad: O(cantidad * N)."""
    resultado = [0] * len(denominaciones)
    if cantidad <= 0 or not denominaciones:
        return resultado

    infinito = float("inf")
    min_monedas = [infinito] * (cantidad + 1)
    ultima = [-1] * (cantidad + 1)
    min_monedas[0] = 0

    for actual in range(1, cantidad + 1):
        for i, valor in enumerate(denominaciones):
            if valor <= actual and min_monedas[actual - valor] + 1 < min_monedas[actual]:
                min_monedas[actual] = min_monedas[actual - valor] + 1
                ultima[actual] = i

    if min_monedas[cantidad] == infinito:
        return resultado

    restante = cantidad
    while restante > 0:
        i = ultima[restante]
        resultado[i] += 1
        restante -= denominaciones[i]

    return resultado


def cambio_avaro(denominaciones, cantidad):
    """Algoritmo avaro. Complejidad: O(N) ya ordenadas las denominaciones."""
    resultado = [0] * len(denominaciones)
    restante = max(cantidad, 0)

    for i, valor in enumerate(denominaciones):
        if restante <= 0:
            break
        resultado[i] = restante // valor
        restante -= resultado[i] * valor

    return resultado


def imprimir(monedas):
    # Complejidad: O(N)
    for m in monedas:
        print(m)


def main():
    entrada = leer_entrada()
    if entrada is None:
        return 1

    denominaciones, precio, pago = entrada
    cantidad = max(pago - precio, 0)

    imprimir(cambio_dp(denominaciones, cantidad))
    imprimir(cambio_avaro(denominaciones, cantidad))

    return 0


if __name__ == "__main__":
    sys.exit(main())
