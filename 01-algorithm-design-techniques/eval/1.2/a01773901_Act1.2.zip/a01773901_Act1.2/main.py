#!/usr/bin/env python3
import sys


def leer_entrada():
    datos= sys.stdin.read().split()
    i=0
    n= int(datos[i]); i += 1
    monedas= [int(datos[i + j]) for j in range(n)]
    i += n
    p= int(datos[i]); i += 1
    q= int(datos[i]); i += 1
    return monedas, p, q


def cambio_dp(monedas, cambio):
    dp =[0] + [float('inf')] * cambio
    usada= [-1] * (cambio + 1)

    for m in range(1, cambio + 1):
        for idx, moneda in enumerate(monedas):
            if moneda <= m and dp[m - moneda] + 1 < dp[m]:
                dp[m]= dp[m - moneda] + 1
                usada[m]= idx

    resultado = [0] * len(monedas)
    restante =cambio
    while restante > 0 and usada[restante] != -1:
        idx =usada[restante]
        resultado[idx] += 1
        restante -= monedas[idx]

    return resultado


def cambio_avaro(monedas, cambio):
    resultado =[0] * len(monedas)
    restante =cambio
    for idx, moneda in enumerate(monedas):
        resultado[idx] = restante // moneda
        restante %= moneda
    return resultado


def main():
    monedas, p, q =leer_entrada()
    monedas.sort(reverse=True)
    cambio =q - p

    for cantidad in cambio_dp(monedas, cambio):
        print(cantidad)
    for cantidad in cambio_avaro(monedas, cambio):
        print(cantidad)


if __name__ == '__main__':
    main()
