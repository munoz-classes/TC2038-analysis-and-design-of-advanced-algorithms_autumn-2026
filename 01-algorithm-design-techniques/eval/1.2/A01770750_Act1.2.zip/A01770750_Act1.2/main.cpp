/*
 *N = numero de denominaciones disponibles
 *d_1 = N lineas, cada una con el valor de una denominacion
 *d_2
 *d_N
 *P = precio del producto
 *Q = monto con el que se paga el producto
 */

#include <iostream>
#include <vector>
#include <algorithm>
#include <limits>
using namespace std;

// Valor para cuando no hay solucion
static const long long SIN_SOLUCION = -1;

// Denominaciones oficiales validas: billetes y monedas de curso legal en Mexico.
static const vector<long long> DENOMINACIONES_VALIDAS = {500, 200, 100, 50, 20, 10, 5, 2, 1};

/*
 * Verifica que 'valor' sea una de las denominaciones oficiales permitidas.
 * Complejidad computacional:
 *   Tiempo:  O(1) (la lista de denominaciones validas tiene tamano fijo, 9)
 *   Espacio: O(1)
 */
bool esDenominacionValida(long long valor) {
    for (long long v : DENOMINACIONES_VALIDAS) {
        if (v == valor) return true;
    }
    return false;
}

//Empareja el valor de una moneda con su posicion original en la entrada.
struct Denominacion {
    long long valor;
    int indiceOriginal;
};

/*
 * Genera una copia de las denominaciones ordenada de mayor a menor, manteniendo el indice original de cada una.
 * Complejidad computacional:
 *   Tiempo:O(N log N)
 *   Espacio:O(N)
 */
vector<Denominacion> ordenarDeMayorAMenor(const vector<long long>& denominaciones) {
    int n = static_cast<int>(denominaciones.size());
    vector<Denominacion> ordenadas(n);
    for (int i = 0; i < n; ++i) {
        ordenadas[i].valor = denominaciones[i];
        ordenadas[i].indiceOriginal = i;
    }
    sort(ordenadas.begin(), ordenadas.end(),
              [](const Denominacion& a, const Denominacion& b) {
                  return a.valor > b.valor;
              });
    return ordenadas;
}
/*
 * Para cada denominacion, cuantas monedas se necesitan para formar EXACTAMENTE 'cambio', minimizando el numero total de monedas utilizadas 
 */
vector<long long> resolverConProgramacionDinamica(
        const vector<long long>& denominaciones, long long cambio) {

    int n = static_cast<int>(denominaciones.size());
    const long long INFINITO = numeric_limits<long long>::max() / 2;

    vector<long long> dp(static_cast<size_t>(cambio) + 1, INFINITO);
    vector<int> monedaUsada(static_cast<size_t>(cambio) + 1, -1);
    dp[0] = 0;

    for (long long monto = 1; monto <= cambio; ++monto) {
        for (int i = 0; i < n; ++i) {
            long long valor = denominaciones[static_cast<size_t>(i)];
            if (valor > 0 && valor <= monto &&
                dp[static_cast<size_t>(monto - valor)] + 1 < dp[static_cast<size_t>(monto)]) {
                dp[static_cast<size_t>(monto)] = dp[static_cast<size_t>(monto - valor)] + 1;
                monedaUsada[static_cast<size_t>(monto)] = i;
            }
        }
    }

    if (dp[static_cast<size_t>(cambio)] >= INFINITO) {
        return vector<long long>(n, SIN_SOLUCION);
    }

    vector<long long> conteo(n, 0);
    long long restante = cambio;
    while (restante > 0) {
        int i = monedaUsada[static_cast<size_t>(restante)];
        conteo[static_cast<size_t>(i)]++;
        restante -= denominaciones[static_cast<size_t>(i)];
    }
    return conteo;
}
/*
 * Recorre las denominaciones de mayor a menor y en cada paso toma la mayor cantidad posible de la denominacion actual sin superar el monto restante
 * Complejidad computacional:
 *   Tiempo:  O(N)
 *   Espacio: O(N)
 */
vector<long long> resolverConAlgoritmoAvaro(
        const vector<Denominacion>& ordenadas, long long cambio, long long& remanente) {
    int n = static_cast<int>(ordenadas.size());
    vector<long long> conteo(n, 0);
    long long restante = cambio;

    for (int i = 0; i < n; ++i) {
        long long valor = ordenadas[static_cast<size_t>(i)].valor;
        if (valor <= 0) continue;
        long long cantidad = restante / valor;
        conteo[static_cast<size_t>(i)] = cantidad;
        restante -= cantidad * valor;
    }
    remanente = restante;
    return conteo;
}
//Imprime N lineas indicando, para cada denominacion, cuantas monedas se dieron (o SIN_SOLUCION si no aplica).
void imprimirBloqueSinSolucion(const vector<Denominacion>& ordenadas) {
    for (size_t i = 0; i < ordenadas.size(); ++i) {
        cout << "Monedas de " << ordenadas[i].valor << " dadas: " << SIN_SOLUCION << "\n";
    }
}
int main() {
    cerr << "Calculadora de cambio (Programacion Dinamica vs Algoritmo Avaro)\n";
    cerr << "Denominaciones validas: 500,200,100,50,20,10,5,2,1\n\n";

    cerr << "Ingresa el numero de denominaciones disponibles (N): ";
    int n;
    if (!(cin >> n) || n < 0) {
        cerr << "N debe ser un entero no negativo.\n";
        return 1;
    }

    vector<long long> denominaciones(static_cast<size_t>(n));
    for (int i = 0; i < n; ++i) {
        cerr << "Ingresa la denominacion " << (i + 1) << " de " << n << ": ";
        cin >> denominaciones[static_cast<size_t>(i)];
    }

    //Validar que todas las denominaciones sean oficiales (500,200,100,50,20,10,5,2,1).
    for (int i = 0; i < n; ++i) {
        if (!esDenominacionValida(denominaciones[static_cast<size_t>(i)])) {
            cout << "Error: " << denominaciones[static_cast<size_t>(i)]
                 << " no es una denominacion valida Las denominaciones permitidas son: 500,200,100,50,20,10,5,2,1.\n";
            return 1;
        }
    }

    cerr << "Da el precio del producto (P): ";
    long long p = 0, q = 0;
    cin >> p;
    cerr << "Da el monto con el que se paga (Q): ";
    cin >> q;
    cerr << "\nResultado\n";

    long long cambio = q - p;
    vector<Denominacion> ordenadas = ordenarDeMayorAMenor(denominaciones);

    //si el cambio no alcanza
    if (cambio < 0) {
        cout << "Programacion Dinamica:\n";
        imprimirBloqueSinSolucion(ordenadas);
        cout << "Algoritmo Avaro:\n";
        imprimirBloqueSinSolucion(ordenadas);
        return 0;
    }
    vector<long long> conteoDP = resolverConProgramacionDinamica(denominaciones, cambio);
    cout << "Programacion Dinamica:\n";
    for (int i = 0; i < n; ++i) {
        int idxOriginal = ordenadas[static_cast<size_t>(i)].indiceOriginal;
        cout << "Monedas de " << ordenadas[static_cast<size_t>(i)].valor << " dadas: " << conteoDP[static_cast<size_t>(idxOriginal)] << "\n";
    }
    long long remanente = 0;
    vector<long long> conteoAvaro = resolverConAlgoritmoAvaro(ordenadas, cambio, remanente);
    cout << "Algoritmo Avaro:\n";
    for (int i = 0; i < n; ++i) {
        if (remanente > 0) {
            cout << "Monedas de " << ordenadas[static_cast<size_t>(i)].valor << " dadas: " << SIN_SOLUCION << "\n";
        } else {
            cout << "Monedas de " << ordenadas[static_cast<size_t>(i)].valor << " dadas: " << conteoAvaro[static_cast<size_t>(i)] << "\n";
        }
    }

    return 0;
}