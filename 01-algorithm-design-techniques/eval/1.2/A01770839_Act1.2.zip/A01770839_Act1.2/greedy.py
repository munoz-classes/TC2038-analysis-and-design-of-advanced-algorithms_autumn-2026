def change (money: int, coins: list[int]):
    coins=sorted(coins, reverse=True)
    result=[]
    for coin in coins:
        while money >= coin:
            money -= coin
            result.append(coin)
    if money == 0:
        return result
    else:
        return None
print(change(10, [1, 5, 10]))