/*
 * Descripción: Programa que ordena N números de mayor a menor con MergeSort.
 * Autor: Alberto Guillen Rayas / Apoyo IA Gemini
 * Fecha: 20 de agosto de 2026
 */

#include <iostream>
using namespace std;

/*
 * Propósito: Junta dos partes ordenadas de un arreglo en orden descendente.
 * Parámetros:
 *   - arreglo: Arreglo de números reales.
 *   - inicio: Posición donde empieza la primera parte.
 *   - medio: Posición donde termina la primera parte.
 *   - fin: Posición donde termina la segunda parte.
 * Retorno: Ninguno.
 * Complejidad:
 *   - Tiempo: O(N) para la mezcla de subarreglos.
 *   - Espacio: O(N) por los subarreglos temporales creados.
 */
void mezclar(double arreglo[], int inicio, int medio, int fin) {
    int tamanoIzquierda = medio - inicio + 1;
    int tamanoDerecha = fin - medio;

    double* izquierda = new double[tamanoIzquierda];
    double* derecha = new double[tamanoDerecha];

    for (int i = 0; i < tamanoIzquierda; i = i + 1) {
        izquierda[i] = arreglo[inicio + i];
    }

    for (int j = 0; j < tamanoDerecha; j = j + 1) {
        derecha[j] = arreglo[medio + 1 + j];
    }

    int indiceIzquierda = 0;
    int indiceDerecha = 0;
    int indiceArreglo = inicio;

    while (indiceIzquierda < tamanoIzquierda && indiceDerecha < tamanoDerecha) {
        if (izquierda[indiceIzquierda] >= derecha[indiceDerecha]) {
            arreglo[indiceArreglo] = izquierda[indiceIzquierda];
            indiceIzquierda = indiceIzquierda + 1;
        } else {
            arreglo[indiceArreglo] = derecha[indiceDerecha];
            indiceDerecha = indiceDerecha + 1;
        }
        indiceArreglo = indiceArreglo + 1;
    }

    while (indiceIzquierda < tamanoIzquierda) {
        arreglo[indiceArreglo] = izquierda[indiceIzquierda];
        indiceIzquierda = indiceIzquierda + 1;
        indiceArreglo = indiceArreglo + 1;
    }

    while (indiceDerecha < tamanoDerecha) {
        arreglo[indiceArreglo] = derecha[indiceDerecha];
        indiceDerecha = indiceDerecha + 1;
        indiceArreglo = indiceArreglo + 1;
    }

    delete[] izquierda;
    delete[] derecha;
}

/*
 * Función: mergeSort
 * Propósito: Divide el arreglo a la mitad y lo ordena recursivamente.
 * Parámetros:
 *   - arreglo: Arreglo de números a ordenar.
 *   - inicio: Índice donde empieza el segmento.
 *   - fin: Índice donde termina el segmento.
 * Retorno: Ninguno.
 * Complejidad:
 *   - Tiempo: O(N log N) en el peor y mejor caso.
 *   - Espacio: O(N) debido a la memoria de la mezcla.
 */
void mergeSort(double arreglo[], int inicio, int fin) {
    if (inicio < fin) {
        int medio = (inicio + fin) / 2;

        mergeSort(arreglo, inicio, medio);
        mergeSort(arreglo, medio + 1, fin);
        mezclar(arreglo, inicio, medio, fin);
    }
}

/*
 * Función: main
 * Propósito: Pide la cantidad de números, los lee y muestra el resultado final.
 * Parámetros: Ninguno.
 * Retorno: 0 si todo sale bien.
 * Complejidad Computacional:
 *   - Tiempo: O(N log N)
 *   - Espacio: O(N)
 */
int main() {
    int cantidadElementos = 0;

    if (cin >> cantidadElementos) {
        if (cantidadElementos > 0) {
            double* datos = new double[cantidadElementos];

            for (int i = 0; i < cantidadElementos; i = i + 1) {
                cin >> datos[i];
            }

            mergeSort(datos, 0, cantidadElementos - 1);

            for (int i = 0; i < cantidadElementos; i = i + 1) {
                cout << datos[i] << "\n";
            }

            delete[] datos;
        }
    }

    return 0;
}

/*  casos de prueba
*Caso 1: Números con decimales, ceros y valores negativos
 *   Entrada:
 *     5
 *     3.14
 *     -10.5
 *     0.0
 *     100.2
 *     -10.51
 *
 * Caso 2: Caso límite con un solo elemento (N = 1)
 *   Entrada:
 *     1
 *     42.5
 *
 * Caso 3: Arreglo con elementos duplicados y repetidos
 *   Entrada:
 *     6
 *     5.5
 *     5.5
 *     2.1
 *     5.5
 *     -1.0
 *     2.1
 * Caso 4: Arreglo en orden ascendente (caso de inversión total)
 *   Entrada:
 *     4
 *     1.1
 *     2.2
 *     3.3
 *     4.4
 */