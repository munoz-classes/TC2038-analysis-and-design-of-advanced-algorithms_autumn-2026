/*
Actividad 1.1 Implementacion de la tecnica de programacion "divide y venceras"
Utilizando MergeSort: ordena una lista de N numeros reales de mayor a menor.
Este programa lee un entero N (la cantidad de valores) seguido de N valores tipo double
desde la entrada estandar, los ordena con el algoritmo MergeSort (tecnica de Divide y Venceras)
e imprime el resultado, colocando un valor por cada línea.

Autor: Iker Octavio Silva Campos - A01770545
Fecha de creacion: 21 de agosto del 2026

Complejidad computacional: O(n log n) en todos los casos.
El "log n" surge por la division recursiva de la lista a la mitad.
La primera "n" es por la mezcla o merge que recorre los elementos en cada nivel.
*/
#include <iostream>
#include <vector>

/*
Mezcla dos listas ya ordenadas de mayor a menor en una sola lista ordenada. 
Parametros:
    izquierda: primera mitad, ordenada de mayor a menor.
    derecha: segunda mitad, ordenada de mayor a menor.
Retorno:
    Una lista con todos los elementos de ambas mitades, ordenada de mayor a menor.
Complejidad:
    O(n), en donde "n" es el total de elementos de ambas mitades.
*/

std::vector<double> merge(std::vector<double> izquierda, std::vector<double> derecha) {
    std::vector<double> resultado;
    int i = 0;
    int j = 0;
    while (i < izquierda.size() && j < derecha.size()) {
        if (izquierda[i] > derecha[j]) {
            resultado.push_back(izquierda[i]);
            i++;
        }
        else {
            resultado.push_back(derecha[j]);
            j++;
        }
    }
    while (i < izquierda.size()) {
        resultado.push_back(izquierda[i]);
        i++;
    }
    while (j < derecha.size()) {
        resultado.push_back(derecha[j]);
        j++;
    }
    return resultado;
}

/*
Ordena una lista de numeros reales de mayor a menor usando MergeSort.
Divide la lista en dos mitades, ordena cada una de forma recursiva, y las combina usando
la funcion Merge.
Parametros:
    lista: una simple lista de numeros a ordenar.
Retorno:
    Una nueva losta con los mismos elementos ordenados de mayor a menor.
Complejidad:
    O(n log n)
*/

std::vector<double> mergeSort(std::vector<double> lista) {
    if (lista.size() <= 1) {
        return lista;
    }
    int medio = lista.size() / 2;
    std::vector<double> izquierda(lista.begin(), lista.begin() + medio);
    std::vector<double> derecha(lista.begin() + medio, lista.end());
    izquierda = mergeSort(izquierda);
    derecha = mergeSort(derecha);
    return merge (izquierda, derecha);
}

/*
La funcion principal:
Lee los datos de entrada, los ordena y posteriormente muestra el resultado.
Lee N y luego N números tipo double, los ordena de mayor a menor usando el MergeSort e imprime
cada valor en una linea.
Retorno:
    0 (Cero), si es que el programa termina correctamente.
*/

int main() {
    int n;
    std::cin >> n;
    std::vector<double> numeros;
    for (int i = 0; i < n; i++) {
        double num;
        std::cin >> num;
        numeros.push_back(num);
    }
    numeros = mergeSort(numeros);
    for (int i = 0; i < numeros.size(); i++) {
        std::cout << numeros[i] << std::endl;
    }
    return 0;
}
/*
CASOS DE PRUEBA:
Cada diagonal representa un cambio de linea

Caso 1 (normal, valores desordenados):
    ENtrada: 5 / 3.5 / 10.2 / 1.1 / 7.8 / 2.4
    Salida: 10.2 / 7.8 / 3.5 / 2.4 / 1.1
Caso 2 (un solo elemento):
    Entrada: 1 / 5.5
    Salida: 5.5
Caso 3 (lista vacia, cero elementos):
    Entrada: 0
    Salida: (no imprime nada)
Caso 4 (valores negativos y repetidos):
    Entrada: 5 / -2.0 / 4.5 / -2.0 / 0.0 / 4.5
    Salida: 4.5 / 4.5 / 0.0 / -2.0 / -2.0
*/