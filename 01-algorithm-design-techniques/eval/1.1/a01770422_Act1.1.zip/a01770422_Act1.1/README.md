# Actividad 1.1 - MergeSort (divide y venceras)

Matricula: a01770422

## Archivos
- `main.cpp` : implementacion del algoritmo MergeSort.
- `casos_prueba/inN.txt` : entradas de prueba.
- `casos_prueba/outN.txt` : salidas esperadas correspondientes.

## Compilacion y ejecucion (Linux)
```
g++ -std=c++17 -Wall -Wextra -Wpedantic -o a.out main.cpp
./a.out < casos_prueba/in1.txt
```

## Formato
- Entrada: un entero N y despues N valores reales (uno por linea).
- Salida : los N valores ordenados de MAYOR a MENOR, uno por linea.

## Complejidad computacional
| Funcion        | Tiempo       | Espacio            |
|----------------|--------------|--------------------|
| `merge`        | O(n)         | O(1) adicional     |
| `mergeSortAux` | O(n log n)   | O(log n) recursion |
| `mergeSort`    | O(n log n)   | O(n) auxiliar      |
| `readInput`    | O(n)         | O(n)               |
| `writeOutput`  | O(n)         | O(1) adicional     |
| `main`         | O(n log n)   | O(n)               |

`mergeSortAux` cumple la recurrencia T(n) = 2 T(n/2) + O(n), que por el
Teorema Maestro da O(n log n) en el mejor, promedio y peor caso.

## Casos de prueba
1. Valores mezclados: positivos, negativos, cero y decimales.
2. Duplicados y entrada ya ordenada de mayor a menor (estabilidad).
3. Entrada en orden ascendente (caso invertido) con magnitudes grandes.
4. Caso extremo: N = 1 (un solo valor negativo).
5. Caso extremo adicional: N = 0 (salida vacia).

Tambien se probo con N = 200,000 valores aleatorios (0.36 s) y con
entradas incompletas o vacias, sin fallas.
