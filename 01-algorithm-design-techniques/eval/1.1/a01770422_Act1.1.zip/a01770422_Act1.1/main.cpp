// ===========================================================================
// main.cpp
//
// Actividad 1.1 - Algoritmo de ordenamiento MergeSort
// Tecnica de programacion: "divide y venceras" (divide and conquer)
//
// Autor    : a01770422
// Fecha    : 22 de agosto de 2026
//
// Descripcion:
//   El programa lee de la entrada estandar un numero entero N, seguido de
//   N valores reales (double, uno en cada linea). La salida es la lista de
//   los N valores ordenados de MAYOR a MENOR, uno por linea.
//
// Compilacion (Linux):
//   g++ -std=c++17 -Wall -Wextra -Wpedantic -o a.out main.cpp
//
// Ejecucion con entrada redireccionada:
//   ./a.out < in.txt
//
// Complejidad global del programa:
//   Tiempo : O(N log N)   -- dominada por mergeSort
//   Espacio: O(N)         -- arreglo de datos + arreglo auxiliar
// ===========================================================================

#include <cstddef>
#include <iomanip>
#include <iostream>
#include <vector>

// Numero de digitos significativos usados al imprimir los valores reales.
// Se usa notacion "defaultfloat", por lo que los ceros a la derecha no se
// imprimen (por ejemplo 3.50 se imprime como 3.5).
const int OUTPUT_PRECISION = 15;

// ---------------------------------------------------------------------------
// merge
//
// Descripcion:
//   Combina (mezcla) dos sub-arreglos adyacentes que ya se encuentran
//   ordenados de mayor a menor:
//       values[left .. middle]  y  values[middle + 1 .. right]
//   El resultado es un unico segmento values[left .. right] ordenado de
//   mayor a menor. Se apoya en el arreglo auxiliar "buffer" para no
//   reservar memoria nueva en cada llamada.
//
// Parametros:
//   values : referencia al vector de datos que se esta ordenando.
//   buffer : vector auxiliar del mismo tamano que "values".
//   left   : indice inicial del primer sub-arreglo.
//   middle : indice final del primer sub-arreglo.
//   right  : indice final del segundo sub-arreglo.
//
// Regresa:
//   void (el vector "values" queda modificado en el rango [left, right]).
//
// Complejidad:
//   Tiempo : O(n), donde n = right - left + 1. Cada elemento del rango se
//            copia exactamente dos veces (una al buffer y otra de regreso).
//   Espacio: O(1) adicional, ya que el buffer se recibe como parametro.
// ---------------------------------------------------------------------------
void merge(std::vector<double> &values, std::vector<double> &buffer,
           std::size_t left, std::size_t middle, std::size_t right) {
    std::size_t i = left;        // recorre el sub-arreglo izquierdo
    std::size_t j = middle + 1;  // recorre el sub-arreglo derecho
    std::size_t k = left;        // posicion de escritura en el buffer

    // Se toma siempre el mayor de los dos frentes (orden descendente).
    // El uso de ">=" conserva la estabilidad del algoritmo.
    while (i <= middle && j <= right) {
        if (values[i] >= values[j]) {
            buffer[k] = values[i];
            i++;
        } else {
            buffer[k] = values[j];
            j++;
        }
        k++;
    }

    // Copia los elementos restantes del sub-arreglo izquierdo (si los hay).
    while (i <= middle) {
        buffer[k] = values[i];
        i++;
        k++;
    }

    // Copia los elementos restantes del sub-arreglo derecho (si los hay).
    while (j <= right) {
        buffer[k] = values[j];
        j++;
        k++;
    }

    // Regresa el segmento ya mezclado al vector original.
    for (std::size_t pos = left; pos <= right; pos++) {
        values[pos] = buffer[pos];
    }
}

// ---------------------------------------------------------------------------
// mergeSortAux
//
// Descripcion:
//   Funcion recursiva que aplica "divide y venceras" sobre el segmento
//   values[left .. right]:
//     1. DIVIDE  : parte el segmento en dos mitades por el punto medio.
//     2. VENCE   : ordena recursivamente cada mitad.
//     3. COMBINA : mezcla las dos mitades ordenadas con merge().
//   El caso base es un segmento de cero o un elemento, que ya esta ordenado.
//
// Parametros:
//   values : referencia al vector de datos que se esta ordenando.
//   buffer : vector auxiliar del mismo tamano que "values".
//   left   : indice inicial del segmento.
//   right  : indice final del segmento.
//
// Regresa:
//   void (el vector "values" queda ordenado en el rango [left, right]).
//
// Complejidad:
//   Tiempo : O(n log n) en el mejor, promedio y peor caso.
//            Relacion de recurrencia: T(n) = 2 T(n/2) + O(n),
//            que por el Teorema Maestro resulta en O(n log n).
//   Espacio: O(log n) por la pila de llamadas recursivas (el buffer de
//            tamano O(n) se reserva una sola vez fuera de esta funcion).
// ---------------------------------------------------------------------------
void mergeSortAux(std::vector<double> &values, std::vector<double> &buffer,
                  std::size_t left, std::size_t right) {
    // Caso base: 0 o 1 elemento. Se usa ">=" y no "==" por seguridad.
    if (left >= right) {
        return;
    }

    // DIVIDE: se calcula asi (y no como (left + right) / 2) para evitar
    // un posible desbordamiento aritmetico con indices muy grandes.
    std::size_t middle = left + (right - left) / 2;

    // VENCE
    mergeSortAux(values, buffer, left, middle);
    mergeSortAux(values, buffer, middle + 1, right);

    // COMBINA
    merge(values, buffer, left, middle, right);
}

// ---------------------------------------------------------------------------
// mergeSort
//
// Descripcion:
//   Interfaz publica del algoritmo. Reserva una sola vez el arreglo auxiliar
//   e inicia el proceso recursivo para ordenar todo el vector de mayor a
//   menor. Si el vector tiene menos de dos elementos no hay nada que hacer.
//
// Parametros:
//   values : referencia al vector de valores reales por ordenar.
//
// Regresa:
//   void (el vector "values" queda ordenado de mayor a menor).
//
// Complejidad:
//   Tiempo : O(n log n) en el mejor, promedio y peor caso.
//   Espacio: O(n) por el arreglo auxiliar, mas O(log n) de la recursion.
// ---------------------------------------------------------------------------
void mergeSort(std::vector<double> &values) {
    if (values.size() < 2) {
        return;
    }

    std::vector<double> buffer(values.size());
    mergeSortAux(values, buffer, 0, values.size() - 1);
}

// ---------------------------------------------------------------------------
// readInput
//
// Descripcion:
//   Lee de la entrada estandar el entero N y despues hasta N valores reales,
//   guardandolos en el vector recibido. Es tolerante a entradas incompletas:
//   si el archivo termina antes de leer los N valores, solo se conservan los
//   que si pudieron leerse. Un valor de N negativo o una entrada vacia
//   producen un vector vacio.
//
// Parametros:
//   values : referencia al vector donde se almacenaran los valores leidos.
//
// Regresa:
//   void (el vector "values" queda lleno con los datos de la entrada).
//
// Complejidad:
//   Tiempo : O(n), una lectura por cada valor de la entrada.
//   Espacio: O(n) por el almacenamiento de los valores.
// ---------------------------------------------------------------------------
void readInput(std::vector<double> &values) {
    long long n = 0;

    // Entrada vacia o mal formada: no hay nada que ordenar.
    if (!(std::cin >> n) || n <= 0) {
        return;
    }

    values.reserve(static_cast<std::size_t>(n));

    double value = 0.0;
    for (long long i = 0; i < n && (std::cin >> value); i++) {
        values.push_back(value);
    }
}

// ---------------------------------------------------------------------------
// writeOutput
//
// Descripcion:
//   Imprime en la salida estandar los valores del vector, uno por linea,
//   en el orden en que se encuentran.
//
// Parametros:
//   values : referencia constante al vector de valores por imprimir.
//
// Regresa:
//   void.
//
// Complejidad:
//   Tiempo : O(n), una impresion por elemento.
//   Espacio: O(1) adicional.
// ---------------------------------------------------------------------------
void writeOutput(const std::vector<double> &values) {
    std::cout << std::defaultfloat << std::setprecision(OUTPUT_PRECISION);

    for (std::size_t i = 0; i < values.size(); i++) {
        std::cout << values[i] << "\n";
    }
}

// ---------------------------------------------------------------------------
// main
//
// Descripcion:
//   Punto de entrada del programa: lee los datos, los ordena de mayor a
//   menor con MergeSort e imprime el resultado.
//
// Regresa:
//   0 si la ejecucion fue exitosa.
//
// Complejidad:
//   Tiempo : O(n log n)  -- lectura O(n) + ordenamiento O(n log n) +
//                           escritura O(n).
//   Espacio: O(n).
// ---------------------------------------------------------------------------
int main() {
    // Acelera la lectura/escritura al desligar los flujos de C y C++.
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(nullptr);

    std::vector<double> values;

    readInput(values);
    mergeSort(values);
    writeOutput(values);

    return 0;
}
