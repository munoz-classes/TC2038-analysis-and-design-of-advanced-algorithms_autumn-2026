/*
 * Programa: Implementacion de MergeSort utilizando la tecnica Divide y Venceras.
 * Nombre: Tabata Carolina Salinas Valdez
 * Matricula: A01770901
 * Fecha de creacion: 21/08/2026
 */

/*
 * Proposito:
 * Combina dos partes ordenadas de un arreglo para formar una sola
 * parte ordenada de mayor a menor.
 * Parametros:
 * arreglo: Arreglo que contiene los valores que se combinan.
 * inicio: Posicion inicial de la primera parte.
 * medio: Posicion final de la primera parte.
 * fin: Posicion final de la segunda parte.
 * Retorno:
 * Ningun valor.
 * Complejidad:
 * O(n), elementos que se combinan.
 */
#include <iostream>
using namespace std;

void merge(double arreglo[], int inicio, int medio, int fin)
{
	int i = inicio;
	int j = medio + 1;
	int k = 0;
	int tamano = fin - inicio + 1;
	double* temporal = new double[tamano];
	while (i <= medio && j <= fin)
	{
		if (arreglo[i] >= arreglo[j])
		{
			temporal[k] = arreglo[i];
			i++;
		}
		else
		{
			temporal[k] = arreglo[j];
			j++;
		}
		k++;
	}
	while (i <= medio)
	{
		temporal[k] = arreglo[i];
		i++;
		k++;
	}
	while (j <= fin)
	{
		temporal[k] = arreglo[j];
		j++;
		k++;
	}
	for (i = 0; i < tamano; i++)
	{
		arreglo[inicio + i] = temporal[i];
	}
	delete[] temporal;
}

/*
 * Proposito:
 * Ordena los elementos de un arreglo utilizando el algoritmo
 * MergeSort usa la tecnica Divide y Venceras.
 * Parametros:
 * arreglo: Arreglo que contiene los valores a ordenar.
 * inicio: Posicion inicial del segmento que se ordenara.
 * fin: Posicion final del segmento que se ordenara.
 * Regr:No da valor.
 * Complejidad:
 * O(nlogn), n = num de elementos.
 */
void mergeSort(double arreglo[], int inicio, int fin)
{
	if (inicio < fin)
	{
		int medio = (inicio + fin) / 2;
		mergeSort(arreglo, inicio, medio);
		mergeSort(arreglo, medio + 1, fin);
		merge(arreglo, inicio, medio, fin);
	}
}

/*
 * Proposito: Lee los datos de entrada, ordena los valores de mayor a menor
 * utilizando MergeSort y muestra el resultado.
 * Parametros: No recibe parametros.
 * Regreso:
 * Da 0 cuando el programa termina correctamente.
 *
 * Complejidad:
 * O(nlogn), n es la cantidad de valores recibidos.
 */
int main()
{
	int n = 0;
	cin >> n;
	double* arreglo = new double[n];
	for (int i = 0; i < n; i++)
	{
		cin >> arreglo[i];
	}
	mergeSort(arreglo, 0, n - 1);
	for (int i = 0; i < n; i++)
	{
		cout << arreglo[i] << endl;
	}
	delete[] arreglo;
	return 0;
}