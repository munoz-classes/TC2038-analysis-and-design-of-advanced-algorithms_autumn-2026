#include <iostream>
#include <vector>

using namespace std;
// Combina dos sublistas ordenadas de mayor a menor a una
void merge(vector<double>& arr, int izq, int medio, int der) {
    int n1=medio-izq + 1;
    int n2=der-medio;
    vector<double>izquierda(n1);
    vector<double>derecha(n2);
    for (int i=0;i<n1;i++)
        izquierda[i] = arr[izq + i];
    for (int j=0;j<n2;j++)
        derecha[j]=arr[medio+1+j];
    int i=0,j=0,k=izq;
    // Se combina comparando y colocando primero el valor mayor
    while (i<n1 && j<n2) {
        if (izquierda[i]>=derecha[j]) {
            arr[k]=izquierda[i];
            i++;
        } else {
            arr[k]=derecha[j];
            j++;
        }
        k++;
    }
    while (i<n1) {
        arr[k]=izquierda[i];
        i++;
        k++;
    }
    while (j<n2) {
        arr[k]=derecha[j];
        j++;
        k++;
    }
}
//MergeSort
void mergeSort(vector<double>& arr, int izq, int der) {
    if (izq>=der) {
        return;
    }
    int medio=izq+(der-izq)/2;
    // Divide
    mergeSort(arr, izq, medio);
    mergeSort(arr, medio + 1, der);
    // Vence
    merge(arr, izq, medio, der);
}
int main() {
    int n;
    // Se lee N: la cantidad de valores double que vienen a continuación por stdin
    cout << "cantidad de valores para ordenar: ";
    if (!(cin>>n)) {
        return 0;
    }
    vector<double> valores(n);
    cout << "poner los " << n << " valores solo uno por linea:\n";
    for (int i=0;i<n;i++) {
        cin>>valores[i];
    }
    if (n>0) {
        mergeSort(valores, 0, n - 1);
    }
    cout << "valores ordenados de mayor a menor:\n";
    for (int i = 0; i < n; i++) {
        cout << valores[i] << "\n";
    }
    return 0;
}