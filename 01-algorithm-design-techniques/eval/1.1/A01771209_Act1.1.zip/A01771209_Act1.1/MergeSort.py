"""
Merge Sort, algoritmo de ordenamiento mediante Divide y venceras
Complejidad: O(n log n)

Kiara Hermann San Lucas | A01771209
21/08/26
"""


def mergeSort(lista):

    # CB: cuando la list tiene 0 o 1 elem
    if len(lista) <= 1:
        return lista
    
    # dividir
    medio = len(lista) // 2
    izq = mergeSort(lista[:medio])
    der = mergeSort(lista[medio:])

    return merge(izq, der)

def merge(izq, der):
    resultado = []
    i = 0
    j = 0

    # comparar elem de sublistas y ocupar el menor
    while i < len(izq) and j < len(der):
        if izq[i] < der[j]:
            resultado.append(izq[i])
            i += 1
        else:
            resultado.append(der[j])
            j += 1

    # agregar elem restantes
    resultado.extend(izq[i:])
    resultado.extend(der[j:]) 

    return resultado


# Casos Prueba

lista1 = [] #Vacio
print(f"Caso 1; lista inicial = {lista1}; resultado -> {mergeSort(lista1)}")

lista2 = [50, 40, 30, 20, 10] #Orden descendente
print(f"Caso 2; lista inicial = {lista2}; resultado -> {mergeSort(lista2)}")

lista3 = [7, -2, 7, 0, -2, 7] #Elementos repetidos
print(f"Caso 3; lista inicial = {lista3}; resultado -> {mergeSort(lista3)}")

lista4 = [15, -3, 0, -80, 42] #Todo tipo de numero
print(f"Caso 4; lista inicial = {lista4}; resultado -> {mergeSort(lista4)}")
