#include <iostream>

static int* mergesortuni(int* nums1, int l1, int* nums2, int l2) {
    int l3 = l1 + l2;
    int* nums = new int[l3];
    int i = 0, j = 0, k = 0;
    while (i < l1 || j < l2) {
        nums[k++] = i < l1 && (j >= l2 || nums1[i] < nums2[j]) ? nums1[i++] : nums2[j++];
    }
    return nums;
}
static void mergesortsep(int*& nums, int l) {
    if (l > 1 && nums != nullptr) {
        int l2 = l / 2, l1 = l - l2;
        int* nums1 = new int[l1], * nums2 = new int[l2];
        bool impar = l % 2 != 0;
        for (int i = 0; i < l1; i++) {
            if (impar && i == l1 - 1) {
                nums1[i] = nums[i];
            }
            else {
                nums1[i] = nums[i];
                nums2[i] = nums[i + l1];
            }
        }
        delete[] nums;
        mergesortsep(nums1, l1);
        mergesortsep(nums2, l2);
        nums = mergesortuni(nums1, l1, nums2, l2);
        delete[] nums1;
        delete[] nums2;
    }
}

void mostrar(int*& nums, int l) {
    std::cout << "Los numeros originales son:\n";
    for (int i = 0; i < l; i++) {
        std::cout << nums[i] << " ";
    }
    std::cout << "\n";
    mergesortsep(nums, l);
    std::cout << "Los numeros ordenados son:\n";
    for (int i = 0; i < l; i++) {
        std::cout << nums[i] << " ";
    }
    std::cout << "\n";
}

int main()
{
    constexpr int LONGITUD1 = 6;
    int* nums1 = new int[LONGITUD1] {6, 5, 12, 10, 9, 1};
    mostrar(nums1, LONGITUD1);
    constexpr int LONGITUD2 = 7;
    int* nums2 = new int[LONGITUD2] {6, 7, 12, 2, 9, 8, 0};
    mostrar(nums2, LONGITUD2);
    constexpr int LONGITUD3 = 8;
    int* nums3 = new int[LONGITUD3] {3, 5, 2, 0, 11, 3, 5, 13};
    mostrar(nums3, LONGITUD3);
    constexpr int LONGITUD4 = 2;
    int* nums4 = new int[LONGITUD4] {9, 2};
    mostrar(nums4, LONGITUD4);
    delete[] nums1;
    delete[] nums2;
    delete[] nums3;
    delete[] nums4;
    return 0;
}

