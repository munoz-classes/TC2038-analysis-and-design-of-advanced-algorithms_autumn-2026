#include <iostream>

using namespace std;

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    cout << "¡Entorno ICPC configurado correctamente!" << endl;

    return 0;
}
