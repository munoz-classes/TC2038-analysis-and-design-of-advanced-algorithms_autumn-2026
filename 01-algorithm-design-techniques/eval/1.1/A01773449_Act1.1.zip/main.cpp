#include <iostream>

// Claudia Vanessa Hermosillo Diaz A01773449 (tomando como referencia el libro baase) y con muchos comentarios para explicar todo 


// definición de la función merge con el arreglo, el primer elemento, la mitad y el segundo elemento como parametros
void merge(int caso[], int primero, int mitad, int ultimo){

    // se calcula el tamaño del subarreglo de la izquierda
    int largoIzquierda = mitad - primero + 1;
    // se calcula el tamaño del subarreglo de la derecha
    int largoDerecha = ultimo - mitad;

    // se ocupan arreglos dinámicos para almacenar y actualizar los subarreglos
    int* Izquierda = new int[largoIzquierda];
    int* Derecha = new int[largoDerecha];

    // Se pasan los elementos a cada subarreglo
    for (int i = 0; i < largoIzquierda; i++){
        Izquierda[i] = caso[primero + i];
    }
    for (int j = 0; j < largoDerecha; j++) {
        Derecha[j] = caso[mitad + 1 + j];
    }

    // indices para subarreglos y del caso
    int izq = 0;
    int der = 0;
    int p = primero;

    // ciclo while para comparar cada numero de los subarreglos y ordenarlos
    while (izq < largoIzquierda && der < largoDerecha) {
        if (Izquierda[izq] <= Derecha[der]) {
            caso[p] = Izquierda[izq];
            izq++;
        } else {
            caso[p] = Derecha[der];
            der++;
        }
        p++;
    }

    // Copiar elementos que queden
    while (izq < largoIzquierda) {
        caso[p++] = Izquierda[izq++];
    }
    while (der < largoDerecha) {
        caso[p++] = Derecha[der++];
    }

    delete[] Izquierda;
    delete[] Derecha;
}

//definicion de la función mergeSort con el arreglo, el inicio y final del arreglo como parámetros
void mergeSort(int caso[], int primero, int ultimo){
    //se hace la comparativa donde el primer elemento es menor al último
    if(primero < ultimo){
        // se calcula la mitaad del arreglo
        int mitad = (primero + ultimo) / 2;
        // llama recursivamente a la funcion mergeSort con la primera mitad del arreglo
        mergeSort(caso, primero, mitad);
        // llama recursivamente a la funcion mergeSort con la segunda mitad del arreglo
        mergeSort(caso, mitad + 1, ultimo);
        // llama a la función merge para hacer el merge de las dos mitades
        merge(caso, primero, mitad, ultimo);
    }
}


int main(){

    // Casos a probar y sus largos 
    int primerCaso[] = {-3,5,0,-1,8,-5};
    int largoPrimerCaso = sizeof(primerCaso) / sizeof(primerCaso[0]);

    int segundoCaso[] = {8,6,1,12,7,4};
    int largoSegundoCaso = sizeof(segundoCaso) / sizeof(segundoCaso[0]);

    int tercerCaso[] = {50,40,90,10,35,60};
    int largoTercerCaso = sizeof(tercerCaso) / sizeof(tercerCaso[0]);

    int cuartoCaso[] = {10,12,8,5,2,20};
    int largoCuartoCaso = sizeof(cuartoCaso) / sizeof(cuartoCaso[0]);


    //llamada a la función mergeSort por cada caso, pasando el arreglo(o caso), su inicio y su final( es decir el largo del arreglo -1)
    mergeSort(primerCaso, 0, largoPrimerCaso - 1);
    mergeSort(segundoCaso, 0, largoSegundoCaso - 1);
    mergeSort(tercerCaso, 0, largoTercerCaso - 1);
    mergeSort(cuartoCaso, 0, largoCuartoCaso - 1);


    //mostrar el resultado de cada caso 
    std::cout<< "Primer caso: " ;
    for(int i = 0; i < largoPrimerCaso; i++){
        std::cout << primerCaso[i] << " ";
    }
    std::cout << std::endl;

    std::cout<< "Segundo caso: ";
    for(int i = 0; i < largoSegundoCaso; i++){
        std::cout << segundoCaso[i] << " ";
    }
    std::cout << std::endl;

    std::cout<< "Tercer caso: ";
    for(int i = 0; i < largoTercerCaso; i++){
        std::cout << tercerCaso[i] << " ";
    }
    std::cout << std::endl;

    std::cout<< "Cuarto caso: ";
    for(int i = 0; i < largoCuartoCaso; i++){
        std::cout << cuartoCaso[i] << " ";
    }
    std::cout << std::endl;

}