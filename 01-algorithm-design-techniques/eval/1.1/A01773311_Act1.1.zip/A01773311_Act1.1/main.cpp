#include <iostream>
#include <vector>
#include <iomanip>
using namespace std;

/*
 * Programa: Actividad 1.1 - MergeSort
 * Descripcion: Implementacion del algoritmo MergeSort utilizando la
 *              tecnica de divide y venceras para ordenar de mayor a
 *              menor una lista de valores reales.
 * Autor: Jose Angel Vargas Carranza - A01773311
 * Fecha: 21/08/2026
 */

/*
 * Funcion: merge
 * Descripcion: Combina (mezcla) dos subarreglos ya ordenados de forma
 *              descendente ([inicio..medio] y [medio+1..fin]) en un
 *              solo subarreglo ordenado descendente.
 * Parametros:
 *   datos  - referencia al vector completo que contiene ambos subarreglos.
 *   inicio - indice inicial del subarreglo izquierdo.
 *   medio  - indice final del subarreglo izquierdo.
 *   fin    - indice final del subarreglo derecho.
 * Retorno: no retorna valor (void); modifica datos in-place.
 * Complejidad temporal: O(n), donde n = fin - inicio + 1
 * Complejidad espacial: O(n), por los vectores temporales izquierda y derecha
 */
void merge(vector<double> &datos, int inicio, int medio, int fin) {
	int tamIzq = medio - inicio + 1;
	int tamDer = fin - medio;
	vector<double> izquierda(tamIzq);
	vector<double> derecha(tamDer);

	for (int i = 0; i < tamIzq; i++)
		izquierda[i] = datos[inicio + i];
	for (int j = 0; j < tamDer; j++)
		derecha[j] = datos[medio + 1 + j];

	int i = 0;
	int j = 0;
	int k = inicio;

	while (i < tamIzq && j < tamDer) {
		if (izquierda[i] >= derecha[j]) {
			datos[k] = izquierda[i];
			i++;
		} else {
			datos[k] = derecha[j];
			j++;
		}
		k++;
	}
	while (i < tamIzq) {
		datos[k] = izquierda[i];
		i++;
		k++;
	}
	while (j < tamDer) {
		datos[k] = derecha[j];
		j++;
		k++;
	}
}

/*
 * Funcion: mergeSort
 * Descripcion: Ordena de forma descendente el subarreglo datos[inicio..fin]
 *              utilizando la tecnica de divide y venceras: divide el
 *              arreglo en dos mitades, ordena cada mitad recursivamente
 *              y luego las combina con merge.
 * Parametros:
 *   datos  - referencia al vector que se desea ordenar.
 *   inicio - indice inicial del rango a ordenar.
 *   fin    - indice final del rango a ordenar.
 * Retorno: no retorna valor (void); ordena datos in-place.
 * Complejidad temporal: O(n log n), donde n = fin - inicio + 1
 * Complejidad espacial: O(n) para los vectores auxiliares de merge,
 *                        mas O(log n) de la pila de recursion.
 */
void mergeSort(vector<double> &datos, int inicio, int fin) {
	if (inicio >= fin)
		return;

	int medio = inicio + (fin - inicio) / 2;
	mergeSort(datos, inicio, medio);
	mergeSort(datos, medio + 1, fin);
	merge(datos, inicio, medio, fin);
}

/*
 * Funcion: main
 * Descripcion: Lee un entero N y N valores reales desde la entrada
 *              estandar, los ordena de mayor a menor utilizando
 *              mergeSort y los imprime, uno por linea.
 * Parametros: no recibe parametros.
 * Retorno: entero que indica el estado de finalizacion del programa (0 = exito).
 * Complejidad temporal: O(n log n), dominada por la llamada a mergeSort.
 * Complejidad espacial: O(n), para almacenar los n valores leidos.
 */
int main() {
	int n = 0;
	cin >> n;

	vector<double> numeros(n);
	for (int i = 0; i < n; i++)
		cin >> numeros[i];

	if (n > 0)
		mergeSort(numeros, 0, n - 1);

	cout << fixed << setprecision(2);
	for (int i = 0; i < n; i++)
		cout << numeros[i] << endl;

	return 0;
}
