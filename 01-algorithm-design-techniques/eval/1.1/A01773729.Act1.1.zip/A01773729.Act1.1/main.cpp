/*
 * Actividad 1.1 - MergeSort con Divide y Venceras
 * Este programa ordena numeros reales de mayor a menor
 * Autor: Leonardo Rulfo Soto, A01773729
 * Fecha: 21/08/2026
 */

#include <iostream>
#include <vector>
using namespace std;

// Esta funcion junta dos partes que ya estan ordenadas y las mezcla
// en una sola parte ordenada de mayor a menor
// Parametros: datos = el vector completo, inicio/medio/fin = los limites de las dos mitades
// No regresa nada, solo modifica el vector datos
// Complejidad: O(n)
void merge(vector<double> &datos, int inicio, int medio, int fin) {
    int tamIzquierda = medio - inicio + 1;
    int tamDerecha = fin - medio;

    vector<double> izquierda(tamIzquierda);
    vector<double> derecha(tamDerecha);

    for (int i = 0; i < tamIzquierda; i++) {
        izquierda[i] = datos[inicio + i];
    }

    for (int i = 0; i < tamDerecha; i++) {
        derecha[i] = datos[medio + 1 + i];
    }

    int i = 0;
    int j = 0;
    int posActual = inicio;

    // Comparo los dos lados y voy metiendo primero el mas grande
    while (i < tamIzquierda && j < tamDerecha) {
        if (izquierda[i] >= derecha[j]) {
            datos[posActual] = izquierda[i];
            i++;
        } else {
            datos[posActual] = derecha[j];
            j++;
        }
        posActual++;
    }

    // Si sobro algo de la izquierda lo voy agregando
    while (i < tamIzquierda) {
        datos[posActual] = izquierda[i];
        i++;
        posActual++;
    }

    // Si sobro algo de la derecha tambien lo agrego
    while (j < tamDerecha) {
        datos[posActual] = derecha[j];
        j++;
        posActual++;
    }
}

// Esta es la funcion principal del algoritmo, aqui aplico divide y venceras
// Divido el vector en dos mitades, ordeno cada mitad y luego las junto con merge
// Parametros: datos = el vector a ordenar, inicio/fin = el rango que voy a ordenar
// No regresa nada, deja el vector ordenado
// Complejidad: O(n log n)
void mergeSort(vector<double> &datos, int inicio, int fin) {
    // Caso base, si ya es un solo elemento no hay nada que hacer
    if (inicio >= fin) {
        return;
    }

    int medio = inicio + (fin - inicio) / 2;

    mergeSort(datos, inicio, medio);
    mergeSort(datos, medio + 1, fin);
    merge(datos, inicio, medio, fin);
}

// Aqui leo los datos, llamo a mergeSort y despues imprimo el resultado
int main() {
    int cantidadDatos = 0;
    cin >> cantidadDatos;

    vector<double> numeros(cantidadDatos);
    for (int i = 0; i < cantidadDatos; i++) {
        cin >> numeros[i];
    }

    if (cantidadDatos > 0) {
        mergeSort(numeros, 0, cantidadDatos - 1);
    }

    for (int i = 0; i < cantidadDatos; i++) {
        cout << numeros[i] << endl;
    }

    return 0;
}