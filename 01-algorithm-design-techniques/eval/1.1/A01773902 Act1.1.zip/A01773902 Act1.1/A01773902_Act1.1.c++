/*
 Descripcion: Ordena N valores double de mayor a menor usando MergeSort
 Alan Garcia
 */

#include <iostream>
#include <vector>

using namespace std;

void merge(vector<double>& v, int izquierda, int medio, int derecha) {
	vector<double> temporal;
	int i = izquierda;
	int j = medio + 1;

	while (i <= medio && j <= derecha) {
		if (v[i] >= v[j]) {
			temporal.push_back(v[i]);
			i++;
		} else {
			temporal.push_back(v[j]);
			j++;
		}
	}

	while (i <= medio) {
		temporal.push_back(v[i]);
		i++;
	}

	while (j <= derecha) {
		temporal.push_back(v[j]);
		j++;
	}

	for (int k = 0; k < (int) temporal.size(); k++) {
		v[izquierda + k] = temporal[k];
	}
}


void mergeSort(vector<double>& v, int izquierda, int derecha) {
	if (izquierda >= derecha) {
		return;
	}

	int medio = izquierda + (derecha - izquierda) / 2;
	mergeSort(v, izquierda, medio);
	mergeSort(v, medio + 1, derecha);
	merge(v, izquierda, medio, derecha);
}

int main() {
	int n;
	cin >> n;

	vector<double> valores(n);
	for (int i = 0; i < n; i++) {
		cin >> valores[i];
	}

	mergeSort(valores, 0, n - 1);

	for (int i = 0; i < n; i++) {
		cout << valores[i] << "\n";
	}

	return 0;
}