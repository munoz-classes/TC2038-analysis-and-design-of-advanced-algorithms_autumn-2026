/*
 * Descripcion: Implementacion de MergeSort (divide y venceras) que ordena
 *              N valores reales de mayor a menor.
 * Autor: Alan Joseph Salazar Segura - A01773491
 * Fecha: 21/08/2026
 */

#include <iostream>
#include <iomanip>
#include <vector>

using namespace std;

/*
 * Proposito: Fusiona dos subarreglos ya ordenados de manera descendente.
 * Complejidad temporal: O(N), donde N es la suma del tamano de ambos subarreglos.
 * Complejidad espacial: O(N) por los subarreglos temporales.
 * Parametros:
 *   arr: Referencia al arreglo original a ordenar.
 *   left: Indice inicial del subarreglo izquierdo.
 *   mid: Indice final del subarreglo izquierdo.
 *   right: Indice final del subarreglo derecho.
 * Valor de retorno: Ninguno (void).
 */
void merge(vector<double>& arr, int left, int mid, int right) {
    int sizeLeft = mid - left + 1;
    int sizeRight = right - mid;

    vector<double> leftArray(sizeLeft);
    vector<double> rightArray(sizeRight);

    for (int i = 0; i < sizeLeft; i++) {
        leftArray[i] = arr[left + i];
    }
    for (int j = 0; j < sizeRight; j++) {
        rightArray[j] = arr[mid + 1 + j];
    }

    int i = 0;
    int j = 0;
    int k = left;

    while (i < sizeLeft && j < sizeRight) {
        if (leftArray[i] >= rightArray[j]) {
            arr[k] = leftArray[i];
            i++;
        } else {
            arr[k] = rightArray[j];
            j++;
        }
        k++;
    }

    while (i < sizeLeft) {
        arr[k] = leftArray[i];
        i++;
        k++;
    }
    while (j < sizeRight) {
        arr[k] = rightArray[j];
        j++;
        k++;
    }
}

/*
 * Proposito: Divide recursivamente el arreglo y fusiona sus mitades ordenadas.
 * Complejidad temporal: O(N log N).
 * Complejidad espacial: O(N).
 * Parametros:
 *   arr: Referencia al arreglo a ordenar.
 *   left: Indice inicial del segmento a ordenar.
 *   right: Indice final del segmento a ordenar.
 * Valor de retorno: Ninguno (void).
 */
void mergeSort(vector<double>& arr, int left, int right) {
    if (left >= right) {
        return;
    }

    int mid = left + (right - left) / 2;

    mergeSort(arr, left, mid);
    mergeSort(arr, mid + 1, right);

    merge(arr, left, mid, right);
}

/*
 * Proposito: Lee N y los N valores de la entrada estandar, los ordena de mayor
 *            a menor e imprime el resultado, un valor por linea.
 * Complejidad temporal: O(N log N).
 * Complejidad espacial: O(N).
 * Parametros: Ninguno.
 * Valor de retorno: 0 si la ejecucion fue exitosa.
 */
int main() {
    int n = 0;

    if (!(cin >> n) || n <= 0) {
        return 0;
    }

    vector<double> arr(n);

    for (int i = 0; i < n; i++) {
        cin >> arr[i];
    }

    mergeSort(arr, 0, n - 1);

    cout << setprecision(10);
    for (int i = 0; i < n; i++) {
        cout << arr[i] << "\n";
    }

    return 0;
}
