#include <iostream>
using namespace std;

double datos[100];

//mergge sort basado en https://www.geeksforgeeks.org/dsa/merge-sort/
void merge(int ini, int mid, int fin) {

    int n1 = mid - ini + 1;
    int n2 = fin - mid;

    double parte1[100];
    double parte2[100];

    for (int i = 0; i < n1; i++)
        parte1[i] = datos[ini + i];

    for (int i = 0; i < n2; i++)
        parte2[i] = datos[mid + 1 + i];

    int a = 0, b = 0, pos = ini;

    while (a < n1 && b < n2) {
        if (parte1[a] >= parte2[b]) {
            datos[pos] = parte1[a];
            a++;
        } else {
            datos[pos] = parte2[b];
            b++;
        }
        pos++;
    }

    while (a < n1) {
        datos[pos] = parte1[a];
        a++;
        pos++;
    }

    while (b < n2) {
        datos[pos] = parte2[b];
        b++;
        pos++;
    }
}

void ordenar(int ini, int fin) {
    if (ini >= fin)
        return;

    int mid = (ini + fin) / 2;

    ordenar(ini, mid);
    ordenar(mid + 1, fin);
    merge(ini, mid, fin);
}

int main() {
    int n;
    cin >> n;

    for (int i = 0; i < n; i++)
        cin >> datos[i];

    ordenar(0, n - 1);

    for (int i = 0; i < n; i++)
        cout << datos[i] << endl;

    return 0;
}