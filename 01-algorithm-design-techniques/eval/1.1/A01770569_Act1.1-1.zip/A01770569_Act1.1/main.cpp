#include <iostream>
using namespace std;

/*
 * Función: merge
 * Combina dos mitades ya ordenadas (a[l..m] y a[m+1..r]) en una sola
 * mitad ordenada, usando un arreglo auxiliar temp[].
 *
 * Complejidad computacional:
 * Sea n = (r - l + 1) el número de elementos a combinar.
 * El primer while hace el reccorido ambas mitades en paralelo: O(n)
 * Los dos while siguientes copian lo que haya sobrado: en conjunto O(n)
 * El for final copia todo de temp[] de regreso a a[]: O(n)
 *   
 * Complejidad de la funcion merge: O(n)
 */
void merge(double a[], int l, int m, int r) {
    double temp[1000]; 
    int i = l, j = m + 1, k = 0; 

    // Comparamos elemento por elemento de las dos mitades y guardamos primero el mayor 
    while (i <= m && j <= r)
        temp[k++] = (a[i] > a[j]) ? a[i++] : a[j++];

    while (i <= m) temp[k++] = a[i++];

    while (j <= r) temp[k++] = a[j++];

    for (i = l, k = 0; i <= r; i++, k++)
        a[i] = temp[k];
}

/*
 * Función: mergeSort
 * Técnica de divide y vencerás: divide el arreglo en mitades
 * de forma recursiva hasta llegar a subarreglos de 1 elemento (ya ordenados
 * por definición), y luego los va combinando con merge().
 *
 * Complejidad computacional:
 *   - Sea n = (r - l + 1) el número de elementos a ordenar.
 *   - Se hacen 2 llamadas recursivas sobre la mitad del arreglo: T(n/2) + T(n/2)
 *   - Después de cada división se llama a merge(), que cuesta O(n)
 *   - Relación de recurrencia: T(n) = 2T(n/2) + O(n)
 *   - Por el Teorema Maestro, esto da: T(n) = O(n log n)
 */
void mergeSort(double a[], int l, int r) {
    if (l >= r) return; // caso base

    int m = (l + r) / 2; 
    mergeSort(a, l, m);     
    mergeSort(a, m + 1, r);  
    merge(a, l, m, r);   
}
/*
 * Función: main
 * Lee N valores double desde la entrada estándar, los ordena de mayor a menor usando mergeSort, y los imprime.
 * Complejidad:
 * Lectura de los N valores: O(n)
 * Llamada a mergeSort: O(n log n)  <- domina el costo total
 *Impresión de los N valores ordenados: O(n)
 * Complejidad total de main: O(n log n)
 */
int main() {
    int N;
    cin >> N;
    double a[1000]; 

    for (int i = 0; i < N; i++)
        cin >> a[i];

    // llamamos a mergeSort para ordenar todo el arreglo
    mergeSort(a, 0, N - 1);

    for (int i = 0; i < N; i++)
        cout << a[i] << endl;

    return 0;
}