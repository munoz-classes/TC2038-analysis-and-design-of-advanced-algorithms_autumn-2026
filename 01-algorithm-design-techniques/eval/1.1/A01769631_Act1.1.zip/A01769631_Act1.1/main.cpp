/*Actividad 1.1 Implementación de la técnica de programación "divide y vencerás".
Codigo Escritó por: José Pedro Rodríguez Munguía | A01769631*/
#include <bits/stdc++.h>
using namespace std;

int n;
double Input_Agregado;
vector<double> lista;

//tipo:pareja, usando dos vectores llamado separacion con un vector constante y un entero
pair<  vector<double>, vector<double>  > separacion( const vector<double>& Datos_a_separacion,int size);
//tipo:vector, usando dos vectores llamado separacion con un vector constante y un entero
vector<double> Vencer_y_Combinar( const vector<double>& Izquierda, const vector<double>& Derecha);

//Merge sort
vector<double> mergesort(vector<double> Vector_dado) {
    //  Casos base: vectores de tamaño 0, 1 y 2.
    //  Resolvibles sin Metodo 99 (Recursividad). 
    if (Vector_dado.size() <= 1) {
        return Vector_dado;
    }

    if (Vector_dado.size() == 2) {
        if (Vector_dado[0] < Vector_dado[1]) {
            swap(Vector_dado[0], Vector_dado[1]);
        }

        return Vector_dado;
    }

    // Separación a mitad izquierda y derecha.
    pair<vector<double>, vector<double>> Mitades = separacion(Vector_dado, Vector_dado.size());

    // Llamada recursiva hasta alcanzar el tamaño para caso base.
    vector<double> Mitad_Izquierda = mergesort(Mitades.first);
    vector<double> Mitad_Derecha = mergesort(Mitades.second);

    //Se ordena y combinar de mayor a menor hasta que no hay llamadas recursivas.
    return Vencer_y_Combinar(Mitad_Izquierda, Mitad_Derecha);
}

//Separación de mitades en caso de no cumplir con el caso base.
pair<  vector<double>, vector<double>  > separacion( const vector<double>& Datos_a_separacion,int size) {
    int size1;
    int size2;
    vector<double> firsthalf;
    vector<double> secondhalf;

    if (size < 0) {
        size = 0;
    }
    if (size != Datos_a_separacion.size()) {
        size = Datos_a_separacion.size();
    }

    size1 = size / 2;
    size2 = size - size1;

    //Utiliza "Mitades_Separadas" hasta llegar a la primera mitad (size1). Su contador es "Mitades_Separadas"
    for (int Mitades_Separadas = 0; Mitades_Separadas < size1; Mitades_Separadas++) {
        firsthalf.push_back(Datos_a_separacion[Mitades_Separadas]);
    }

    //Utiliza "Mitades separadas" hasta llegar a la secunda mitad (size2). Su contador es "Mitades_Separadas" + primera mitad
    for (int Mitades_Separadas = 0; Mitades_Separadas < size2; Mitades_Separadas++) {
        secondhalf.push_back(Datos_a_separacion[size1 + Mitades_Separadas]);
    }

    return {firsthalf, secondhalf};
}

//Combinación de mitades separadas despues de cumplir con el caso base en caso de no haber sido caso base desde el principio.
vector<double> Vencer_y_Combinar( const vector<double>& Izquierda, const vector<double>& Derecha ) {
    vector<double> Valores_Combinados;

    int Izquierda_Actual = 0;
    int Derecha_Actual = 0;

    int sizeIzquierda = Izquierda.size();
    int sizeDerecha = Derecha.size();

    //&& Significa: Mientras ambos sean verdaderos. 
    while (Izquierda_Actual < sizeIzquierda && Derecha_Actual < sizeDerecha) {
        if (Izquierda[Izquierda_Actual] >= Derecha[Derecha_Actual]) {
            Valores_Combinados.push_back(Izquierda[Izquierda_Actual]);
            Izquierda_Actual++;
        }
        else {
            Valores_Combinados.push_back(Derecha[Derecha_Actual]);
            Derecha_Actual++;
        }
    }

    //En caso de que Derecha_Actual sea mayor a su tamaño izquerdo, se aplica un contador unicamente para Izquierda_Actual
    while (Izquierda_Actual < sizeIzquierda) {
        Valores_Combinados.push_back(Izquierda[Izquierda_Actual]);
        Izquierda_Actual++;
    }

    //En caso de que Izquierda_Actual sea mayor a su tamaño izquerdo, se aplica un contador unicamente para Derecha_Actual
    while (Derecha_Actual < sizeDerecha) {
        Valores_Combinados.push_back(Derecha[Derecha_Actual]);
        Derecha_Actual++;
    }

    return Valores_Combinados;
}


int main() {
    /*Codigo para ejecutar en Windows:
    g++ main.cpp -o main.exe
    cmd /c "main.exe < In.txt"
    */
    
    
    //print("Actividad 1.1 Implementacion de la tecnica de programacion 'divide y venceras' \n");
    //printf("Codigo Escrito por: Jose Pedro Rodriguez Munguia | A01769631\n");
    scanf("%d", &n);
    while (n > 0) {
        scanf("%lf", &Input_Agregado);
        lista.push_back(Input_Agregado);
        n--;
    }

    lista = mergesort(lista);

    for (double valores : lista) {
        cout << valores << "\n";
    }

    // Formato alternativo que no se utilizó
    
    // printf("Los valores de la lista ordenados de mayor a menor son: \n");
    // if (lista.size() <= 20) {
    //     int contadortexto = 1;
    //     for (double valores : lista) {
    //         cout << contadortexto++ << ".- " << valores << "\n";
    //     }
    // }
    // if (lista.size() > 20) {
    //     for (double valores : lista) {
    //         cout << valores << " | ";
    //     }
    // }

    return 0;
}