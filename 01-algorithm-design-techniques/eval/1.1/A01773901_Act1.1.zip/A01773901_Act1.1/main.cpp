#include <iostream>
#include <vector>
#include <iomanip>

using namespace std;

void merge(vector <double> & arr, int izq, int medio, int der) {
    int n1 = medio-  izq + 1;
    int n2 = der - medio;          // subarreglo derecho

    vector<double> izquierda(n1);
    vector<double> derecha(n2);

    for (int i = 0; i < n1; i++) {
        izquierda[i] = arr[izq + i];
    }
    for (int j = 0; j < n2; j++) {
        derecha[j] = arr[medio + 1 + j];
    }

    int i = 0;
    int j = 0;
    int k = izq  ;

    while (i < n1 && j < n2) {
        if ( izquierda[i] >= derecha[j]) {
            arr [k] = izquierda[i];
            i++;
        } else {
            arr [k] = derecha[j];
            j++ ;
        }
        k++;
    }

    while (i < n1) {
        arr [k] = izquierda[i];
        i++;
        k++;
    }

    while (j < n2) {
        arr [k] = derecha[j];
        j++;
        k++;
    }
}

void mergeSort (vector<double>& arr, int izq, int der) {
    if (izq >= der) {
        return; // caso base
    }

    int medio = izq + (der - izq) / 2;

    mergeSort(arr, izq, medio);
    mergeSort(arr, medio + 1, der);

    
    merge(arr, izq, medio, der);
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);

    int n;
    if (!(cin >> n)) {
        return 0  ;
    }

    vector<double> valores(n);
    for (int i = 0; i < n; i++) {
        cin >> valores[i];
    }

    if (n > 1)  {
        mergeSort(valores, 0, n - 1);
    }

    cout << fixed << setprecision(2);
    for (int i = 0; i < n; i++) {
        cout << valores[i] << "\n";
    }

    return 0;
}
