Actividad 1.1 - MergeSort (Divide y venceras)
Matricula: A01774031

Descripcion:
El programa lee un entero N y despues N valores reales (double), uno por linea.
Ordena los valores de mayor a menor usando MergeSort y los imprime uno por linea.

Compilacion:
g++ main.cpp

Ejecucion:
./a.out < in.txt

Complejidad computacional:

Funcion merge:
Recorre los dos subarreglos una sola vez para combinarlos.
Complejidad: O(n), donde n es el numero de elementos del rango a combinar.

Funcion mergeSort:
Divide el arreglo en dos mitades en cada llamada (divide y venceras) y despues
las combina con merge.
Complejidad: O(n log n) en el mejor, promedio y peor caso.

Complejidad espacial:
O(n) por los arreglos auxiliares que se crean en cada combinacion.
