package A01773449_Act1_3;
import java.util.ArrayList;

// Claudia Vanessa Hermosillo Diaz A01773449 (este estuvo muy complejo :(((( si tuve que buscar ayuda)

public class Main {

    public static void main(String[] args) {
        // Se define M y N
        int M = 4;
        int N = 4;

        // se define la matriz que representa el laberinto (1 representando camino, 0 representando pared)
        int[][] laberinto = {
            {1, 0, 0, 0},
            {1, 1, 0, 1},
            {0, 1, 0, 0},
            {1, 1, 1, 1}
        };

        // matriz que guardara el resultado por backtracking
        int[][] resultadoBT = new int[M][N];

        // llamado a la funcion de backtracking iniciando en la casilla (0,0)
        resolverBT(laberinto, 0, 0, M, N, resultadoBT);

        // solucion de backtracking a partir del resultadoBT
        for (int i = 0; i < M; i++) {
            for (int j = 0; j < N; j++) {
                System.out.print(resultadoBT[i][j]);
                // ponemos espacio entre numeros excepto en el ultimo elemento de la fila (para que se vea bonito vaya y no todo pegado)
                if (j < N - 1) {
                    System.out.print(" ");
                }
            }
            // se agrgega un SOUT como salto de linea al terminar la fila
            System.out.println();
        }

        System.out.println();

        // llamado a la funcion de ramificacion y poda pasando el laberinto y sus dimensiones
        int[][] resultadoRP = resolverRP(laberinto, M, N);

        // solucion de ramificacion y poda a partir de resultadoRP
        for (int i = 0; i < M; i++) {
            for (int j = 0; j < N; j++) {
                System.out.print(resultadoRP[i][j]);
                if (j < N - 1) {
                    System.out.print(" ");
                }
            }
            // salto de linea para pasar a la siguiente fila
            System.out.println();
        }
    }

    // definicion de la funcion resolverBT con el laberinto, la fila y columna actuales, sus dimensiones m y n y la matriz de la solucion como parametros
    public static boolean resolverBT(int[][] lab, int f, int c, int M, int N, int[][] sol) {
        /*
        casos base de la poda
        si el indice de fila o columna se sale de los limites de la matriz,
        si la casilla es una pared (0) o si ya la marcamos en el camino actual (1), regresamos false
        para no seguir explorando esa rama
        */
        if (f < 0 || f >= M || c < 0 || c >= N || lab[f][c] == 0 || sol[f][c] == 1) {
            return false;
        }

        // marcamos la casilla actual como parte de la solucion
        sol[f][c] = 1;

        // si llegamos a la casilla meta (M-1, N-1) terminamos con exito
        if (f == M - 1 && c == N - 1) {
            return true;
        }

        /*
        intentamos movernos en las 4 direcciones posibles (abajo, derecha, arriba, izquierda)
        usando llamadas recursivas; si alguna de ellas encuentra el camino a la salida regresa true
        */
        if (resolverBT(lab, f + 1, c, M, N, sol)) return true;
        if (resolverBT(lab, f, c + 1, M, N, sol)) return true;
        if (resolverBT(lab, f - 1, c, M, N, sol)) return true;
        if (resolverBT(lab, f, c - 1, M, N, sol)) return true;

        /*
        si ninguna de las 4 direcciones nos llevo a la meta, desmarcamos
        la casilla actual regresandola a 0 para probar otra alternativa
        */
        sol[f][c] = 0;
        return false;
    }

    // definicion de la funcion resolverRP con el laberinto y sus dimensiones M y N como parametros
    public static int[][] resolverRP(int[][] lab, int M, int N) {
        // se crea la matriz que guardara el camino final
        int[][] sol = new int[M][N];

        // si la entrada es pared, no hay solucion
        if (lab[0][0] == 0) return sol;

        // creamos dos arraylist para las filas y columnas que aun no se explroan 
        ArrayList<Integer> colaF = new ArrayList<>();
        ArrayList<Integer> colaC = new ArrayList<>();

        // matriz booleana para recordar casillas ya visitadas
        boolean[][] visitado = new boolean[M][N];

        // matrices para rastrear de que casilla padre vino cada coordenada y reconstruir el camino al final
        int[][] padreF = new int[M][N];
        int[][] padreC = new int[M][N];

        // insertamos la posicion inicial (0,0) y la marcamos como visitada
        colaF.add(0);
        colaC.add(0);
        visitado[0][0] = true;
        padreF[0][0] = -1;
        padreC[0][0] = -1;

        boolean llego = false;

        // mientras sigan existiendo casillas pendientes en la lista por explorar
        while (colaF.size() > 0) {
            // tomamos el primer elemento de la lista 
            int f = colaF.remove(0);
            int c = colaC.remove(0);

            // si alcanzamos la meta salimos del ciclo
            if (f == M - 1 && c == N - 1) {
                llego = true;
                break;
            }

            // arreglos con los 4 desplazamientos posibles: abajo, derecha, arriba, izquierda
            int[] df = {1, 0, -1, 0};
            int[] dc = {0, 1, 0, -1};

            /*
            se generan los posibles nodos hijos en las 4 direcciones
            aplicando la poda si estan fuera de rango, si son paredes o si ya se habian visitado
            */
            for (int i = 0; i < 4; i++) {
                int nf = f + df[i];
                int nc = c + dc[i];

                if (nf >= 0 && nf < M && nc >= 0 && nc < N && lab[nf][nc] == 1 && !visitado[nf][nc]) {
                    visitado[nf][nc] = true;
                    padreF[nf][nc] = f;
                    padreC[nf][nc] = c;
                    colaF.add(nf);
                    colaC.add(nc);
                }
            }
        }

        /*
        si encontramos la salida, reconstruimos el camino retrocediendo desde la meta
        hacia el origen usando las matrices de padres
        */
        if (llego) {
            int f = M - 1;
            int c = N - 1;
            while (f != -1 && c != -1) {
                sol[f][c] = 1;
                int antF = padreF[f][c];
                int antC = padreC[f][c];
                f = antF;
                c = antC;
            }
        }

        // retornamos la matriz con el camino marcado
        return sol;
    }
}