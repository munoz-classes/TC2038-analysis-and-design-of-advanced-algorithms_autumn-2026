from collections import deque

# Leer entrada
M = int(input())
N = int(input())

laberinto = []

for i in range(M):
    fila = list(map(int, input().split()))
    laberinto.append(fila)


# BACKTRACKING
def resolver_backtracking():
    solucion = [[0 for j in range(N)] for i in range(M)]
    visitado = [[False for j in range(N)] for i in range(M)]

    def buscar(x, y):
        if x < 0 or x >= M or y < 0 or y >= N:
            return False

        if laberinto[x][y] == 0 or visitado[x][y]:
            return False

        visitado[x][y] = True
        solucion[x][y] = 1

        if x == M - 1 and y == N - 1:
            return True

        movimientos = [(1, 0), (0, 1), (-1, 0), (0, -1)]

        for dx, dy in movimientos:
            if buscar(x + dx, y + dy):
                return True

        solucion[x][y] = 0
        return False

    buscar(0, 0)
    return solucion


# RAMIFICACION Y PODA
def resolver_ramificacion_poda():
    solucion = [[0 for j in range(N)] for i in range(M)]

    cola = deque()
    cola.append([(0, 0)])

    visitado = set()
    visitado.add((0, 0))

    movimientos = [(1, 0), (0, 1), (-1, 0), (0, -1)]

    while cola:
        camino = cola.popleft()
        x, y = camino[-1]

        if x == M - 1 and y == N - 1:
            for a, b in camino:
                solucion[a][b] = 1
            return solucion

        for dx, dy in movimientos:
            nuevo_x = x + dx
            nuevo_y = y + dy

            # Poda de movimientos que no son validos
            if (nuevo_x >= 0 and nuevo_x < M and
                nuevo_y >= 0 and nuevo_y < N and
                laberinto[nuevo_x][nuevo_y] == 1 and
                (nuevo_x, nuevo_y) not in visitado):

                visitado.add((nuevo_x, nuevo_y))
                nuevo_camino = camino + [(nuevo_x, nuevo_y)]
                cola.append(nuevo_camino)

    return solucion


solucion_backtracking = resolver_backtracking()
solucion_ramificacion = resolver_ramificacion_poda()


# Imprimir solucion de Backtracking
for fila in solucion_backtracking:
    print(*fila)

print()

# Imprimir solucion de Ramificacion y Poda
for fila in solucion_ramificacion:
    print(*fila)
