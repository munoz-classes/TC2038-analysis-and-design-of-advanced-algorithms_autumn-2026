// Resuelve un laberinto con backtracking y con ramificacion y poda.
// Autor: Leonardo Rulfo Soto, matricula A01773729
// Fecha: 31/08/2026

#include <iostream>
#include <vector>

using namespace std;

int m, n;
vector<vector<int>> mat;
vector<vector<bool>> vis;

int dx[4] = { 1, -1, 0, 0 };
int dy[4] = { 0, 0, 1, -1 };

// checa si se puede pisar la casilla (x, y)
bool valido(int x, int y)
{
	if (x < 0 || x >= m || y < 0 || y >= n)
	{
		return false;
	}

	if (mat[x][y] == 0 || vis[x][y])
	{
		return false;
	}

	return true;
}

// backtracking: se detiene en la primera solucion que encuentre
bool backtracking(int x, int y, vector<vector<int>>& camino)
{
	vis[x][y] = true;
	camino[x][y] = 1;

	if (x == m - 1 && y == n - 1)
	{
		return true;
	}

	for (int i = 0; i < 4; i++)
	{
		int nx = x + dx[i];
		int ny = y + dy[i];

		if (valido(nx, ny))
		{
			if (backtracking(nx, ny, camino))
			{
				return true;
			}
		}
	}

	camino[x][y] = 0;
	return false;
}

// ramificacion y poda: sigue buscando otras soluciones y se queda
// con la mas corta. Si un camino ya va mas largo que el mejor que
// llevamos, se corta ahi (esa es la poda).
int mejorLargo;
vector<vector<int>> mejorCamino;

void ramaYPoda(int x, int y, int largo, vector<vector<int>>& camino)
{
	if (largo >= mejorLargo)
	{
		return;
	}

	vis[x][y] = true;
	camino[x][y] = 1;

	if (x == m - 1 && y == n - 1)
	{
		mejorLargo = largo;
		mejorCamino = camino;
	}
	else
	{
		for (int i = 0; i < 4; i++)
		{
			int nx = x + dx[i];
			int ny = y + dy[i];

			if (valido(nx, ny))
			{
				ramaYPoda(nx, ny, largo + 1, camino);
			}
		}
	}

	vis[x][y] = false;
	camino[x][y] = 0;
}

void imprimir(vector<vector<int>>& c)
{
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
		{
			cout << c[i][j];

			if (j < n - 1)
			{
				cout << " ";
			}
		}
		cout << endl;
	}
}

int main()
{
	cin >> m >> n;

	mat = vector<vector<int>>(m, vector<int>(n));

	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
		{
			cin >> mat[i][j];
		}
	}

	// backtracking
	vis = vector<vector<bool>>(m, vector<bool>(n, false));
	vector<vector<int>> c1(m, vector<int>(n, 0));
	backtracking(0, 0, c1);
	imprimir(c1);

	cout << endl;

	// ramificacion y poda
	vis = vector<vector<bool>>(m, vector<bool>(n, false));
	vector<vector<int>> c2(m, vector<int>(n, 0));
	mejorLargo = m * n + 1;
	ramaYPoda(0, 0, 1, c2);
	imprimir(mejorCamino);

	return 0;
}
