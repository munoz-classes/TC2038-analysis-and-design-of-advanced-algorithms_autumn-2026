// main.cpp
// Actividad 1.3 - Laberinto con Backtracking y Ramificacion y Poda
// A01773902

#include <iostream>
#include <vector>

using namespace std;

// Backtracking: intenta un camino de (fila,columna) hasta (M-1,N-1).
// Marca la celda en la matriz solucion y si no funciona la regresa a 0.
// Complejidad: O(4^(M*N)) en el peor caso.
bool resolverBacktracking(const vector<vector<int>>& laberinto,
                           vector<vector<int>>& solucion,
                           int fila, int columna, int M, int N) {
    if (fila < 0 || fila >= M || columna < 0 || columna >= N) {
        return false;
    }
    if (laberinto[fila][columna] == 0 || solucion[fila][columna] == 1) {
        return false;
    }

    solucion[fila][columna] = 1;

    if (fila == M - 1 && columna == N - 1) {
        return true;
    }

    if (resolverBacktracking(laberinto, solucion, fila, columna + 1, M, N)) return true;
    if (resolverBacktracking(laberinto, solucion, fila + 1, columna, M, N)) return true;
    if (resolverBacktracking(laberinto, solucion, fila, columna - 1, M, N)) return true;
    if (resolverBacktracking(laberinto, solucion, fila - 1, columna, M, N)) return true;

    solucion[fila][columna] = 0;
    return false;
}

// Ramificacion y poda: igual que backtracking, pero antes de entrar a una
// celda revisa si todavia se puede llegar a la meta (distancia Manhattan
// contra las celdas libres que quedan). Si no se puede, no entra.
// Complejidad: O(4^(M*N)) en el peor caso, pero explora menos ramas.
bool resolverRamificacionPoda(const vector<vector<int>>& laberinto,
                               vector<vector<int>>& solucion,
                               int fila, int columna, int M, int N,
                               int totalLibres, int visitados) {
    if (fila < 0 || fila >= M || columna < 0 || columna >= N) {
        return false;
    }
    if (laberinto[fila][columna] == 0 || solucion[fila][columna] == 1) {
        return false;
    }

    int distancia = (M - 1 - fila) + (N - 1 - columna);
    int disponibles = totalLibres - visitados;
    if (distancia > disponibles) {
        return false;
    }

    solucion[fila][columna] = 1;
    visitados++;

    if (fila == M - 1 && columna == N - 1) {
        return true;
    }

    if (resolverRamificacionPoda(laberinto, solucion, fila, columna + 1, M, N, totalLibres, visitados)) return true;
    if (resolverRamificacionPoda(laberinto, solucion, fila + 1, columna, M, N, totalLibres, visitados)) return true;
    if (resolverRamificacionPoda(laberinto, solucion, fila, columna - 1, M, N, totalLibres, visitados)) return true;
    if (resolverRamificacionPoda(laberinto, solucion, fila - 1, columna, M, N, totalLibres, visitados)) return true;

    solucion[fila][columna] = 0;
    return false;
}

// Imprime la matriz con espacios entre valores.
void imprimirMatriz(const vector<vector<int>>& matriz) {
    for (const auto& fila : matriz) {
        for (size_t j = 0; j < fila.size(); j++) {
            cout << fila[j];
            if (j + 1 < fila.size()) cout << " ";
        }
        cout << "\n";
    }
}

int main() {
    int M, N;
    cin >> M >> N;

    vector<vector<int>> laberinto(M, vector<int>(N));
    int totalLibres = 0;
    for (int i = 0; i < M; i++) {
        for (int j = 0; j < N; j++) {
            cin >> laberinto[i][j];
            if (laberinto[i][j] == 1) totalLibres++;
        }
    }

    vector<vector<int>> solucionBacktracking(M, vector<int>(N, 0));
    resolverBacktracking(laberinto, solucionBacktracking, 0, 0, M, N);
    imprimirMatriz(solucionBacktracking);

    cout << "\n";

    vector<vector<int>> solucionRamificacionPoda(M, vector<int>(N, 0));
    resolverRamificacionPoda(laberinto, solucionRamificacionPoda, 0, 0, M, N, totalLibres, 0);
    imprimirMatriz(solucionRamificacionPoda);

    return 0;
}
