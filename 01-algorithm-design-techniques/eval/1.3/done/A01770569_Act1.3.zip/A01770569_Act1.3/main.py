import sys
# BACKTRACKING
# Tiempo: O(4^(M*N)) peor caso.
# Espacio: O(M*N).
def backtracking(laberinto, camino, visitado, f, c):
    m = len(laberinto)
    n = len(laberinto[0])

    # Meta
    if f == m - 1 and c == n - 1:
        camino[f][c] = 1
        return True

    # Casilla fuera del laberinto o bloqueada
    if f < 0 or f >= m or c < 0 or c >= n:
        return False

    if laberinto[f][c] == 0 or visitado[f][c]:
        return False

    visitado[f][c] = True
    camino[f][c] = 1

    movimientos = [(1, 0), (0, 1), (-1, 0), (0, -1)]

    for df, dc in movimientos:
        if backtracking(laberinto, camino, visitado,
                        f + df, c + dc):
            return True

    # El camino no funcionó, regresamos
    camino[f][c] = 0
    return False


# RAMIFICACIÓN Y PODA
# Tiempo: O(4^(M*N)) peor caso.
# Espacio: O(M*N).
def ramificacion_poda(laberinto):
    m = len(laberinto)
    n = len(laberinto[0])

    # Cada elemento es: (fila, columna, camino)
    caminos = [(0, 0, [(0, 0)])]

    # Guarda cuántos pasos se necesitaron
    # para llegar a cada casilla.
    mejor = {}

    while caminos:
        f, c, camino = caminos.pop(0)

        # Meta
        if f == m - 1 and c == n - 1:
            solucion = [[0] * n for _ in range(m)]

            for x, y in camino:
                solucion[x][y] = 1

            return solucion

        movimientos = [(1, 0), (0, 1), (-1, 0), (0, -1)]

        for df, dc in movimientos:
            nf = f + df
            nc = c + dc

            if 0 <= nf < m and 0 <= nc < n:
                if laberinto[nf][nc] == 1:
                    if (nf, nc) not in camino:

                        pasos = len(camino)

                        # PODA:
                        # Si se llega con menos pasos a una casilla, se descarta el camino actual.
                        if ((nf, nc) not in mejor or
                                pasos < mejor[(nf, nc)]):

                            mejor[(nf, nc)] = pasos
                            nuevo_camino = camino + [(nf, nc)]

                            caminos.append(
                                (nf, nc, nuevo_camino)
                            )

    # No existe solución
    return [[0] * n for _ in range(m)]


def imprimir(matriz):
    for fila in matriz:
        print(*fila)


def main():
    datos = list(map(int, sys.stdin.read().split()))

    m = datos[0]
    n = datos[1]

    laberinto = []
    pos = 2

    for i in range(m):
        laberinto.append(datos[pos:pos + n])
        pos += n

    # Solución con Backtracking
    camino = [[0] * n for _ in range(m)]
    visitado = [[False] * n for _ in range(m)]

    backtracking(laberinto, camino, visitado, 0, 0)

    imprimir(camino)
    print()

    # Solución con Ramificación y Poda
    solucion = ramificacion_poda(laberinto)

    imprimir(solucion)


if __name__ == "__main__":
    main()
