#include <iostream>
#include <vector>
using namespace std;

// Direcciones de movimiento en orden fijo derecha, abajo, izquierda, arriba.
static const int D_FILA[] = {0, 1, 0, -1};
static const int D_COLUMNA[] = {1, 0, -1, 0};

//Dar una matriz de 0/1, una fila por linea, valores separados por espacio
void imprimirMatriz(const vector<vector<int>>& matriz) {
    for (const auto& fila : matriz) {
        for (size_t j = 0; j < fila.size(); ++j) {
            cout << fila[j];
            if (j + 1 < fila.size()) cout << " ";
        }
        cout << "\n";
    }
}
/*
 * Busca un camino de (0,0) a (M-1,N-1) con DFS y backtracking, probando las direcciones en orden derecha,abajo,izquierda,arriba y haciendose para atras si una rama no llega a la meta
 * Complejidad computacional:
 *   Tiempo:  O(M*N) (cada casilla se visita una sola vez gracias a 'visitado')
 *   Espacio: O(M*N)
 */
bool resolverConBacktracking(const vector<vector<int>>& laberinto,
                              vector<vector<int>>& solucion,
                              vector<vector<bool>>& visitado,
                              int fila, int columna) {
    int m = static_cast<int>(laberinto.size());
    int n = static_cast<int>(laberinto[0].size());

    visitado[fila][columna] = true;
    solucion[fila][columna] = 1;

    if (fila == m - 1 && columna == n - 1) {
        return true; // se llego a la meta
    }

    for (int d = 0; d < 4; ++d) {
        int nf = fila + D_FILA[d];
        int nc = columna + D_COLUMNA[d];
        if (nf >= 0 && nf < m && nc >= 0 && nc < n &&
            laberinto[nf][nc] == 1 && !visitado[nf][nc]) {
            if (resolverConBacktracking(laberinto, solucion, visitado, nf, nc)) {
                return true;
            }
        }
    }

    // Ninguna direccion desde aqui llega a la meta: se retrocede.
    solucion[fila][columna] = 0;
    return false;
}

/*
 * Distancia Manhattan de a la meta cota inferior de pasos restantes
 * Complejidad computacional: Tiempo O(1), Espacio O(1)
 */
int calcularCotaInferior(int fila, int columna, int m, int n) {
    return (m - 1 - fila) + (n - 1 - columna);
}

/*
 * Busca el camino mas corto con ramificacion y poda descarta cualquier rama que ya no se pueda mejorar
 * Complejidad computacional:
 *   Tiempo:  O(4^(M*N))
 *   Espacio: O(M*N)
 */
void resolverConRamificacionYPoda(const vector<vector<int>>& laberinto,
                                   vector<vector<int>>& solucionParcial,
                                   vector<vector<int>>& mejorSolucion,
                                   vector<vector<bool>>& visitado,
                                   int fila, int columna,
                                   int profundidad, int& mejorLongitud) {
    int m = static_cast<int>(laberinto.size());
    int n = static_cast<int>(laberinto[0].size());

    // Poda: si ni en el mejor de los casos esta rama puede igualar o mejorar la mejor solucion conocida
    int cota = profundidad + calcularCotaInferior(fila, columna, m, n);
    if (cota >= mejorLongitud) {
        return;
    }

    visitado[fila][columna] = true;
    solucionParcial[fila][columna] = 1;

    if (fila == m - 1 && columna == n - 1) {
        // si se encontro un camino mejor que el mejor conocido.
        mejorLongitud = profundidad;
        mejorSolucion = solucionParcial;
    } else {
        for (int d = 0; d < 4; ++d) {
            int nf = fila + D_FILA[d];
            int nc = columna + D_COLUMNA[d];
            if (nf >= 0 && nf < m && nc >= 0 && nc < n &&
                laberinto[nf][nc] == 1 && !visitado[nf][nc]) {
                resolverConRamificacionYPoda(laberinto, solucionParcial, mejorSolucion,
                                              visitado, nf, nc, profundidad + 1, mejorLongitud);
            }
        }
    }

    // va para atras para checar otras ramas
    visitado[fila][columna] = false;
    solucionParcial[fila][columna] = 0;
}

int main() {
    cerr << "Laberinto Backtracking vs Ramificacion y Poda\n";
    cerr << "Un 1 = casilla transitable, un 0 = casilla bloqueada.\n";
    cerr << "El inicio siempre es (0,0) y la meta siempre es (M-1,N-1).\n\n";

    cerr << "Pon M y N (numero de filas y columnas del laberinto): ";
    int m, n;
    if (!(cin >> m >> n) || m <= 0 || n <= 0) {
        //M y N tienen que ser enteros positivos
        cerr << "\nEntrada invalida: M y N tienen que ser enteros positivos.\n";
        return 1;
    }

    vector<vector<int>> laberinto(static_cast<size_t>(m), vector<int>(static_cast<size_t>(n)));
    for (int i = 0; i < m; ++i) {
        cerr << "Da la fila " << (i + 1) << " de " << m
             << " (" << n << " valores 0/1 separados por espacio): ";
        for (int j = 0; j < n; ++j) {
            cin >> laberinto[static_cast<size_t>(i)][static_cast<size_t>(j)];
        }
    }

    //backtracking
    vector<vector<int>> solucionBacktracking(static_cast<size_t>(m), vector<int>(static_cast<size_t>(n), 0));
    vector<vector<bool>> visitadoBacktracking(static_cast<size_t>(m), vector<bool>(static_cast<size_t>(n), false));
    bool encontradoBacktracking = false;
    if (laberinto[0][0] == 1) {
        encontradoBacktracking = resolverConBacktracking(laberinto, solucionBacktracking, visitadoBacktracking, 0, 0);
    }
    if (!encontradoBacktracking) {
        cerr << "Backtracking: no existe un camino de salida.\n";
    }
    cerr << "\nResultado con Backtracking\n";
    imprimirMatriz(solucionBacktracking);

    cout << "\n";

    //ramificacion y poda
    vector<vector<int>> solucionParcial(static_cast<size_t>(m), vector<int>(static_cast<size_t>(n), 0));
    vector<vector<int>> mejorSolucion(static_cast<size_t>(m), vector<int>(static_cast<size_t>(n), 0));
    vector<vector<bool>> visitadoRP(static_cast<size_t>(m), vector<bool>(static_cast<size_t>(n), false));
    int mejorLongitud = m * n + 1; // cota superior inicial ningun camino usa mas de M*N casillas
    if (laberinto[0][0] == 1) {
        resolverConRamificacionYPoda(laberinto, solucionParcial, mejorSolucion, visitadoRP, 0, 0, 1, mejorLongitud);
    }
    if (mejorLongitud == m * n + 1) {
        cerr << "Ramificacion y poda: no existe un camino de salida\n";
    }
    cerr << "\nResultado con Ramificacion y Poda\n";
    imprimirMatriz(mejorSolucion);

    return 0;
}