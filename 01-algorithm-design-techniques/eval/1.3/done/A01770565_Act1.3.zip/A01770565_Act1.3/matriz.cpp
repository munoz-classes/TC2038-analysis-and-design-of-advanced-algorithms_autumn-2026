/*
Alberto Guillen Rayas
A01770565
*/

#include <iostream>
#include <vector>
#include <queue>

using namespace std;

/*Back tracking complejidad O(M X N)*/
//posibles movimientos
int df[] = {1, 0, -1, 0};
int dc[] = {0, 1, 0, -1}; 

/*Asumiremos que empezaremos en la esquina superior izquierda
para empezar el algoritmo y hacemos una funcion auxiliar que 
valide la longitud */
bool Valido(const std::vector<std::vector<int>> & laberinto,
const std::vector<std::vector<int>> & solucion, int f, int c, int M, int N){

    //Delimitar el borde de la matriz
    if (f >= 0 && f < M && c >= 0 && c < N){
        if (laberinto[f][c] == 1 && solucion[f][c] == 0){
            return true;
        }
    }
    return false;
}

bool resolverBack(const std::vector<std::vector<int>> & laberinto, 
    std::vector<std::vector<int>> & solucion, int f, int c, int M, int N){

    // caso base llegar a la meta
    if (f == M - 1 && c == N - 1 && laberinto[f][c] == 1){
        solucion[f][c] = 1;
        return true;
    }

    // combrobar si la casilla actual es valida
    if (Valido(laberinto, solucion, f, c, M, N)){
        //marcar la casilla
        solucion[f][c] = 1;

        //intentar las 4 direcciones
        for (int i = 0; i < 4; i++) {
            int sigRen = f + df[i];
            int sigCol = c + dc[i];

            if (resolverBack(laberinto, solucion, sigRen, sigCol, M, N)){
                return true;
            }
        }
        //podamos sii no funciono ninguna solucion
        solucion[f][c] = 0;
        return false;
    }
    return false;
}


/*Ramificacion
complejidad O( M X N)*/

//funcion auxiliar para saber la pocision de la casilla
struct casilla {
    int f, c;
};

void resolverRamific(const std::vector<std::vector<int>> & laberinto,
    std::vector<std::vector<int>> & solucion, int M, int N){

        //Casos si la salida es bloqueada
        if (laberinto[0][0] == 0 || laberinto[M - 1][N - 1] == 0){
            return;
        
        }
        //posibles moovimientos
        int df[] = {1, 0, -1, 0};
        int dc[] = {0, 1, 0, -1};

        //esta matriz evita procesar casillas repetidas
        std::vector<std::vector<bool>> visitado(M, std::vector<bool>(N, false));

        //matriz padre la cual inicializamos con (-1,-1) que indiica sin padre
        std::vector<std::vector<casilla>> padre(M, std::vector<casilla>(N, {-1, -1}));

        //cola de priordad
        std::queue<casilla> cola;

        //inicializamos en el origen(0,0)
        cola.push({0, 0});
        visitado[0][0] = true;

        bool alcanzado = false;

        //ramificacion
        while(!cola.empty()){
            casilla actual = cola.front();
            cola.pop();

            //detener la busqueda si llegamos al final
            if (actual.f == M - 1 && actual.c == N -1){
                alcanzado = true;
                break;
            }

            //ramificacion en las 4 direcciones
            for (int i = 0; i <4; i++){
                int sigRen = actual.f + df[i];
                int sigCol = actual.c + dc[i];

                //poda
                if (sigRen >= 0 && sigRen < M && sigCol >= 0 && sigCol < N){
                    if (laberinto[sigRen][sigCol] == 1 && !visitado[sigRen][sigCol]){
                        visitado[sigRen][sigCol] = true;
                        padre[sigRen][sigCol] = actual;
                        cola.push({sigRen, sigCol});
                    }
                }
            }
        }

        //recontruccion de camino
        if(alcanzado){
            int currRen = M - 1;
            int currCol = N - 1;
            
            //navegar completamente 
            while (currRen != -1 && currCol != -1){
                solucion[currRen][currCol] = 1;
                casilla p = padre[currRen][currCol];
                currRen = p.f;
                currCol = p.c;

            }
        }
}

int main(){
    int M, N;
    if (!(cin >> M >> N)) return 0;

    std::vector<std::vector<int>> laberinto(M, std::vector<int>(N));
    for (int i = 0; i < M; i++){
        for (int j = 0; j < N; j++){
            cin >> laberinto[i][j]; 
        }
    }

    //backtracking
   std::vector<std::vector<int>> solBack(M, std::vector<int>(N, 0));
    resolverBack(laberinto, solBack, 0, 0, M, N);

    for (int i = 0; i < M; i++) {
        for (int j = 0; j < N; j++) {
            cout << solBack[i][j] << (j == N - 1 ? "" : " ");
        }
        cout << endl;
    }

    cout << endl; // Línea de separación entre soluciones

    // 2. Resolver con Ramificación y Poda
    std::vector<std::vector<int>> solRamific(M, std::vector<int>(N, 0));
    resolverRamific(laberinto, solRamific, M, N);

    for (int i = 0; i < M; i++) {
        for (int j = 0; j < N; j++) {
            cout << solRamific[i][j] << (j == N - 1 ? "" : " ");
        }
        cout << endl;
    }

    return 0;

}