/*
 * Programa: Solucion de un laberinto con backtracking y ramificacion y poda.
 * Nombre: Tabata Carolina Salinas Valdez
 * Matricula: A01770901
 * Fecha: 31/08/2026
 */

#include <iostream>

using namespace std;

/*
 * Verificar si una posicion es valida para continuar el camino.
 * Parametros:
 * laberinto: Matriz del laberinto.
 * camino: Matriz de posiciones visitadas.
 * filas: Numero de filas.
 * columnas: Numero de columnas.
 * fila: Fila de la posicion.
 * columna: Columna de la posicion.
 * Retorno:
 * True si la posicion es valida; false en otro caso.
 * Complejidad: O(1).
 */
bool posicionValida(int** laberinto, int** camino, int filas,
                    int columnas, int fila, int columna)
{
	bool valida = false;
	if (fila >= 0 && fila < filas && columna >= 0 && columna < columnas)
	{
		if (laberinto[fila][columna] == 1 &&
			camino[fila][columna] == 0)
		{
			valida = true;
		}
	}
	return valida;
}

/*
 * Encuentra un camino mediante backtracking.
 * Parametros:
 * laberinto: Matriz del laberinto.
 * camino: Matriz donde se guarda el camino.
 * filas: Numero de filas.
 * columnas: Numero de columnas.
 * fila: Fila actual.
 * columna: Columna actual.
 * Retorno:
 * True si encuentra la meta; false si no existe un camino.
 * Complejidad: O(4^(M*N)) en el peor caso.
 */
bool backtracking(int** laberinto, int** camino, int filas,
                  int columnas, int fila, int columna)
{
	bool encontrado = false;
	if (posicionValida(laberinto, camino, filas, columnas, fila, columna))
	{
		camino[fila][columna] = 1;

		if (fila == filas - 1 && columna == columnas - 1)
		{
			encontrado = true;
		}
		else
		{
			encontrado = backtracking(laberinto, camino, filas, columnas,
			                          fila + 1, columna);
			if (!encontrado)
			{
				encontrado = backtracking(laberinto, camino, filas, columnas,
				                          fila, columna + 1);
			}
			if (!encontrado)
			{
				encontrado = backtracking(laberinto, camino, filas, columnas,
				                          fila - 1, columna);
			}
			if (!encontrado)
			{
				encontrado = backtracking(laberinto, camino, filas, columnas,
				                          fila, columna - 1);
			}
		}
		if (!encontrado)
		{
			camino[fila][columna] = 0;
		}
	}
	return encontrado;
}

/*
 * Busca el camino mas corto mediante ramificacion y poda.
 * Parametros:
 * laberinto: Matriz del laberinto.
 * camino: Camino que se esta explorando.
 * mejorCamino: Mejor camino encontrado.
 * filas: Numero de filas.
 * columnas: Numero de columnas.
 * fila: Fila actual.
 * columna: Columna actual.
 * longitud: Longitud del camino actual.
 * mejorLongitud: Longitud del mejor camino.
 * Retorno:
 * Nada.
 * Complejidad: O(M*N*4^(M*N)) en el peor caso.
 */
void ramificacionPoda(int** laberinto, int** camino, int** mejorCamino,
                      int filas, int columnas, int fila, int columna,
                      int longitud, int& mejorLongitud)
{
	if (posicionValida(laberinto, camino, filas, columnas, fila, columna))
	{
		camino[fila][columna] = 1;
		longitud++;

		if (fila == filas - 1 && columna == columnas - 1)
		{
			if (longitud < mejorLongitud)
			{
				mejorLongitud = longitud;

				for (int i = 0; i < filas; i++)
				{
					for (int j = 0; j < columnas; j++)
					{
						mejorCamino[i][j] = camino[i][j];
					}
				}
			}
		}
		else
		{
			int distancia = (filas - 1 - fila) + (columnas - 1 - columna);
			int limite = longitud + distancia;

			if (limite < mejorLongitud)
			{
				ramificacionPoda(laberinto, camino, mejorCamino,
				                 filas, columnas, fila + 1, columna,
				                 longitud, mejorLongitud);

				ramificacionPoda(laberinto, camino, mejorCamino,
				                 filas, columnas, fila, columna + 1,
				                 longitud, mejorLongitud);

				ramificacionPoda(laberinto, camino, mejorCamino,
				                 filas, columnas, fila - 1, columna,
				                 longitud, mejorLongitud);

				ramificacionPoda(laberinto, camino, mejorCamino,
				                 filas, columnas, fila, columna - 1,
				                 longitud, mejorLongitud);
			}
		}

		camino[fila][columna] = 0;
	}

}

/*
 * Crea una matriz dinamica inicializada en cero.
 * Parametros:
 * filas: Numero de filas.
 * columnas: Numero de columnas.
 * Retorno:
 * Matriz creada.
 * Complejidad: O(M*N).
 */
int** crearMatriz(int filas, int columnas)
{
	int** matriz = new int*[filas];

	for (int i = 0; i < filas; i++)
	{
		matriz[i] = new int[columnas];

		for (int j = 0; j < columnas; j++)
		{
			matriz[i][j] = 0;
		}
	}

	return matriz;
}

/*
 * Muestra una matriz.
 * Parametros:
 * matriz: Matriz a mostrar.
 * filas: Numero de filas.
 * columnas: Numero de columnas.
 * Retorno: Nada
 * Complejidad: O(M*N).
 */
void mostrarMatriz(int** matriz, int filas, int columnas)
{
	for (int i = 0; i < filas; i++)
	{
		for (int j = 0; j < columnas; j++)
		{
			cout << matriz[i][j];

			if (j < columnas - 1)
			{
				cout << " ";
			}
		}
		cout << endl;
	}
}

/*
 * Libera la memoria de una matriz dinamica.
 * Parametros:
 * matriz: Matriz que se desea liberar.
 * filas: Numero de filas.
 * Retorno: Nada.
 * Complejidad: O(M).
 */
void eliminarMatriz(int** matriz, int filas)
{
	for (int i = 0; i < filas; i++)
	{
		delete[] matriz[i];
	}
	delete[] matriz;
}

/*
 * Lee el laberinto, ejecuta ambas tecnicas y muestra los resultados.
 * Retorno:
 * 0 si el programa termina correctamente.
 * Complejidad: O(M*N*4^(M*N)) en el peor caso.
 */
int main()
{
	int filas = 0;
	int columnas = 0;
	cin >> filas;
	cin >> columnas;
	int** laberinto = crearMatriz(filas, columnas);
	int** caminoBacktracking = crearMatriz(filas, columnas);
	int** caminoActual = crearMatriz(filas, columnas);
	int** mejorCamino = crearMatriz(filas, columnas);
	for (int i = 0; i < filas; i++)
	{
		for (int j = 0; j < columnas; j++)
		{
			cin >> laberinto[i][j];
		}
	}
	backtracking(laberinto, caminoBacktracking, filas, columnas, 0, 0);
	int mejorLongitud = filas * columnas + 1;
	ramificacionPoda(laberinto, caminoActual, mejorCamino,
	                 filas, columnas, 0, 0, 0, mejorLongitud);
	mostrarMatriz(caminoBacktracking, filas, columnas);
	cout << endl;
	mostrarMatriz(mejorCamino, filas, columnas);
	eliminarMatriz(laberinto, filas);
	eliminarMatriz(caminoBacktracking, filas);
	eliminarMatriz(caminoActual, filas);
	eliminarMatriz(mejorCamino, filas);
	return 0;
}