#include <iostream>
#include <vector>
#include <queue>
#include <cstdlib>

using namespace std;

static int M, N;
static vector<vector<int> > lab;

// Movimientos: abajo, derecha, arriba, izquierda
static const int dr[4] = {1, 0, -1, 0};
static const int dc[4] = {0, 1, 0, -1};

bool dentro(int r, int c) {
    return r >= 0 && r < M && c >= 0 && c < N;
}

void imprimir(const vector<vector<int> >& m) {
    for (int i = 0; i < M; i++) {
        for (int j = 0; j < N; j++) {
            cout << m[i][j];
            if (j + 1 < N) cout << ' ';
        }
        cout << '\n';
    }
}

// ---------------- Backtracking ----------------
// Explora en profundidad marcando la casilla actual; si ninguna direccion
// conduce a la meta se deshace la marca (backtrack) y se prueba otra rama.
bool backtracking(int r, int c, vector<vector<int> >& sol) {
    if (!dentro(r, c) || lab[r][c] == 0 || sol[r][c] == 1) return false;

    sol[r][c] = 1;
    if (r == M - 1 && c == N - 1) return true;

    for (int k = 0; k < 4; k++) {
        if (backtracking(r + dr[k], c + dc[k], sol)) return true;
    }

    sol[r][c] = 0; // se deshace la decision
    return false;
}

// ------------- Ramificacion y poda -------------
struct Nodo {
    int r, c;      // posicion
    int g;         // costo acumulado (pasos desde el origen)
    int f;         // cota inferior: g + distancia Manhattan a la meta
    bool operator<(const Nodo& o) const { return f > o.f; } // menor f = mayor prioridad
};

int cotaInferior(int r, int c, int g) {
    return g + (M - 1 - r) + (N - 1 - c);
}

bool ramificacionYPoda(vector<vector<int> >& sol) {
    if (lab[0][0] == 0) return false;

    const int INF = 1 << 30;
    vector<vector<int> > mejorG(M, vector<int>(N, INF));
    vector<vector<int> > padre(M, vector<int>(N, -1));

    priority_queue<Nodo> pq;
    Nodo ini;
    ini.r = 0; ini.c = 0; ini.g = 0; ini.f = cotaInferior(0, 0, 0);
    mejorG[0][0] = 0;
    pq.push(ini);

    int mejorSolucion = INF; // cota superior conocida

    while (!pq.empty()) {
        Nodo n = pq.top();
        pq.pop();

        // Poda: la cota inferior del nodo no mejora la mejor solucion hallada
        if (n.f >= mejorSolucion) continue;
        if (n.g > mejorG[n.r][n.c]) continue;

        if (n.r == M - 1 && n.c == N - 1) {
            mejorSolucion = n.g;
            continue;
        }

        for (int k = 0; k < 4; k++) {
            int nr = n.r + dr[k], nc = n.c + dc[k];
            if (!dentro(nr, nc) || lab[nr][nc] == 0) continue;

            int ng = n.g + 1;
            if (ng >= mejorG[nr][nc]) continue; // ya existe una rama igual o mejor

            int nf = cotaInferior(nr, nc, ng);
            if (nf >= mejorSolucion) continue;  // poda por cota

            mejorG[nr][nc] = ng;
            padre[nr][nc] = k;
            Nodo s;
            s.r = nr; s.c = nc; s.g = ng; s.f = nf;
            pq.push(s);
        }
    }

    if (mejorSolucion == INF) return false;

    // Reconstruccion del camino desde la meta usando la direccion almacenada
    int r = M - 1, c = N - 1;
    sol[r][c] = 1;
    while (!(r == 0 && c == 0)) {
        int k = padre[r][c];
        r -= dr[k];
        c -= dc[k];
        sol[r][c] = 1;
    }
    return true;
}

int main() {
    if (!(cin >> M >> N)) return 0;
    if (M <= 0 || N <= 0) return 0;

    lab.assign(M, vector<int>(N, 0));
    for (int i = 0; i < M; i++)
        for (int j = 0; j < N; j++)
            cin >> lab[i][j];

    vector<vector<int> > solBT(M, vector<int>(N, 0));
    backtracking(0, 0, solBT);
    imprimir(solBT);

    cout << '\n';

    vector<vector<int> > solRP(M, vector<int>(N, 0));
    ramificacionYPoda(solRP);
    imprimir(solRP);

    return 0;
}
