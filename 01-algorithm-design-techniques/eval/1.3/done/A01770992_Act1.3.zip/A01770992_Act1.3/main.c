#include <stdio.h>

#define MAX 50

int M, N;
int maze[MAX][MAX];      // laberinto 1 = libre 0 = pared
int visitado[MAX][MAX];  // celdas ya usadas en el intento actual
int camino[MAX][MAX];    // camino que se va construyendo
int mejor[MAX][MAX];     // mejor camino encontrado
int mejorLargo;          // largo del mejor camino

int dx[4] = {1, 0, -1, 0};   // abajo, derecha, arriba, izquierda
int dy[4] = {0, 1, 0, -1};

int esValido(int x, int y) {
    return x >= 0 && x < M && y >= 0 && y < N &&
           maze[x][y] == 1 && !visitado[x][y];
}

// Backtracking
// Se detiene en cuanto encuentra una solucion
int backtracking(int x, int y) {
    if (!esValido(x, y)) return 0;

    visitado[x][y] = 1;
    camino[x][y] = 1;

    if (x == M - 1 && y == N - 1) return 1;

    for (int i = 0; i < 4; i++) {
        if (backtracking(x + dx[i], y + dy[i])) return 1;
    }

    camino[x][y] = 0;
    visitado[x][y] = 0;
    return 0;
}

// Ramificacion y poda
// Explora todas las rutas pero corta una rama en cuanto es imposible que sea mas corta que la mejor ya encontrada
void ramificarYPodar(int x, int y, int largo) {
    if (!esValido(x, y)) return;

    int distMin = (M - 1 - x) + (N - 1 - y);   // lo minimo que falta
    if (largo + 1 + distMin >= mejorLargo) return; // poda no puede mejorar

    visitado[x][y] = 1;
    camino[x][y] = 1;
    largo++;

    if (x == M - 1 && y == N - 1) {
        if (largo < mejorLargo) {
            mejorLargo = largo;
            for (int i = 0; i < M; i++)
                for (int j = 0; j < N; j++)
                    mejor[i][j] = camino[i][j];
        }
    } else {
        for (int i = 0; i < 4; i++)
            ramificarYPodar(x + dx[i], y + dy[i], largo);
    }

    camino[x][y] = 0;
    visitado[x][y] = 0;
}

void imprimir(int m[MAX][MAX]) {
    for (int i = 0; i < M; i++) {
        for (int j = 0; j < N; j++)
            printf(j < N - 1 ? "%d " : "%d\n", m[i][j]);
    }
}

int main(void) {


    scanf("%d %d", &M, &N);
    for (int i = 0; i < M; i++)
        for (int j = 0; j < N; j++)
            scanf("%d", &maze[i][j]);

    // backtracking
    backtracking(0, 0);
    imprimir(camino);


    // ramificacion y poda
    for (int i = 0; i < M; i++)
        for (int j = 0; j < N; j++) { visitado[i][j] = 0; camino[i][j] = 0; }
    mejorLargo = M * N + 1;
    ramificarYPodar(0, 0, 0);
    imprimir(mejor);

    return 0;
}
