# Natalia Sosa Torres, A01770703
# Fecha: 31/08/2026


LIBRE = 1
BLOQUEADA = 0
VISITADA = 1
NO_VISITADA = 0


# Pide al usuario el tamano del laberinto y su contenido.
# Complejidad computacional: O(M * N), se lee cada casilla una vez.
def leerLaberinto():
    print("Ingresa el numero de filas (M):")
    numeroFilas = int(input())

    print("Ingresa el numero de columnas (N):")
    numeroColumnas = int(input())

    print("Ingresa el laberinto.")
    print("Usa 1 para una casilla por donde se puede pasar.")
    print("Usa 0 para una casilla por donde NO se puede pasar.")
    print("Ingresa una fila por linea, separando los valores con espacios.")
    print("(Tambien se acepta una fila sin espacios, ejemplo: 1000).")

    laberinto = []

    for i in range(numeroFilas):
        print("Fila", i + 1, ":")
        linea = input().strip()

        if " " in linea:
            fila = list(map(int, linea.split()))
        else:
            fila = list(map(int, list(linea)))

        laberinto.append(fila)

    return laberinto, numeroFilas, numeroColumnas


# Complejidad computacional: O(M * N).
def imprimirSolucion(solucion, numeroFilas):
    for i in range(numeroFilas):
        print(*solucion[i])


#Intenta encontrar, con backtracking, un camino desde la
#casilla (fila, columna) hasta la ultima casilla del laberinto. P
def backtracking(laberinto, solucion, numeroFilas, numeroColumnas, fila, columna):
    if fila < 0 or fila >= numeroFilas or columna < 0 or columna >= numeroColumnas:
        return False

    if laberinto[fila][columna] == BLOQUEADA:
        return False

    if solucion[fila][columna] == VISITADA:
        return False

    solucion[fila][columna] = VISITADA

    print("Se visita la casilla (fila", fila + 1, ", columna", columna + 1, "):")
    imprimirSolucion(solucion, numeroFilas)
    print()

    if fila == numeroFilas - 1 and columna == numeroColumnas - 1:
        print("Se llego a la casilla final. Camino encontrado.")
        print()
        return True

    if backtracking(laberinto, solucion, numeroFilas, numeroColumnas, fila + 1, columna):
        return True

    if backtracking(laberinto, solucion, numeroFilas, numeroColumnas, fila - 1, columna):
        return True

    if backtracking(laberinto, solucion, numeroFilas, numeroColumnas, fila, columna + 1):
        return True

    if backtracking(laberinto, solucion, numeroFilas, numeroColumnas, fila, columna - 1):
        return True

    solucion[fila][columna] = NO_VISITADA

    print("Sin salida en (fila", fila + 1, ", columna", columna + 1, "), se regresa:")
    imprimirSolucion(solucion, numeroFilas)
    print()

    return False


def main():
    laberinto, numeroFilas, numeroColumnas = leerLaberinto()

    solucion = []

    for i in range(numeroFilas):
        fila = []

        for j in range(numeroColumnas):
            fila.append(NO_VISITADA)

        solucion.append(fila)

    print("Comienza la busqueda del camino:")
    print()

    backtracking(laberinto, solucion, numeroFilas, numeroColumnas, 0, 0)

    print("Matriz solucion final:")
    imprimirSolucion(solucion, numeroFilas)


main()