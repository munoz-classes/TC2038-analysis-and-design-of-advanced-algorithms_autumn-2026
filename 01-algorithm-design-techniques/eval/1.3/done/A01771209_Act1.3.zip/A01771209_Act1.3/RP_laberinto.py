"""
Enfoque: Ramificacion y poda
Resolver un laberinto representado por una matriz binaria,
se busca ir de la posicion (0,0) hasta (m-1, n-1)

Complejidad: O(m*n log(m*n))
    m = numero de filas; n = numero de columnas

31/08/26
"""

def distancia_manhattan(r, c, m, n):
    return (m - 1 - r) + (n - 1 - c)

def resolver_ramificacion_y_poda(m, n, laberinto):
    # matriz de distancias minimas iniciada en infinito
    infinito = 10**9
    dist_minima = [[infinito] * n for _ in range(m)]
    dist_minima[0][0] = 0

    # lista ordenada manualmente como cola de prioridad: (prioridad_f, costo_g, r, c, camino)
    h0 = distancia_manhattan(0, 0, m, n)
    lista_prioridad = [[h0, 0, 0, 0, [(0, 0)]]]

    mejor_costo_global = infinito
    mejor_camino = []

    dr = [1, 0, -1, 0]
    dc = [0, 1, 0, -1]

    while len(lista_prioridad) > 0:
        # extraer el elemento con menor prioridad_f
        lista_prioridad.sort(key=lambda x: x[0])
        f, g, r, c, camino = lista_prioridad.pop(0)

        # poda 1: si la estimacion supera el mejor costo ya encontrado
        if f >= mejor_costo_global:
            continue

        # llegada a la meta
        if r == m - 1 and c == n - 1:
            if g < mejor_costo_global:
                mejor_costo_global = g
                mejor_camino = camino
            continue

        for i in range(4):
            nr = r + dr[i]
            nc = c + dc[i]

            if 0 <= nr < m and 0 <= nc < n and laberinto[nr][nc] == 1:
                nuevo_g = g + 1

                # poda 2: si se encuentra una ruta de menor costo a la casilla (nr, nc)
                if nuevo_g < dist_minima[nr][nc]:
                    dist_minima[nr][nc] = nuevo_g
                    h = distancia_manhattan(nr, nc, m, n)
                    nuevo_f = nuevo_g + h
                    nuevo_camino = camino + [(nr, nc)]
                    lista_prioridad.append([nuevo_f, nuevo_g, nr, nc, nuevo_camino])

    # construir matriz, solucion con el mejor camino
    solucion = [[0] * n for _ in range(m)]
    for r, c in mejor_camino:
        solucion[r][c] = 1

    return solucion

def imprimir_matriz(matriz):
    for fila in matriz:
        print(*(fila))


# Casos prueba
# Caso 1: Laberinto estandar de 4x4
m1, n1 = 4, 4
laberinto1 = [
    [1, 0, 0, 0],
    [1, 1, 0, 1],
    [0, 1, 0, 0],
    [1, 1, 1, 1]
]
res1 = resolver_ramificacion_y_poda(m1, n1, laberinto1)
print(f"Caso 1 | Dimensiones: {m1}x{n1}")
print("Resultado Ramificacion y Poda:")
imprimir_matriz(res1)


# Caso 2: Camino directo en forma de L
m2, n2 = 3, 3
laberinto2 = [
    [1, 1, 1],
    [0, 0, 1],
    [0, 0, 1]
]
res2 = resolver_ramificacion_y_poda(m2, n2, laberinto2)
print(f"Caso 2 | Dimensiones: {m2}x{n2}")
print("Resultado Ramificacion y Poda:")
imprimir_matriz(res2)

# Caso 3: Laberinto totalmente abierto (muestra el camino mas corto)
m3, n3 = 3, 3
laberinto3 = [
    [1, 1, 1],
    [1, 1, 1],
    [1, 1, 1]
]
res3 = resolver_ramificacion_y_poda(m3, n3, laberinto3)
print(f"Caso 3 | Dimensiones: {m3}x{n3}")
print("Resultado Ramificacion y Poda:")
imprimir_matriz(res3)

# Caso 4: Laberinto sin salida disponible
m4, n4 = 3, 3
laberinto4 = [
    [1, 0, 0],
    [0, 1, 0],
    [0, 0, 1]
]
res4 = resolver_ramificacion_y_poda(m4, n4, laberinto4)
print(f"Caso 4 | Dimensiones: {m4}x{n4}")
print("Resultado Ramificacion y Poda:")
imprimir_matriz(res4)