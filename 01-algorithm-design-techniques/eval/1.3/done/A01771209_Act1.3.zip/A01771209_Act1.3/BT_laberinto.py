"""
Enfoque: Backtracking
Resolver un laberinto representado por una matriz binaria,
se busca ir de la posicion (0,0) hasta (m-1, n-1)

Complejidad: O(4^(m*n))
    m = numero de filas; n = numero de columnas

31/08/26
"""

def es_valido(r, c, m, n, laberinto, solucion):
    return 0 <= r < m and 0 <= c < n and laberinto[r][c] == 1 and solucion[r][c] == 0

def resolver_backtracking(r, c, m, n, laberinto, solucion):
    # caso base: llegar a la casilla final
    if r == m - 1 and c == n - 1:
        solucion[r][c] = 1
        return True

    if es_valido(r, c, m, n, laberinto, solucion):
        solucion[r][c] = 1 #marcar paso en el camino

        # movimientos: abajo, derecha, arriba, izquierda
        dr = [1, 0, -1, 0]
        dc = [0, 1, 0, -1]

        for i in range(4):
            nr = r + dr[i]
            nc = c + dc[i]
            if resolver_backtracking(nr, nc, m, n, laberinto, solucion):
                return True

        solucion[r][c] = 0 # desmarcar si no lleva a la salida (backtrack)

    return False

def resolver_laberinto_bt(m, n, laberinto):
    solucion = [[0] * n for _ in range(m)]
    resolver_backtracking(0, 0, m, n, laberinto, solucion)
    return solucion

def imprimir_matriz(matriz):
    for fila in matriz:
        print(*(fila))


# Casos prueba
# Caso 1: Laberinto estandar de 4x4
m1, n1 = 4, 4
laberinto1 = [
    [1, 0, 0, 0],
    [1, 1, 0, 1],
    [0, 1, 0, 0],
    [1, 1, 1, 1]
]
res1 = resolver_laberinto_bt(m1, n1, laberinto1)
print(f"Caso 1 | Dimensiones: {m1}x{n1}")
print("Resultado Backtracking:")
imprimir_matriz(res1)

# Caso 2: Camino directo en forma de L
m2, n2 = 3, 3
laberinto2 = [
    [1, 1, 1],
    [0, 0, 1],
    [0, 0, 1]
]
res2 = resolver_laberinto_bt(m2, n2, laberinto2)
print(f"Caso 2 | Dimensiones: {m2}x{n2}")
print("Resultado Backtracking:")
imprimir_matriz(res2)

# Caso 3: Laberinto totalmente abierto
m3, n3 = 3, 3
laberinto3 = [
    [1, 1, 1],
    [1, 1, 1],
    [1, 1, 1]
]
res3 = resolver_laberinto_bt(m3, n3, laberinto3)
print(f"Caso 3 | Dimensiones: {m3}x{n3}")
print("Resultado Backtracking:")
imprimir_matriz(res3)

# Caso 4: Laberinto sin salida disponible
m4, n4 = 3, 3
laberinto4 = [
    [1, 0, 0],
    [0, 1, 0],
    [0, 0, 1]
]
res4 = resolver_laberinto_bt(m4, n4, laberinto4)
print(f"Caso 4 | Dimensiones: {m4}x{n4}")
print("Resultado Backtracking:")
imprimir_matriz(res4)