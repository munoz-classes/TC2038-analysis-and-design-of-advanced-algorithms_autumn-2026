#ifndef PODA_H
#define PODA_H

#include "config.h"

// avanzamos casilla por casilla sin repetir ninguna hasta llegar a la
// salida. como nunca repetimos una casilla, el camino que encontramos
// es el mas corto
// O(M*N)
bool poda(int laberinto[MAXN][MAXN], int camino[MAXN][MAXN], int m, int n) {
	if (laberinto[0][0] == 0) {
		return false;
	}

	bool visitado[MAXN][MAXN];
	int padreFila[MAXN][MAXN];
	int padreCol[MAXN][MAXN];

	int fi = 0;
	while (fi < m) {
		int ci = 0;
		while (ci < n) {
			visitado[fi][ci] = false;
			padreFila[fi][ci] = -1;
			padreCol[fi][ci] = -1;
			ci = ci + 1;
		}
		fi = fi + 1;
	}

	int colaFila[MAXCOLA];
	int colaCol[MAXCOLA];
	int frente = 0;
	int final = 0;

	colaFila[final] = 0;
	colaCol[final] = 0;
	final = final + 1;
	visitado[0][0] = true;

	while (frente < final) {
		int fila = colaFila[frente];
		int col = colaCol[frente];
		frente = frente + 1;

		if (fila == m - 1) {
			if (col == n - 1) {
				break;
			}
		}

		// probamos ir a la derecha
		if (col + 1 < n) {
			if (laberinto[fila][col + 1] == 1) {
				if (visitado[fila][col + 1] == false) {
					visitado[fila][col + 1] = true;
					padreFila[fila][col + 1] = fila;
					padreCol[fila][col + 1] = col;
					colaFila[final] = fila;
					colaCol[final] = col + 1;
					final = final + 1;
				}
			}
		}
		// probamos ir hacia abajo
		if (fila + 1 < m) {
			if (laberinto[fila + 1][col] == 1) {
				if (visitado[fila + 1][col] == false) {
					visitado[fila + 1][col] = true;
					padreFila[fila + 1][col] = fila;
					padreCol[fila + 1][col] = col;
					colaFila[final] = fila + 1;
					colaCol[final] = col;
					final = final + 1;
				}
			}
		}
		// probamos ir a la izquierda
		if (col - 1 >= 0) {
			if (laberinto[fila][col - 1] == 1) {
				if (visitado[fila][col - 1] == false) {
					visitado[fila][col - 1] = true;
					padreFila[fila][col - 1] = fila;
					padreCol[fila][col - 1] = col;
					colaFila[final] = fila;
					colaCol[final] = col - 1;
					final = final + 1;
				}
			}
		}
		// probamos ir hacia arriba
		if (fila - 1 >= 0) {
			if (laberinto[fila - 1][col] == 1) {
				if (visitado[fila - 1][col] == false) {
					visitado[fila - 1][col] = true;
					padreFila[fila - 1][col] = fila;
					padreCol[fila - 1][col] = col;
					colaFila[final] = fila - 1;
					colaCol[final] = col;
					final = final + 1;
				}
			}
		}
	}

	if (visitado[m - 1][n - 1] == false) {
		return false;
	}

	// desde la salida vamos regresando por los padres hasta el inicio
	int fila = m - 1;
	int col = n - 1;
	while (fila != -1) {
		camino[fila][col] = 1;
		int pf = padreFila[fila][col];
		int pc = padreCol[fila][col];
		fila = pf;
		col = pc;
	}

	return true;
}

#endif
