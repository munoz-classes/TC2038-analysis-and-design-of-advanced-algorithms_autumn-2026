#ifndef BACKTRACKING_H
#define BACKTRACKING_H

#include "config.h"

// probamos una casilla, si no sirve regresamos y probamos otra
// O(4^(M*N)) en el peor caso
bool backtracking(int laberinto[MAXN][MAXN], int camino[MAXN][MAXN], bool visitado[MAXN][MAXN], int fila, int col, int m, int n) {
	if (fila < 0) {
		return false;
	}
	if (fila >= m) {
		return false;
	}
	if (col < 0) {
		return false;
	}
	if (col >= n) {
		return false;
	}
	if (laberinto[fila][col] == 0) {
		return false;
	}
	if (visitado[fila][col] == true) {
		return false;
	}

	visitado[fila][col] = true;
	camino[fila][col] = 1;

	// si ya llegamos a la salida terminamos
	if (fila == m - 1) {
		if (col == n - 1) {
			return true;
		}
	}

	bool encontro = false;

	if (encontro == false) {
		encontro = backtracking(laberinto, camino, visitado, fila, col + 1, m, n);
	}
	if (encontro == false) {
		encontro = backtracking(laberinto, camino, visitado, fila + 1, col, m, n);
	}
	if (encontro == false) {
		encontro = backtracking(laberinto, camino, visitado, fila, col - 1, m, n);
	}
	if (encontro == false) {
		encontro = backtracking(laberinto, camino, visitado, fila - 1, col, m, n);
	}

	// si no funciono ninguna direccion quitamos la marca
	if (encontro == false) {
		camino[fila][col] = 0;
		visitado[fila][col] = false;
	}

	return encontro;
}

#endif
