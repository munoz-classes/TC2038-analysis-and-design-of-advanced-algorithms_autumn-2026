#ifndef CONFIG_H
#define CONFIG_H

const int MAXN = 100;
const int MAXCOLA = MAXN * MAXN;

#endif
