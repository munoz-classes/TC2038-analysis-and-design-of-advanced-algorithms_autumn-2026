// Laberinto - Backtracking y Ramificacion y Poda
// Ileana Tapia Castillo - A01773374
// 31/08/2026

#include <iostream>
#include "config.h"
#include "backtracking.h"
#include "poda.h"

using namespace std;

int laberinto[MAXN][MAXN];
int caminoBack[MAXN][MAXN];
int caminoPoda[MAXN][MAXN];
bool visitado[MAXN][MAXN];

void imprimir(int camino[MAXN][MAXN], int m, int n) {
	int fila = 0;
	while (fila < m) {
		int col = 0;
		while (col < n) {
			cout << camino[fila][col];
			if (col < n - 1) {
				cout << " ";
			}
			col = col + 1;
		}
		cout << endl;
		fila = fila + 1;
	}
}

int main() {
	// leemos el tamaño del laberinto y sus casillas
	int m;
	int n;
	cin >> m;
	cin >> n;

	int fila = 0;
	while (fila < m) {
		int col = 0;
		while (col < n) {
			cin >> laberinto[fila][col];
			caminoBack[fila][col] = 0;
			caminoPoda[fila][col] = 0;
			visitado[fila][col] = false;
			col = col + 1;
		}
		fila = fila + 1;
	}

	backtracking(laberinto, caminoBack, visitado, 0, 0, m, n);
	poda(laberinto, caminoPoda, m, n);

	imprimir(caminoBack, m, n);
	imprimir(caminoPoda, m, n);

	return 0;
}
