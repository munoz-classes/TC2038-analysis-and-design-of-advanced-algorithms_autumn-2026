#include <iostream>
#include <vector>
#include <climits>

struct Punto {
    int x, y;
};

const Punto DIRECCIONES[4] = {
    {1, 0}, {0, 1}, {-1, 0}, {0, -1}
};
// O(M*N)
static void imprimirmat(int* sol, int M, int N) {
    for (int i = 0; i < M; ++i) {
        for (int j = 0; j < N; ++j) {
            std::cout << sol[i * N + j] << " ";
        }
        std::cout << "\n";
    }
}
std::vector<std::vector<int>> laberinto;
std::vector<std::vector<bool>> visitado;
// O(4^(M*N))
static bool backtrack(Punto p, int* sol, int M, int N) {
    int x = p.x, y = p.y;

    if (x == M - 1 && y == N - 1) {
        sol[x * N + y] = 1;
        return true;
    }

    visitado[x][y] = true;
    sol[x * N + y] = 1;

    for (int d = 0; d < 4; ++d) {
        int nx = x + DIRECCIONES[d].x;
        int ny = y + DIRECCIONES[d].y;

        if (nx >= 0 && nx < M && ny >= 0 && ny < N &&
            laberinto[nx][ny] == 1 && !visitado[nx][ny]) {

            if (backtrack({ nx, ny }, sol, M, N)) {
                return true;
            }
        }
    }

    sol[x * N + y] = 0;
    visitado[x][y] = false;
    return false;
}
int mjrlongitud;
std::vector<Punto> mjrcmn;
std::vector<Punto> cmnact;
// O(4^(M*N))
static void ramypod(Punto p, int pasos, int M, int N) {
    int x = p.x, y = p.y;

    if (pasos >= mjrlongitud) return;

    if (x == M - 1 && y == N - 1) {
        mjrcmn = cmnact;
        mjrcmn.push_back(p);
        mjrlongitud = pasos;
        return;
    }

    visitado[x][y] = true;
    cmnact.push_back(p);

    for (int d = 0; d < 4; ++d) {
        int nx = x + DIRECCIONES[d].x;
        int ny = y + DIRECCIONES[d].y;

        if (nx >= 0 && nx < M && ny >= 0 && ny < N &&
            laberinto[nx][ny] == 1 && !visitado[nx][ny]) {

            ramypod({ nx, ny }, pasos + 1, M, N);
        }
    }

    cmnact.pop_back();
    visitado[x][y] = false;
}

int main() {
    int M, N;
    std::cin >> M >> N;

    

    laberinto.assign(M, std::vector<int>(N));
    // O(M*N)
    for (int i = 0; i < M; ++i) {
        for (int j = 0; j < N; ++j) {
            std::cin >> laberinto[i][j];
        }
    }
    std::cout << "\n";

    visitado.assign(M, std::vector<bool>(N, false));
    int* solBacktrack = new int[M * N]();

    if (backtrack({ 0, 0 }, solBacktrack, M, N)) {
        imprimirmat(solBacktrack, M, N);
        std::cout << "\n";
    }
    else {
        std::cout << "No hay soluci�n\n";
        delete[] solBacktrack;
        return 0;
    }


    

    visitado.assign(M, std::vector<bool>(N, false));
    mjrlongitud = INT_MAX;
    mjrcmn.clear();
    cmnact.clear();

    ramypod({ 0, 0 }, 1, M, N);

    if (mjrlongitud != INT_MAX) {
        int* solRamypod = new int[M * N]();
        // O(M*N)
        for (Punto p : mjrcmn) {
            solRamypod[p.x * N + p.y] = 1;
        }
        imprimirmat(solRamypod, M, N);
        delete[] solRamypod;
    }
    else {
        std::cout << "No hay soluci�n\n";
    }

    delete[] solBacktrack;
    return 0;
}