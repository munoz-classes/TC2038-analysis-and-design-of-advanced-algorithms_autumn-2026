/*
Solucionador de laberintos: encuentra un camino de la entrada a la salida.
Lee dos enteros M y N (filas y columnas), seguidos de M lineas con N valores
booleanos (ceros y unos): 1 es una casilla transitable, mientras que 0 es una pared.
El origen es siempre la casilla (0,0) y la meta es la casilla (M-1, N-1). Resuelve el 
laberinto con dos tecnicas y muestra ambas soluciones: primero backtracking, y luego
ramificacion y poda. Cada solucion es una matriz en donde 1 marca el camino de salida
y 0 el resto. Si no hay camino, la matriz se imprime llena de ceros.

Autor: Iker Octavio Silva Campos - A01770545
Fecha de creacion: 31 de agosto de 2026

Complejidad computacional: O(M*N), donde M y N son las dimensiones del laberinto.
Cada casilla se visita como máximo una vez gracias al marcado de casillas visitadas,
que evita ciclos. Sin este marcado, la ramificacion en cuatro direcciones seria exponencial
en el peor caso. El marcado la reduce a lineal respecto al numero de casillas.
Esto aplica a ambas tecnicas.
*/

#include <iostream>
#include <vector>

/*
Resuelve el laberinto con backtracking: explora cuatro direcciones desde la casilla actual y,
si un camino no lleva a la salida, retrocede y prueba otro. Marca el camino en la matriz
solucion.
Parametros:
    laberinto: la matriz original con paredes y casillas libres.
    soluicon: la matriz donde se marca con 1 el camino encontrado.
    fila: fila de la casilla actual
    columna: columna de la casilla actual
    m: numero de filas del laberinto
    n: numero de columnas del laberinto
Retorno:
    true si desde la casilla actual se llega a la salida, false si no.
*/

bool backtracking(std::vector<std::vector<int>> & laberinto,
    std::vector<std::vector<int>> & solucion,
    int fila, int columna, int m, int n){
    if (fila < 0 || fila >= m || columna < 0 || columna >= n){
        return false;
    }
    if (laberinto[fila][columna] == 0 || solucion[fila][columna] == 1){
        return false;
    }
    if (fila == m - 1 && columna == n - 1){
        solucion[fila][columna] = 1;
        return true;
    }
    solucion[fila][columna] = 1;
    if (backtracking(laberinto, solucion, fila + 1, columna, m, n)){
        return true;
    }
    if (backtracking(laberinto, solucion, fila, columna + 1, m, n)){
        return true;
    }
    if (backtracking(laberinto, solucion, fila - 1, columna, m, n)){
        return true;
    }
    if (backtracking(laberinto, solucion, fila, columna - 1, m, n)){
        return true;
    }
    solucion[fila][columna] = 0;
    return false;
}

/*
Verifica si una casilla es viable para explorar: dentro de los limites, sin pared y
no visitada. Sirve como poda previa en ramificacion y poda.
Parametros:
    laberinto: matriz original con paredes y casillas libres.
    solucion: matriz con el camino marcado hasta el momento
    fila: fila de la casilla a verificar
    columna: columna de la casilla a verificar
    m: numero de filas del laberinto.
    n: numero de columnas del laberinto.
Retorno: 
    true si la casilla es transitable y no visitada, false si no.
*/

bool esViable(std::vector<std::vector<int>> & laberinto,
    std::vector<std::vector<int>> & solucion,
    int fila, int columna, int m, int n){
    if (fila < 0 || fila >= m || columna < 0 || columna >= n){
        return false;
    }
    if (laberinto[fila][columna] == 0 || solucion[fila][columna] == 1){
        return false;
    }
    return true;
}

/*
Resuelve el laberinto con ramificacion y poda. Igual que backtracking, pero poda cada
direccion con esViable antes de la llamada recursiva, evitando explorar
casillas que no son prometedoras.
Parametros:
    laberinto: matriz original con paredes y casillas libres
    solucion: matriz donde se marca con 1 el camino encontrado.
    fila: fila de la casilla actual
    columna: columna de la casilla actual
    m: numero de filas del laberinto
    n: numero de columnas del laberinto
Retorno:
    true si desde la casilla actual se llega a la salida, false si no
*/

bool ramificacionPoda(std::vector<std::vector<int>> & laberinto,
    std::vector<std::vector<int>> & solucion,
    int fila, int columna, int m, int n){
    if (!esViable(laberinto, solucion, fila, columna, m, n)){
        return false;
    }
    if (fila == m - 1 && columna == n - 1){
        solucion[fila][columna] = 1;
        return true;
    }
    solucion[fila][columna] = 1;
    if (esViable(laberinto, solucion, fila + 1, columna, m, n)){
        if (ramificacionPoda(laberinto, solucion, fila + 1, columna, m, n)){
            return true;
        }
    }
    if (esViable(laberinto, solucion, fila, columna + 1, m, n)){
        if (ramificacionPoda(laberinto, solucion, fila, columna + 1, m, n)){
            return true;
        }
    }
    if (esViable(laberinto, solucion, fila - 1, columna, m, n)){
        if (ramificacionPoda(laberinto, solucion, fila - 1, columna, m, n)){
            return true;
        }
    }
    if (esViable(laberinto, solucion, fila, columna - 1, m, n)){
        if (ramificacionPoda(laberinto, solucion, fila, columna - 1, m, n)){
            return true;
        }
    }
    solucion[fila][columna] = 0;
    return false;
    }

/*
Funcion principal: lee el laberinto y muestra el camino de salida con las dos tecnicas,
primero backtracking y luego ramificacion y poda. Estan separadas por una linea
en blanco.
Retorno:
    0 si el programa termina correctamente.
*/

int main() {
    int m = 0;
    int n = 0;
    std::cin >> m;
    std::cin >> n;
    std::vector<std::vector<int>> laberinto(m, std::vector<int>(n));
    for (int i = 0; i < m; i++){
        for (int j = 0; j < n; j++){
            std::cin >> laberinto[i][j];
        }
    }
    std::vector<std::vector<int>> solucionBacktracking(m, std::vector<int>(n, 0));
    backtracking(laberinto, solucionBacktracking, 0, 0, m, n);
    for (int i = 0; i < m; i++){
        for (int j = 0; j < n; j++){
            std::cout << solucionBacktracking[i][j] << " ";
        }
        std::cout << std::endl; 
    }
    std::cout << std::endl;
    std::vector<std::vector<int>> solucionPoda(m, std::vector<int>(n, 0));
    ramificacionPoda(laberinto, solucionPoda, 0, 0, m, n);
    for (int i = 0; i < m; i++){
        for (int j = 0; j < n; j++){
            std::cout << solucionPoda[i][j] << " "; 
        }
        std::cout << std::endl;
    }
    return 0;
}

/*
CASOS DE PRUEBA:
Cada diagonal representa un cambio de linea:

Caso 1: (Entrada regular, misma salida con ambos algoritmos):
    Entrada: 4 / 4 / 1 0 0 0 / 1 1 0 1 / 0 1 0 0 / 1 1 1 1
    Salida: 1 0 0 0 / 1 1 0 0 / 0 1 0 0 / 0 1 1 1 / / 1 0 0 0 / 1 1 0 0 / 0 1 0 0 / 0 1 1 1
Caso 2: (Laberinto sin solucion):
    Entrada: 3 / 3 / 1 0 0 / 0 0 0 / 0 0 1
    Salida: 0 0 0 / 0 0 0 / 0 0 0 / / 0 0 0 / 0 0 0 / 0 0 0
    Nota: Se devuelven matrices llenas de ceros, pues están desmarcadas (sin solucion)
Caso 3: (Laberinto minimo):
    Entrada: 1 / 1 / 1
    Salida: 1 / / 1
Caso 4: (Laberinto rectangular):
    Entrada: 2 / 5 / 1 1 1 1 1 / 0 0 0 0 1
    Salida: 1 1 1 1 1 / 0 0 0 0 1 / / 1 1 1 1 1 / 0 0 0 0 1
Caso 5: (Laberinto sin paredes):
    Entrada: 3 / 3 / 1 1 1 / 1 1 1 / 1 1 1
    Salida: 1 0 0 / 1 0 0 / 1 1 1 / / 1 0 0 / 1 0 0 / 1 1 1
    Nota: Los algoritmos tienen libertad de movimiento, pero el primer camino que verifican es hacia abajo, por eso sale esta ruta
*/