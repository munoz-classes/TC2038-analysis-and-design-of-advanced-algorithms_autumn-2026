/*
 * Descripcion: Programa para resolver un laberinto con dos tecnicas:
 *              1. Backtracking (Busqueda en profundidad con retroceso)
 *              2. Ramificacion y Poda (Branch and Bound usando distancia Manhattan)
 * Autor: Jacquelin Velázquez Ramírez - A01773495
 * Fecha: 31/08/2026
 */

#include <iostream>
#include <vector>
#include <queue>
#include <cmath>

using namespace std;

// Estructura para guardar un estado del laberinto en Branch and Bound
struct Nodo {
	int fila;
	int columna;
	int costoG;
	int costoF;
	vector<pair<int, int>> camino;
};

// Comparador para que la cola de prioridad elija el nodo con menor costo estimado (f)
struct CompararNodo {
	bool operator()(const Nodo& a, const Nodo& b) {
		return a.costoF > b.costoF;
	}
};

/*
 * Proposito: Calcula la distancia Manhattan desde una casilla hasta la meta.
 * Parametros:
 *   - fila: fila actual
 *   - columna: columna actual
 *   - filas: total de filas del laberinto (M)
 *   - columnas: total de columnas del laberinto (N)
 * Retorno: Entero con la distancia Manhattan
 * Complejidad de Tiempo: O(1)
 * Complejidad de Espacio: O(1)
 */
int calcularHeuristica(int fila, int columna, int filas, int columnas) {
	return abs((filas - 1) - fila) + abs((columnas - 1) - columna);
}

/*
 * Proposito: Imprime una matriz en consola separando los valores por espacio.
 * Parametros:
 *   - matriz: matriz de ceros y unos
 *   - filas: numero de filas
 *   - columnas: numero de columnas
 * Retorno: void
 * Complejidad de Tiempo: O(M x N)
 * Complejidad de Espacio: O(1)
 */
void imprimirMatriz(const vector<vector<int>>& matriz, int filas, int columnas) {
	for (int i = 0; i < filas; i++) {
		for (int j = 0; j < columnas; j++) {
			cout << matriz[i][j];
			if (j < columnas - 1) {
				cout << " ";
			}
		}
		cout << "\n";
	}
}

/*
 * Proposito: Encuentra un camino en el laberinto usando la tecnica de Backtracking.
 * Parametros:
 *   - laberinto: matriz con los obstaculos (0) y caminos libres (1)
 *   - fila: coordenada actual de fila
 *   - col: coordenada actual de columna
 *   - filas: total de filas (M)
 *   - columnas: total de columnas (N)
 *   - solucion: matriz donde se guarda la ruta final
 *   - visitado: matriz booleana para no ciclarse
 * Retorno: bool indicando si se llego a la meta
 * Complejidad de Tiempo: O(4^(M x N)) en el peor caso
 * Complejidad de Espacio: O(M x N) por la recursion y matriz de visitados
 */
bool resolverBacktracking(const vector<vector<int>>& laberinto, int fila, int col,
                          int filas, int columnas, vector<vector<int>>& solucion,
                          vector<vector<bool>>& visitado) {
	if (fila == filas - 1 && col == columnas - 1 && laberinto[fila][col] == 1) {
		solucion[fila][col] = 1;
		return true;
	}

	bool esCasillaValida = (fila >= 0 && fila < filas &&
	                        col >= 0 && col < columnas &&
	                        laberinto[fila][col] == 1 &&
	                        !visitado[fila][col]);

	if (esCasillaValida) {
		visitado[fila][col] = true;
		solucion[fila][col] = 1;

		int despFila[4] = {1, 0, -1, 0};
		int despCol[4] = {0, 1, 0, -1};
		bool encontroCamino = false;

		for (int i = 0; i < 4 && !encontroCamino; i++) {
			int nuevaFila = fila + despFila[i];
			int nuevaCol = col + despCol[i];
			if (resolverBacktracking(laberinto, nuevaFila, nuevaCol, filas, columnas, solucion, visitado)) {
				encontroCamino = true;
			}
		}

		if (encontroCamino) {
			return true;
		}

		// Si no funciono ninguna direccion, desmarcamos (Backtrack)
		solucion[fila][col] = 0;
	}

	return false;
}

/*
 * Proposito: Resuelve el laberinto usando Ramificacion y Poda con una cola de prioridad.
 * Parametros:
 *   - laberinto: matriz del laberinto
 *   - filas: total de filas (M)
 *   - columnas: total de columnas (N)
 * Retorno: vector<vector<int>> matriz con la solucion encontrada
 * Complejidad de Tiempo: O(M x N x log(M x N))
 * Complejidad de Espacio: O(M x N) para la cola y estados
 */
vector<vector<int>> resolverRamificacionYPoda(const vector<vector<int>>& laberinto, int filas, int columnas) {
	vector<vector<int>> solucion(filas, vector<int>(columnas, 0));

	if (laberinto[0][0] == 0 || laberinto[filas - 1][columnas - 1] == 0) {
		return solucion;
	}

	priority_queue<Nodo, vector<Nodo>, CompararNodo> colaPrioridad;
	vector<vector<int>> menorCosto(filas, vector<int>(columnas, 1000000));

	Nodo inicio;
	inicio.fila = 0;
	inicio.columna = 0;
	inicio.costoG = 0;
	inicio.costoF = calcularHeuristica(0, 0, filas, columnas);
	inicio.camino.push_back({0, 0});

	colaPrioridad.push(inicio);
	menorCosto[0][0] = 0;

	bool metaAlcanzada = false;
	int despFila[4] = {1, 0, -1, 0};
	int despCol[4] = {0, 1, 0, -1};

	while (!colaPrioridad.empty() && !metaAlcanzada) {
		Nodo actual = colaPrioridad.top();
		colaPrioridad.pop();

		if (actual.fila == filas - 1 && actual.columna == columnas - 1) {
			for (size_t i = 0; i < actual.camino.size(); i++) {
				solucion[actual.camino[i].first][actual.camino[i].second] = 1;
			}
			metaAlcanzada = true;
		}

		if (!metaAlcanzada && actual.costoG <= menorCosto[actual.fila][actual.columna]) {
			for (int i = 0; i < 4; i++) {
				int nf = actual.fila + despFila[i];
				int nc = actual.columna + despCol[i];

				if (nf >= 0 && nf < filas && nc >= 0 && nc < columnas && laberinto[nf][nc] == 1) {
					int nuevoG = actual.costoG + 1;
					// Poda: solo continuamos si encontramos un camino mas corto a esa casilla
					if (nuevoG < menorCosto[nf][nc]) {
						menorCosto[nf][nc] = nuevoG;
						Nodo hijo;
						hijo.fila = nf;
						hijo.columna = nc;
						hijo.costoG = nuevoG;
						hijo.costoF = nuevoG + calcularHeuristica(nf, nc, filas, columnas);
						hijo.camino = actual.camino;
						hijo.camino.push_back({nf, nc});
						colaPrioridad.push(hijo);
					}
				}
			}
		}
	}

	return solucion;
}

int main() {
	int filas = 0;
	int columnas = 0;

	if (!(cin >> filas >> columnas)) {
		return 0;
	}

	vector<vector<int>> laberinto(filas, vector<int>(columnas, 0));
	for (int i = 0; i < filas; i++) {
		for (int j = 0; j < columnas; j++) {
			cin >> laberinto[i][j];
		}
	}

	// 1. Ejecucion de Backtracking
	vector<vector<int>> solucionBT(filas, vector<int>(columnas, 0));
	vector<vector<bool>> visitadoBT(filas, vector<bool>(columnas, false));
	if (laberinto[0][0] == 1) {
		resolverBacktracking(laberinto, 0, 0, filas, columnas, solucionBT, visitadoBT);
	}
	imprimirMatriz(solucionBT, filas, columnas);

	cout << "\n";

	// 2. Ejecucion de Ramificacion y Poda
	vector<vector<int>> solucionRP = resolverRamificacionYPoda(laberinto, filas, columnas);
	imprimirMatriz(solucionRP, filas, columnas);

	return 0;
}