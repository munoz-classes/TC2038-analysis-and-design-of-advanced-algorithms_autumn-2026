"""
Resolución de laberinto usando Backtracking (principalmente) y Ramificación y poda

Complejidades:
    Backtracking: O(4^(n*m)), en el peor caso, donde n y m son las dimensiones del laberinto
    Ramificación y poda: O(4^(n*m)) en el peor caso, pero puede ser mucho más eficiente en la 
    práctica debido a la poda de ramas no prometedoras.

La verdad no supe cómo hacer ramificación y poda, por lo que sólo voy a entregar el código de backtracking, que es el que me funcionó.
La idea de ramificación y poda es similar a la de backtracking, siendo la diferencia que se puede ir descartando caminos que 
no son prometedores, que no llevan a una solución óptima. Es una versión mejorada de backtracking.

Casos prueba:

1. Caso 1. Ejemplo de canvas:
4
4
1 0 0 0
1 1 0 1
0 1 0 0
1 1 1 1
    salida:
    1 0 0 0
    1 1 0 0
    0 1 0 0
    0 1 1 1

2. Caso 2. Sin solución:
3
3
1 0 0
0 0 0
0 0 1
    salida:
    0 0 0
    0 0 0
    0 0 0

Caso 3. Caso extremo mínimo
1
1
1
    salida:
    1

Caso 4. Multiples caminos posibles
5
5
1 1 1 1 1
0 0 0 0 1
1 1 1 0 1
1 0 1 0 1
1 0 1 1 1
    salida:
    1 1 1 1 1
    0 0 0 0 1
    0 0 0 0 1
    0 0 0 0 1
    0 0 0 0 1   

Fátima Montserrat Herrera González | A01770839
31/08/26

REFERENCIAS:
- https://manuais.pages.iessanclemente.net/apuntes/2.programacion/kotlin/01_prog_estructurada/015.backtracking/152.backtrakingylaberinto/index.html
- https://www.tutorialesprogramacionya.com/estructurasdedatos/pilaspython/tema12.html
- https://www.geeksforgeeks.org/dsa/rat-in-a-maze-backtracking-using-stack/
"""

def leer_entrada():
    m = int(input())
    n = int(input())

    laberinto = []
    for i in range(m):
        fila = input().split()
        fila = [int(valor) for valor in fila]
        laberinto.append(fila)

    return m, n, laberinto


def es_valido(laberinto, x, y, m, n, visitado):
    return 0 <= x < m and 0 <= y < n and laberinto[x][y] == 1 and not visitado[x][y]


def backtracking_rec(laberinto, x, y, m, n, solucion, visitado, dx, dy):
    if x == m - 1 and y == n - 1 and laberinto[x][y] == 1:
        solucion[x][y] = 1
        return True

    if es_valido(laberinto, x, y, m, n, visitado):
        solucion[x][y] = 1
        visitado[x][y] = True

        for k in range(4):
            if backtracking_rec(laberinto, x + dx[k], y + dy[k], m, n, solucion, visitado, dx, dy):
                return True

        solucion[x][y] = 0
        visitado[x][y] = False

    return False


def backtracking(laberinto, m, n):
   
    solucion = [[0] * n for _ in range(m)]
    visitado = [[False] * n for _ in range(m)]
    dx = [1, 0, -1, 0]
    dy = [0, 1, 0, -1]

    encontrado = backtracking_rec(laberinto, 0, 0, m, n, solucion, visitado, dx, dy)

    if not encontrado:
        return [[0] * n for _ in range(m)]

    return solucion


def imprimir_matriz(matriz):
    for fila in matriz:
        print(" ".join(str(valor) for valor in fila))


def main():
    m, n, laberinto = leer_entrada()

    solucion_backtracking = backtracking(laberinto, m, n)
    imprimir_matriz(solucion_backtracking)


main()