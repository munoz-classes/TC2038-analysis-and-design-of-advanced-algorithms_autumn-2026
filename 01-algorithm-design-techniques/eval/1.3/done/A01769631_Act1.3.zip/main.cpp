/*Actividad 1.3 Implementación de la técnica de programación "backtracking" y "ramificación y poda"
Codigo Escritó por: José Pedro Rodríguez Munguía | A01769631*/

#include <bits/stdc++.h>
using namespace std;

vector<vector<int>> laberinto;
vector<vector<int>> camino;
vector<vector<bool>> visitado;
vector<vector<int>> mejor_camino;

int M, N;
int mejor = -1;


//Técnica de backtracking.
bool backtracking(int fila, int columna) {

    //Revisa que no pase de los limites del laberinto ni que pase por casillas ya visitadas. Si no lo hace, se agrega al camino.
    if (fila < 0 or fila >= M or columna < 0 or columna >= N) {
        return false;
    }
    if (laberinto[fila][columna] == 0 or visitado[fila][columna]) {
        return false;
    }
    visitado[fila][columna] = true;
    camino[fila][columna] = 1;

    //Caso base.
    if (fila == M - 1 and columna == N - 1) {
        return true;
    }

    //Se realizan llamadas recursivas hasta encontrar al caso base o encontrar pared en cada movimiento.
    if (backtracking(fila + 1, columna)) {
        return true;
    }
    if (backtracking(fila, columna + 1)) {
        return true;
    }
    if (backtracking(fila - 1, columna)) {
        return true;
    }
    if (backtracking(fila, columna - 1)) {
        return true;
    }

    //Si topa con pared, se quita esta celda o movimiento posible del camino actual.
    camino[fila][columna] = 0;
    return false;
}

//Técnica de ramificación y poda.
//El codigo es parecido al de backtracking, pero con condición de mejor camino para poder podar caminos que no son óptimos.
bool ramificacionPoda(int fila, int columna, int pasos) {

    if (fila < 0 or fila >= M or columna < 0 or columna >= N) {
        return false;
    }
    if (laberinto[fila][columna] == 0 or visitado[fila][columna]) {
        return false;
    }

    int distancia = abs(fila - (M - 1)) + abs(columna - (N - 1));

    if (mejor != -1 and pasos + distancia >= mejor) {
        return false;
    }

    visitado[fila][columna] = true;
    camino[fila][columna] = 1;

    //Caso base.
    if (fila == M - 1 and columna == N - 1) {
        if (mejor == -1 or pasos < mejor) {
            mejor = pasos;
            mejor_camino = camino;
        }
        return true;
    }

    if (ramificacionPoda(fila + 1, columna, pasos + 1)) {
        return true;
    }
    if (ramificacionPoda(fila, columna + 1, pasos + 1)) {
        return true;
    }
    if (ramificacionPoda(fila - 1, columna, pasos + 1)) {
        return true;
    }
    if (ramificacionPoda(fila, columna - 1, pasos + 1)) {
        return true;
    }

    camino[fila][columna] = 0;
    visitado[fila][columna] = false;
    return false;
}

int main() {
    /*
    Codigo para ejecutar en Windows:

    g++ main.cpp -o main.exe
    cmd /c "main.exe < in.txt"
    */

    /*Orden de las entradas:
    - Cantidad de filas.
    - Cantidad de columnas.
    - Matriz del laberinto, donde 1 es libre y 0 es pared.
    */

    scanf("%d", &M);
    scanf("%d", &N);

    //Se reservan espacios en memoria para la estructura del laberinto, el camino y las casillas.
    laberinto.assign(M, vector<int>(N));
    camino.assign(M, vector<int>(N, 0));
    visitado.assign(M, vector<bool>(N, false));
    mejor_camino.assign(M, vector<int>(N, 0));

    //Lecuta del laberinto fila por fila.
    for (int i = 0; i < M; i++) {
        for (int j = 0; j < N; j++) {
            scanf("%d", &laberinto[i][j]);
        }
    }

    //Se llama a la técnica de backtracking y si encuentra un camino, se imprime este resultado.
    printf("Backtracking:\n");
    if (backtracking(0, 0)) {
        for (int i = 0; i < M; i++) {
            for (int j = 0; j < N; j++) {
                printf("%d ", camino[i][j]);
            }
            printf("\n");
        }
    }

    //Se llama a técnica de ramificación y poda, y si encuentra un camino, se imprime este resultado.
    printf("\nRamificacion y poda:\n");
    for (int i = 0; i < M; i++) {
        for (int j = 0; j < N; j++) {
            visitado[i][j] = false;
            camino[i][j] = 0;
            mejor_camino[i][j] = 0;
        }
    }
    mejor = -1;
    if (ramificacionPoda(0, 0, 0)) {
        for (int i = 0; i < M; i++) {
            for (int j = 0; j < N; j++) {
                printf("%d ", mejor_camino[i][j]);
            }
            printf("\n");
        }
    }

    return 0;
}