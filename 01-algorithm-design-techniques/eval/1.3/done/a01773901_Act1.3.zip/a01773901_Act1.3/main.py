#!/usr/bin/env python3
"""
Resolucion de laberintos mediante:
  1 Backtracking (busqueda en profundidad con retroceso)
  2 Ramificacion y poda (Branch and Bound - mejor-primero con acotamiento)

"""

import sys
import heapq


# Orden de movimientos: abajo, derecha, arriba, izquierda
Movimientos = [(1, 0), (0, 1), (-1, 0), (0, -1)]


def leer_entrada():
    datos = sys.stdin.read().split()
    idx = 0
    m = int(datos[idx]); idx += 1
    n = int(datos[idx]); idx += 1
    laberinto = []
    for i in range(m):
        fila = []
        for j in range(n):
            fila.append(int(datos[idx])); idx += 1
        laberinto.append(fila)
    return m, n, laberinto


def imprimir_matriz(matriz):
    if matriz is None:
        print("No hay solucion")
        return
    for fila in matriz:
        print(" ".join(str(v) for v in fila))

def resolver_backtracking(laberinto, m, n):
    visitado = [[False] * n for _ in range(m)]
    camino = [[0] * n for _ in range(m)]

    def es_valida(x, y):
        return (0 <= x < m and 0 <= y < n
                and laberinto[x][y] == 1 and not visitado[x][y])

    def backtrack(x, y):
        if not es_valida(x, y):
            return False

        visitado[x][y] = True
        camino[x][y] = 1

        if (x, y) == (m - 1, n - 1):
            return True

        for dx, dy in Movimientos:
            if backtrack(x + dx, y + dy):
                return True

        camino[x][y] = 0
        return False

    if backtrack(0, 0):
        return camino
    return None

def resolver_ramificacion_y_poda(laberinto, m, n):
    if laberinto[0][0] == 0:
        return None

    meta = (m - 1, n - 1)

    def heuristica(x, y):
        return abs(meta[0] - x) + abs(meta[1] - y)

    mejor_longitud = float("inf")
    mejor_camino = None

    contador = 0  # desempate estable para heapq
    frontera = []
    inicio = (0, 0)
    cota_inicial = 1 + heuristica(*inicio)
    heapq.heappush(frontera, (cota_inicial, 1, contador, [inicio], frozenset([inicio])))

    while frontera:
        cota, longitud, _, camino, visitados = heapq.heappop(frontera)
        x, y = camino[-1]

        if cota >= mejor_longitud:
            continue

        if (x, y) == meta:
            mejor_longitud = longitud
            mejor_camino = camino
            continue

        # Ramificacion: se generan los hijos validos del nodo actual
        for dx, dy in Movimientos:
            nx, ny = x + dx, y + dy
            if (0 <= nx < m and 0 <= ny < n
                    and laberinto[nx][ny] == 1
                    and (nx, ny) not in visitados):
                nueva_longitud = longitud + 1
                nueva_cota = nueva_longitud + heuristica(nx, ny)
                
                if nueva_cota < mejor_longitud:
                    contador += 1
                    nuevo_camino = camino + [(nx, ny)]
                    nuevos_visitados = visitados | {(nx, ny)}
                    heapq.heappush(
                        frontera,
                        (nueva_cota, nueva_longitud, contador,
                         nuevo_camino, nuevos_visitados)
                    )

    if mejor_camino is None:
        return None

    resultado = [[0] * n for _ in range(m)]
    for (x, y) in mejor_camino:
        resultado[x][y] = 1
    return resultado


def main():
    m, n, laberinto = leer_entrada()

    solucion_backtracking = resolver_backtracking(laberinto, m, n)
    imprimir_matriz(solucion_backtracking)

    print()

    solucion_ramificacion = resolver_ramificacion_y_poda(laberinto, m, n)
    imprimir_matriz(solucion_ramificacion)


if __name__ == "__main__":
    main()
