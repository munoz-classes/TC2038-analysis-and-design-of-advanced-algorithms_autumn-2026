"""
Programa que resuelve un laberinto utilizando dos tecnicas distintas:
backtracking y ramificacion y poda (busqueda tipo A*).
Autor: Jose Angel Vargas Carranza, A01773311
Fecha: 31/08/2026
"""

import sys
import heapq


NO_TRANSITABLE = 0
TRANSITABLE = 1


def leerLaberinto():
    """
    Lee de la entrada estandar el numero de filas, el numero de columnas
    y el contenido del laberinto.

    Parametros:
        Ninguno.

    Retorno:
        Una tupla (filas, columnas, laberinto), donde laberinto es una
        lista de listas de enteros (0 o 1).
    """
    datos = sys.stdin.read().split()
    indiceDato = 0
    filas = int(datos[indiceDato])
    indiceDato = indiceDato + 1
    columnas = int(datos[indiceDato])
    indiceDato = indiceDato + 1

    laberinto = []
    fila = 0
    while fila < filas:
        renglon = []
        columna = 0
        while columna < columnas:
            valor = int(datos[indiceDato])
            indiceDato = indiceDato + 1
            renglon.append(valor)
            columna = columna + 1
        laberinto.append(renglon)
        fila = fila + 1

    return filas, columnas, laberinto


def crearMatrizEntera(filas, columnas, valorInicial):
    """
    Crea una matriz de enteros del tamano indicado, inicializada con un
    valor dado.

    Parametros:
        filas: numero de filas de la matriz.
        columnas: numero de columnas de la matriz.
        valorInicial: valor con el que se inicializa cada casilla.

    Retorno:
        Una lista de listas de enteros con las dimensiones solicitadas.
    """
    matriz = []
    fila = 0
    while fila < filas:
        renglon = []
        columna = 0
        while columna < columnas:
            renglon.append(valorInicial)
            columna = columna + 1
        matriz.append(renglon)
        fila = fila + 1
    return matriz


def imprimirMatriz(matriz):
    """
    Imprime una matriz binaria en la salida estandar, con los valores de
    cada renglon separados por un espacio.

    Parametros:
        matriz: lista de listas de enteros que se desea imprimir.

    Retorno:
        Ninguno.
    """
    indiceFila = 0
    while indiceFila < len(matriz):
        renglonTexto = " ".join(str(valor) for valor in matriz[indiceFila])
        print(renglonTexto)
        indiceFila = indiceFila + 1


def esMovimientoValido(laberinto, visitado, filas, columnas, renglon, columna):
    """
    Determina si una casilla puede ser visitada durante el recorrido.

    Parametros:
        laberinto: matriz del laberinto.
        visitado: matriz que indica las casillas visitadas en el camino actual.
        filas: numero de filas del laberinto.
        columnas: numero de columnas del laberinto.
        renglon: renglon de la casilla a evaluar.
        columna: columna de la casilla a evaluar.

    Retorno:
        True si la casilla esta dentro del laberinto, es transitable y no
        ha sido visitada; False en caso contrario.
    """
    dentroDeRango = renglon >= 0 and renglon < filas and columna >= 0 and columna < columnas
    esValido = False
    if dentroDeRango:
        esValido = laberinto[renglon][columna] == TRANSITABLE and not visitado[renglon][columna]
    return esValido


def resolverBacktracking(laberinto, filas, columnas, renglon, columna, visitado, camino, movimientos):
    """
    Busca de manera recursiva un camino desde la casilla actual hasta la
    meta utilizando backtracking puro.

    Parametros:
        laberinto: matriz del laberinto.
        filas: numero de filas del laberinto.
        columnas: numero de columnas del laberinto.
        renglon: renglon de la casilla actual.
        columna: columna de la casilla actual.
        visitado: matriz de casillas visitadas en el camino actual.
        camino: matriz donde se marca el camino solucion.
        movimientos: lista de desplazamientos (renglon, columna) permitidos.

    Retorno:
        True si desde esta casilla se llega a la meta; False en caso contrario.
    """
    visitado[renglon][columna] = True
    camino[renglon][columna] = 1

    llegoALaMeta = renglon == filas - 1 and columna == columnas - 1
    encontrado = llegoALaMeta

    indiceMovimiento = 0
    while not encontrado and indiceMovimiento < len(movimientos):
        desplazamientoRenglon, desplazamientoColumna = movimientos[indiceMovimiento]
        siguienteRenglon = renglon + desplazamientoRenglon
        siguienteColumna = columna + desplazamientoColumna
        if esMovimientoValido(laberinto, visitado, filas, columnas, siguienteRenglon, siguienteColumna):
            encontrado = resolverBacktracking(laberinto, filas, columnas, siguienteRenglon, siguienteColumna, visitado, camino, movimientos)
        indiceMovimiento = indiceMovimiento + 1

    if not encontrado:
        camino[renglon][columna] = 0
        visitado[renglon][columna] = False

    return encontrado


def distanciaManhattan(renglon, columna, filas, columnas):
    """
    Calcula la distancia Manhattan entre una casilla y la casilla meta,
    utilizada como cota inferior (heuristica) para la poda.

    Parametros:
        renglon: renglon de la casilla actual.
        columna: columna de la casilla actual.
        filas: numero de filas del laberinto.
        columnas: numero de columnas del laberinto.

    Retorno:
        La distancia Manhattan (entero) hasta la casilla meta.
    """
    return (filas - 1 - renglon) + (columnas - 1 - columna)


def resolverRamificacionPoda(laberinto, filas, columnas, movimientos):
    """
    Busca el camino mas corto desde el origen hasta la meta utilizando
    ramificacion y poda: se exploran primero los nodos mas prometedores
    (menor costo + heuristica) y se descartan los nodos cuya cota no
    puede mejorar la mejor solucion encontrada hasta el momento.

    Parametros:
        laberinto: matriz del laberinto.
        filas: numero de filas del laberinto.
        columnas: numero de columnas del laberinto.
        movimientos: lista de desplazamientos (renglon, columna) permitidos.

    Retorno:
        Una matriz binaria con el camino solucion, o None si no existe
        solucion.
    """
    contadorNodos = 0
    cotaSuperior = float("inf")
    mejorCamino = None

    caminoInicial = [(0, 0)]
    cotaInicial = distanciaManhattan(0, 0, filas, columnas)
    fronteraPrioridad = [(cotaInicial, 0, contadorNodos, 0, 0, caminoInicial)]

    while len(fronteraPrioridad) > 0:
        cotaNodo, costoNodo, _, renglon, columna, caminoActual = heapq.heappop(fronteraPrioridad)
        esNodoPodado = cotaNodo >= cotaSuperior

        if not esNodoPodado:
            llegoALaMeta = renglon == filas - 1 and columna == columnas - 1
            if llegoALaMeta:
                cotaSuperior = costoNodo
                mejorCamino = caminoActual
            else:
                indiceMovimiento = 0
                while indiceMovimiento < len(movimientos):
                    desplazamientoRenglon, desplazamientoColumna = movimientos[indiceMovimiento]
                    siguienteRenglon = renglon + desplazamientoRenglon
                    siguienteColumna = columna + desplazamientoColumna
                    dentroDeRango = siguienteRenglon >= 0 and siguienteRenglon < filas and siguienteColumna >= 0 and siguienteColumna < columnas

                    if dentroDeRango:
                        esTransitable = laberinto[siguienteRenglon][siguienteColumna] == TRANSITABLE
                        yaEnCamino = (siguienteRenglon, siguienteColumna) in caminoActual
                        if esTransitable and not yaEnCamino:
                            costoHijo = costoNodo + 1
                            cotaHijo = costoHijo + distanciaManhattan(siguienteRenglon, siguienteColumna, filas, columnas)
                            esHijoPodado = cotaHijo >= cotaSuperior
                            if not esHijoPodado:
                                contadorNodos = contadorNodos + 1
                                caminoHijo = caminoActual + [(siguienteRenglon, siguienteColumna)]
                                heapq.heappush(fronteraPrioridad, (cotaHijo, costoHijo, contadorNodos, siguienteRenglon, siguienteColumna, caminoHijo))
                    indiceMovimiento = indiceMovimiento + 1

    matrizSolucion = None
    if mejorCamino is not None:
        matrizSolucion = crearMatrizEntera(filas, columnas, 0)
        indiceCelda = 0
        while indiceCelda < len(mejorCamino):
            renglonCelda, columnaCelda = mejorCamino[indiceCelda]
            matrizSolucion[renglonCelda][columnaCelda] = 1
            indiceCelda = indiceCelda + 1

    return matrizSolucion


def main():
    """
    Funcion principal del programa: lee el laberinto de la entrada
    estandar, lo resuelve primero con backtracking y despues con
    ramificacion y poda, e imprime ambas soluciones.

    Parametros:
        Ninguno.

    Retorno:
        Ninguno.
    """
    filas, columnas, laberinto = leerLaberinto()
    movimientos = [(1, 0), (0, 1), (-1, 0), (0, -1)]

    origenTransitable = laberinto[0][0] == TRANSITABLE
    metaTransitable = laberinto[filas - 1][columnas - 1] == TRANSITABLE
    existePosibleSolucion = origenTransitable and metaTransitable

    caminoBacktracking = crearMatrizEntera(filas, columnas, 0)
    if existePosibleSolucion:
        visitadoBacktracking = crearMatrizEntera(filas, columnas, 0)
        resolverBacktracking(laberinto, filas, columnas, 0, 0, visitadoBacktracking, caminoBacktracking, movimientos)
    imprimirMatriz(caminoBacktracking)

    print()

    caminoRamificacionPoda = None
    if existePosibleSolucion:
        caminoRamificacionPoda = resolverRamificacionPoda(laberinto, filas, columnas, movimientos)
    if caminoRamificacionPoda is None:
        caminoRamificacionPoda = crearMatrizEntera(filas, columnas, 0)
    imprimirMatriz(caminoRamificacionPoda)


if __name__ == "__main__":
    main()
