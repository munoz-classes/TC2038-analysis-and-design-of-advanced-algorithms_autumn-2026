# ==============================================================
# Solucion de un laberinto usando backtracking y ramificacion y poda.
# El programa lee de la entrada estandar el tamano del laberinto y sus
# casillas, y muestra el camino de salida encontrado con cada tecnica.
#
# Autor: Sebastian Plata Mercado - A01774031
# Fecha de creacion/modificacion: 31/08/2026
# ==============================================================

import sys
import heapq


# Lee el laberinto desde la entrada estandar.
# Regresa una tupla con la matriz del laberinto, el numero de filas y
# el numero de columnas.
def leerLaberinto():
    datos = sys.stdin.read().split()
    numFilas = int(datos[0])
    numColumnas = int(datos[1])
    laberinto = []
    indice = 2
    fila = 0
    while fila < numFilas:
        renglon = []
        columna = 0
        while columna < numColumnas:
            renglon.append(int(datos[indice]))
            indice = indice + 1
            columna = columna + 1
        laberinto.append(renglon)
        fila = fila + 1
    return laberinto, numFilas, numColumnas


# Crea una matriz de numFilas por numColumnas llena con el valor recibido.
# numFilas: cantidad de renglones de la matriz.
# numColumnas: cantidad de columnas de la matriz.
# valorInicial: valor con el que se llena cada casilla.
# Regresa la matriz ya construida.
def crearMatriz(numFilas, numColumnas, valorInicial):
    matriz = []
    fila = 0
    while fila < numFilas:
        renglon = []
        columna = 0
        while columna < numColumnas:
            renglon.append(valorInicial)
            columna = columna + 1
        matriz.append(renglon)
        fila = fila + 1
    return matriz


# Indica si una casilla cae dentro de los limites del laberinto.
# fila y columna: posicion a revisar.
# numFilas y numColumnas: dimensiones del laberinto.
# Regresa True si la posicion es valida en el rango, False en otro caso.
def estaEnRango(fila, columna, numFilas, numColumnas):
    dentro = False
    if fila >= 0 and fila < numFilas and columna >= 0 and columna < numColumnas:
        dentro = True
    return dentro


# Revisa si una casilla se puede pisar en la solucion actual.
# laberinto: matriz original del laberinto.
# solucion: matriz con el camino que se lleva marcado.
# fila y columna: posicion a revisar.
# numFilas y numColumnas: dimensiones del laberinto.
# Regresa True si la casilla esta libre y aun no se ha usado.
def esCasillaValida(laberinto, solucion, fila, columna, numFilas, numColumnas):
    valida = False
    if estaEnRango(fila, columna, numFilas, numColumnas):
        if laberinto[fila][columna] == 1 and solucion[fila][columna] == 0:
            valida = True
    return valida


# Resuelve el laberinto con la tecnica de backtracking probando en orden
# abajo, derecha, arriba e izquierda. Marca el camino en la matriz solucion.
# laberinto: matriz original del laberinto.
# solucion: matriz donde se va marcando el camino.
# fila y columna: casilla actual.
# numFilas y numColumnas: dimensiones del laberinto.
# Regresa True si desde esta casilla se llega a la salida.
#
# Complejidad: O(4^(numFilas*numColumnas)) en el peor caso, ya que en cada
# casilla se pueden explorar hasta 4 direcciones.
def resolverBacktracking(laberinto, solucion, fila, columna, numFilas, numColumnas):
    encontrado = False
    if esCasillaValida(laberinto, solucion, fila, columna, numFilas, numColumnas):
        solucion[fila][columna] = 1
        if fila == numFilas - 1 and columna == numColumnas - 1:
            encontrado = True
        else:
            movimientos = [(1, 0), (0, 1), (-1, 0), (0, -1)]
            indice = 0
            while indice < len(movimientos) and not encontrado:
                nuevaFila = fila + movimientos[indice][0]
                nuevaColumna = columna + movimientos[indice][1]
                if resolverBacktracking(laberinto, solucion, nuevaFila, nuevaColumna, numFilas, numColumnas):
                    encontrado = True
                indice = indice + 1
            if not encontrado:
                solucion[fila][columna] = 0
    return encontrado


# Calcula la distancia de Manhattan de una casilla hasta la salida.
# Se usa como cota inferior para la ramificacion y poda.
# fila y columna: casilla actual.
# numFilas y numColumnas: dimensiones del laberinto.
# Regresa el numero minimo de pasos que faltarian sin considerar paredes.
def calcularHeuristica(fila, columna, numFilas, numColumnas):
    distancia = (numFilas - 1 - fila) + (numColumnas - 1 - columna)
    return distancia


# Resuelve el laberinto con ramificacion y poda buscando el camino mas corto.
# Se usa una cola de prioridad ordenada por la cota (pasos + heuristica) y se
# podan los nodos cuya cota ya no puede mejorar la mejor solucion encontrada.
# laberinto: matriz original del laberinto.
# numFilas y numColumnas: dimensiones del laberinto.
# Regresa una matriz con el camino mas corto marcado con unos.
#
# Complejidad: O(numFilas*numColumnas*log(numFilas*numColumnas)) gracias a la
# poda con la matriz de distancias, que evita repetir casillas con peor costo.
def resolverRamificacion(laberinto, numFilas, numColumnas):
    solucion = crearMatriz(numFilas, numColumnas, 0)
    distancias = crearMatriz(numFilas, numColumnas, float("inf"))
    cola = []
    mejorCosto = float("inf")
    mejorCamino = []

    if laberinto[0][0] == 1:
        distancias[0][0] = 0
        cotaInicial = calcularHeuristica(0, 0, numFilas, numColumnas)
        heapq.heappush(cola, (cotaInicial, 0, 0, 0, [(0, 0)]))

    while len(cola) > 0:
        nodo = heapq.heappop(cola)
        cota = nodo[0]
        costo = nodo[1]
        fila = nodo[2]
        columna = nodo[3]
        camino = nodo[4]
        if cota < mejorCosto:
            if fila == numFilas - 1 and columna == numColumnas - 1:
                mejorCosto = costo
                mejorCamino = camino
            else:
                movimientos = [(1, 0), (0, 1), (-1, 0), (0, -1)]
                indice = 0
                while indice < len(movimientos):
                    nuevaFila = fila + movimientos[indice][0]
                    nuevaColumna = columna + movimientos[indice][1]
                    if estaEnRango(nuevaFila, nuevaColumna, numFilas, numColumnas):
                        if laberinto[nuevaFila][nuevaColumna] == 1:
                            nuevoCosto = costo + 1
                            if nuevoCosto < distancias[nuevaFila][nuevaColumna]:
                                distancias[nuevaFila][nuevaColumna] = nuevoCosto
                                nuevaCota = nuevoCosto + calcularHeuristica(nuevaFila, nuevaColumna, numFilas, numColumnas)
                                if nuevaCota < mejorCosto:
                                    nuevoCamino = camino + [(nuevaFila, nuevaColumna)]
                                    heapq.heappush(cola, (nuevaCota, nuevoCosto, nuevaFila, nuevaColumna, nuevoCamino))
                    indice = indice + 1

    for casilla in mejorCamino:
        solucion[casilla[0]][casilla[1]] = 1
    return solucion


# Imprime una matriz con los valores separados por un espacio.
# matriz: matriz a imprimir.
# numFilas y numColumnas: dimensiones de la matriz.
def imprimirMatriz(matriz, numFilas, numColumnas):
    fila = 0
    while fila < numFilas:
        renglon = ""
        columna = 0
        while columna < numColumnas:
            renglon = renglon + str(matriz[fila][columna])
            if columna < numColumnas - 1:
                renglon = renglon + " "
            columna = columna + 1
        print(renglon)
        fila = fila + 1


# Funcion principal: lee el laberinto, resuelve con las dos tecnicas e
# imprime primero el resultado de backtracking y despues el de ramificacion.
def main():
    laberinto, numFilas, numColumnas = leerLaberinto()

    solucionBacktracking = crearMatriz(numFilas, numColumnas, 0)
    resolverBacktracking(laberinto, solucionBacktracking, 0, 0, numFilas, numColumnas)
    imprimirMatriz(solucionBacktracking, numFilas, numColumnas)

    print("")

    solucionRamificacion = resolverRamificacion(laberinto, numFilas, numColumnas)
    imprimirMatriz(solucionRamificacion, numFilas, numColumnas)


main()
