# Actividad 1.3 - Solucion de un laberinto
# Alan Joseph Salazar Segura - A01773491

import sys
import heapq

MOVIMIENTOS = ((1, 0), (0, 1), (-1, 0), (0, -1))


def leer_laberinto():
    """Complejidad computacional: O(M*N)"""
    datos = sys.stdin.read().split()
    filas = int(datos[0])
    columnas = int(datos[1])
    valores = [int(dato) for dato in datos[2:2 + filas * columnas]]
    laberinto = []
    for i in range(filas):
        laberinto.append(valores[i * columnas:(i + 1) * columnas])
    return laberinto, filas, columnas


def resolver_backtracking(laberinto, filas, columnas):
    """Complejidad computacional: O(4^(M*N))"""
    solucion = [[0] * columnas for _ in range(filas)]

    def avanzar(i, j):
        if i < 0 or i >= filas or j < 0 or j >= columnas:
            return False
        if laberinto[i][j] == 0 or solucion[i][j] == 1:
            return False
        solucion[i][j] = 1
        if i == filas - 1 and j == columnas - 1:
            return True
        for di, dj in MOVIMIENTOS:
            if avanzar(i + di, j + dj):
                return True
        solucion[i][j] = 0
        return False

    avanzar(0, 0)
    return solucion


def resolver_ramificacion_poda(laberinto, filas, columnas):
    """Complejidad computacional: O(M*N*log(M*N))"""
    solucion = [[0] * columnas for _ in range(filas)]
    if laberinto[0][0] == 0 or laberinto[filas - 1][columnas - 1] == 0:
        return solucion

    infinito = float('inf')
    costos = [[infinito] * columnas for _ in range(filas)]
    padres = {}
    costos[0][0] = 0
    mejor = infinito
    monticulo = [(filas - 1 + columnas - 1, 0, 0, 0)]

    while monticulo:
        cota, costo, i, j = heapq.heappop(monticulo)
        if cota >= mejor or costo > costos[i][j]:
            continue
        if i == filas - 1 and j == columnas - 1:
            mejor = costo
            continue
        for di, dj in MOVIMIENTOS:
            ni, nj = i + di, j + dj
            if 0 <= ni < filas and 0 <= nj < columnas and laberinto[ni][nj] == 1:
                nuevo_costo = costo + 1
                nueva_cota = nuevo_costo + (filas - 1 - ni) + (columnas - 1 - nj)
                if nuevo_costo < costos[ni][nj] and nueva_cota < mejor:
                    costos[ni][nj] = nuevo_costo
                    padres[(ni, nj)] = (i, j)
                    heapq.heappush(monticulo, (nueva_cota, nuevo_costo, ni, nj))

    if costos[filas - 1][columnas - 1] == infinito:
        return solucion

    actual = (filas - 1, columnas - 1)
    while actual is not None:
        solucion[actual[0]][actual[1]] = 1
        actual = padres.get(actual)
    return solucion


def imprimir_matriz(matriz):
    """Complejidad computacional: O(M*N)"""
    for fila in matriz:
        print(' '.join(str(valor) for valor in fila))


def main():
    """Complejidad computacional: O(4^(M*N))"""
    sys.setrecursionlimit(1000000)
    laberinto, filas, columnas = leer_laberinto()
    imprimir_matriz(resolver_backtracking(laberinto, filas, columnas))
    imprimir_matriz(resolver_ramificacion_poda(laberinto, filas, columnas))


main()
